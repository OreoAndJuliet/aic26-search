from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from app.core.config import settings
from app.services.kis_engine import kis_engine
from app.services.media_info_store import media_info_store

router = APIRouter()


@router.get("/keyframes/{video_id}/{frame_id}.jpg")
async def serve_keyframe_by_frame_id(video_id: str, frame_id: int) -> FileResponse:
    """Serve keyframe images using FE contract paths keyed by frame_id.

    Updated to match specification: /keyframes/<video_name>/<frame_id>.jpg

    Try multiple strategies to locate the image:
    1. Ask kis_engine (preferred; honors metadata mappings).
    2. Fallback to STATIC_DIR/keyframes/{video_id}/{frame_id}.jpg
    3. Fallback to STATIC_DIR/keyframes/{video_id}/{frame_id:03d}.jpg
    """
    # 1) Preferred: ask KIS store for the canonical image path
    image_path_raw = kis_engine.resolve_keyframe_path(video_id, frame_id)
    if image_path_raw is not None:
        image_path = Path(image_path_raw)
        if not image_path.is_absolute():
            image_path = Path(settings.STATIC_DIR) / image_path
        if image_path.is_file():
            return FileResponse(path=image_path, media_type="image/jpeg")

    # 2) Fallback: direct path under KEYFRAMES_DIR
    static_candidate = Path(settings.KEYFRAMES_DIR) / video_id / f"{frame_id}.jpg"
    if static_candidate.is_file():
        return FileResponse(path=static_candidate, media_type="image/jpeg")

    # 3) Fallback: zero-padded keyframe id style used by some ingesters
    padded_candidate = Path(settings.KEYFRAMES_DIR) / video_id / f"{frame_id:03d}.jpg"
    if padded_candidate.is_file():
        return FileResponse(path=padded_candidate, media_type="image/jpeg")

    # 4) Fallback: scan for any file that represents the same numeric frame id
    # (e.g., 001.jpg, 0001.jpg) — handle ingesters that use different padding.
    video_dir = Path(settings.KEYFRAMES_DIR) / video_id
    if video_dir.is_dir():
        # Try exact match by name first (already checked), then try numeric match ignoring leading zeros
        for child in sorted(video_dir.iterdir()):
            if not child.is_file():
                continue
            if child.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
                continue
            name = child.stem  # filename without suffix
            # Compare numeric value if name is all digits (handles leading zeros)
            if name.isdigit() and int(name) == frame_id:
                return FileResponse(path=child, media_type="image/jpeg")

    # 5) Fallback: try legacy STATIC_DIR path for backward compatibility
    legacy_dir = Path(settings.STATIC_DIR) / "keyframes" / video_id
    if legacy_dir.is_dir():
        # Try to find exact numeric match in legacy dir too
        for child in sorted(legacy_dir.iterdir()):
            if child.is_file() and child.suffix.lower() in {".jpg", ".jpeg", ".png"}:
                if child.stem.isdigit() and int(child.stem) == frame_id:
                    return FileResponse(path=child, media_type="image/jpeg")

    # Nothing found
    raise HTTPException(status_code=404, detail="Keyframe image not found.")


@router.get("/api/v1/videos/{video_id}/info")
async def video_info(video_id: str) -> dict:
    """Return optional YouTube metadata JSON for a video when available."""
    info = media_info_store.get(video_id)
    if info is None:
        raise HTTPException(status_code=404, detail="Video metadata not found.")
    return {"video_id": video_id, "metadata": info}
