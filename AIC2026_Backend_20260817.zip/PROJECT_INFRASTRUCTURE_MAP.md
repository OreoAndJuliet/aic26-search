# AIC 2026 Backend - Project Infrastructure Map & Architectural Blueprint

Comprehensive architectural blueprint of the AIC 2026 Video Retrieval & Question Answering Backend. Use this document as the system map for future development, optimizations, and prompts.

---

## 1. High-Level Architecture Overview

```mermaid
flowchart TD
    Client[Client / Frontend / CLI\nsearch.ps1 / Web UI] --> API[FastAPI Gateway\nmain.py :8000]
    
    subgraph API Layer [API & Routing Layer]
        API --> R_Search[routers/search.py\nPOST /api/search\nPOST /api/search_trake\nPOST /api/v1/search]
        API --> R_Export[routers/export.py\nPOST /api/export/csv]
        API --> R_Health[routers/health.py\nGET /health, GET /]
        API --> R_Media[routers/media.py\nGET /keyframes/:video/:frame]
    end

    subgraph Service Orchestration [Search Orchestration Layer]
        R_Search --> S_Search[features/search/service.py\nUnified run_search]
        S_Search --> Translator[services/translator.py\nGoogle GTX / Gemini API]
        S_Search --> KIS_Pipe[features/search/retrieval.py\nrun_kis_retrieval]
        S_Search --> VQA_Pipe[features/vqa/service.py\nanswer_vqa_question]
        S_Search --> TRAKE_Pipe[services/trake_engine.py\nalign_events]
    end

    subgraph Engine & Vector Layer [Core Retrieval & Vector Engine]
        KIS_Pipe --> KISEngine[services/kis_engine.py\nKISEngine]
        KISEngine --> TextEnc[providers/text_encoder.py\nCLIP ViT-B/32 + Multilingual Ensemble]
        KISEngine --> VecStore[vector/faiss_store.py / hybrid_store.py\nFAISS IndexFlatIP]
        VecStore --> FaissBin[(data/faiss_index.bin\n19k+ L2 Normalized Vectors)]
        VecStore --> MetaJson[(data/metadata.json\nVector-to-Frame Mappings)]
    end

    subgraph Post-Processing & Reranking [Post-Processing & Reranking Pipeline]
        KISEngine --> CrossEnc[algorithms/cross_encoder.py\nIn-Memory Cosine Reranking]
        KISEngine --> ObjStore[services/object_store.py\nFaster R-CNN Bounding Boxes]
        KISEngine --> MediaStore[services/media_info_store.py\nChannel/Title/Description Match]
        KISEngine --> HybridRank[algorithms/hybrid_ranking.py\nMetadata Keyword Overlap]
    end

    subgraph VQA Intelligence Layer [Visual Question Answering Pipeline]
        VQA_Pipe --> VQAEngine[services/vqa_engine.py\nVQAEngine]
        VQAEngine --> PersonCheck{Is Person Count?}
        PersonCheck -- Yes --> FasterRCNN[object_store.py\nFaster R-CNN JSON Count]
        PersonCheck -- No / Low Conf --> VLMProvider[providers/vlm.py\nGemini 2.0 / Flash-Lite VLM]
        VLMProvider --> VLMCache[(cache/vlm_cache.py\nScoped Answer Cache)]
    end
```

---

## 2. Directory Tree & Module Hierarchy

```
D:\backup\
├── main.py                       # FastAPI entrypoint, middleware, static mounts & exception handlers
├── build_index.py                # Builds FAISS index (faiss_index.bin) & metadata.json from features
├── requirements.txt              # Production Python dependencies
├── .env / .env.example           # Runtime environment variables & AI provider configurations
│
├── app/                          # Core application package
│   ├── algorithms/               # Mathematical ranking and alignment algorithms
│   │   ├── cross_encoder.py      # Cosine similarity re-scoring over top candidates
│   │   ├── hybrid_ranking.py     # Metadata keyword overlap scoring
│   │   ├── kis_postprocess.py    # Faster R-CNN object constraint filtering & confidence weighting
│   │   └── temporal_alignment.py # Dynamic programming/greedy event sequence alignment for TRAKE
│   │
│   ├── cache/                    # High-throughput caching subsystem
│   │   ├── base.py & factory.py  # Cache backend abstraction & factory (Memory / Redis)
│   │   ├── embedding_cache.py    # In-memory LRU cache for query text embeddings
│   │   ├── text_cache.py         # Translation cache (Vietnamese -> English)
│   │   └── vlm_cache.py          # Scoped cache for Gemini/OpenAI VLM answers
│   │
│   ├── core/                     # Application foundation
│   │   ├── config.py             # Strongly-typed Pydantic Settings & environment validation
│   │   ├── exceptions.py         # Standardized backend exception hierarchy
│   │   └── logging.py            # Structured logging formatter
│   │
│   ├── data/                     # Data adapters & schemas
│   │   └── aic_keyframe_adapter.py # Keyframe CSV map adapter (n, frame_idx, pts_time)
│   │
│   ├── features/                 # High-level domain workflows
│   │   ├── competition/          # Batch evaluation & official submission formatting
│   │   ├── search/               # Unified search contracts, schemas, and retrieval service
│   │   ├── search_kis/           # Legacy v1 KIS search routes & schemas
│   │   └── vqa/                  # VQA orchestration (Faster R-CNN first, VLM fallback)
│   │
│   ├── providers/                # External & local AI model integrations
│   │   ├── text_encoder.py       # CLIP ViT-B/32 & Multilingual Ensemble text encoders
│   │   ├── translation.py        # Google GTX & Gemini translation providers
│   │   └── vlm.py                # Gemini, OpenAI, Claude, Qwen VLM providers with circuit breaker
│   │
│   ├── routers/                  # FastAPI HTTP endpoint controllers
│   │   ├── export.py             # CSV export & competition submission generation
│   │   ├── health.py             # /health & / system diagnostics
│   │   ├── media.py              # Dynamic keyframe image resolution
│   │   └── search.py             # POST /api/search (KIS, VQA, TRAKE) & POST /api/search_trake
│   │
│   ├── services/                 # Singleton business logic engines
│   │   ├── kis_engine.py         # Core KIS search, warmup, FAISS execution, & reranking
│   │   ├── vqa_engine.py         # VQA prompt building, VLM invocation, & answer caching
│   │   ├── trake_engine.py       # Temporal sequence retrieval & alignment coordinator
│   │   ├── translator.py         # Language detection & translation coordinator
│   │   ├── object_store.py       # Indexed access to Faster R-CNN object bounding boxes
│   │   ├── media_info_store.py   # Indexed access to video metadata (titles, descriptions)
│   │   └── zip_ingest.py         # Inbox archive extraction pipeline
│   │
│   ├── utils/                    # Shared utilities
│   │   ├── circuit_breaker.py    # Resilience circuit breaker for remote APIs
│   │   ├── keyframes.py          # Keyframe path resolution helpers
│   │   └── vqa_answer.py         # VQA prompt construction & response regex parsers
│   │
│   └── vector/                   # Vector database abstraction layer
│       ├── base.py & factory.py  # Vector store interface & factory
│       ├── faiss_store.py        # FAISS IndexFlatIP implementation (RAM-based, 100% exact recall)
│       ├── milvus_store.py       # Milvus gRPC vector store (Docker/cluster scaling)
│       ├── hybrid_store.py       # Dual FAISS + Milvus query execution
│       └── merge.py              # Reciprocal Rank Fusion (RRF) for multi-backend hits
│
├── data/                         # Persistent datasets & vector storage
│   ├── faiss_index.bin           # Serialized FAISS IndexFlatIP binary
│   ├── metadata.json             # Serialized vector-to-frame metadata index
│   ├── map_keyframes/            # CSV map files for each video (n, pts_time, fps, frame_idx)
│   ├── features/                 # Pre-extracted CLIP .npy feature matrices
│   ├── objects/                  # Faster R-CNN detection JSON files per video
│   └── media_info/               # JSON metadata per video (titles, descriptions, channel)
│
├── static/                       # Static media assets served over HTTP
│   ├── keyframes/                # Extracted keyframe images (<video_id>/<keyframe_id>.jpg)
│   └── videos/                   # Raw MP4 video files
│
├── submission/                   # Output directory for generated competition submissions
│
└── scripts/ & Root Scripts       # Automation & Operations
    ├── start.bat                 # Server launcher with `--reset` ghost-process killer
    ├── setup.bat / install.ps1   # One-click installer with automated tqdm Windows hotfix
    ├── setup.ps1                 # Lightweight environment setup & hotfix script
    ├── search.ps1                # Unified CLI search tool (-Mode KIS / VQA / TRAKE)
    ├── package_for_release.ps1   # Packages self-installing release ZIP
    ├── ingest.ps1                # Batch zip extractor for data/inbox
    └── test.ps1                  # Test suite runner & validation harness
```

---

## 3. Core Task Workflows & Execution Pipelines

### A. Known-Item Search (KIS) Pipeline
1. **Input**: User query (Vietnamese or English), `top_k` (default 20).
2. **Translation**: `TranslatorService` checks for Vietnamese characters. If detected, calls Google GTX or Gemini; bypasses network if English.
3. **Query Embedding**: `kis_engine` encodes English text via `SentenceTransformerClipTextEncoder` (or `EnsembleTextEncoder`). Result is cached in memory.
4. **Vector Search**: `FaissVectorStore` searches `data/faiss_index.bin` using inner-product (cosine similarity on L2-normalized 512-dim vectors) in ~4ms.
5. **Metadata Hydration**: Vector IDs are converted to `video_id`, `frame_id`, `pts_time`, and `thumbnail_url` via `data/metadata.json`.
6. **Cross-Encoder Reranking**: Top $N$ candidates are re-scored against the query embedding.
7. **Multimodal Boost**:
   - `object_store`: Matches detected objects (e.g. "car", "person") and adjusts confidence scores.
   - `media_info_store`: Overlaps title/channel/description terms with query keywords.
8. **Output**: Sorted list of validated keyframe candidates with similarity scores.

### B. Visual Question Answering (VQA) Pipeline
1. **Input**: Context `query`, question `question`, `top_k`.
2. **Candidate Retrieval**: Runs KIS retrieval using `query` to locate top $K$ keyframe candidates.
3. **Person Count Fast-Path**:
   - If question asks *"How many people / bao nhiêu người"*, queries `object_store` for Faster R-CNN person detections.
   - If detection confidence is high, returns integer count directly (`source: FASTER_RCNN_JSON`) in **<10ms**.
4. **VLM Answering**:
   - For general questions (or low detection confidence), loads keyframe image from disk.
   - Sends image + prompt to Gemini (`gemini-flash-lite-latest`) or configured VLM provider.
   - Circuit breaker and exponential backoff retry on 503/429 demand spikes.
5. **Caching**: Answers are cached in `VlmCache` scoped by model and image hash.
6. **Output**: Keyframes populated with concise answers (`yes`, `no`, `red car`, etc.).

### C. Temporal Retrieval & Keyframe Alignment (TRAKE) Pipeline
1. **Input**: Sequence of events (e.g. `["person enters room", "sits at desk", "stands up and leaves"]`), `max_gap_seconds` (300s).
2. **Translation**: Translates all event strings concurrently.
3. **Per-Event Retrieval**: Runs vector search for each individual event.
4. **Temporal Alignment**: `TemporalAlignmentEngine` searches for timestamp-monotone paths:
   $$t(e_1) < t(e_2) < \dots < t(e_n) \quad \text{and} \quad t(e_{i+1}) - t(e_i) \le \text{max\_gap}$$
5. **Output**: Aligned sequence of keyframes representing the temporal story.

---

## 4. API Endpoints Reference

| Method | Endpoint | Description | Request Body Key Fields |
|---|---|---|---|
| `POST` | `/api/search` | **Unified Search** (Specification required) | `type`: `"KIS"`\|`"VQA"`\|`"TRAKE"`, `query`: str, `question`: str?, `events`: list[str]?, `top_k`: int |
| `POST` | `/api/search_trake` | **TRAKE Endpoint** (Specification required) | `events`: list[str], `top_k_per_event`: int, `max_gap_seconds`: float |
| `POST` | `/api/export/csv` | **Competition Export** | `results`: list, `query_id`: str, `session_id`: str |
| `GET` | `/health` | **System Health Diagnostics** | Returns index status, memory usage, and backend mode |
| `GET` | `/keyframes/{video_id}/{frame_id}` | **Keyframe Image Stream** | Direct JPEG image resolver |
| `GET` | `/` | **Root Status** | Quick ping / online indicator |

---

## 5. Technology Stack & Key Libraries

| Component | Technology / Library | Purpose |
|---|---|---|
| **Web Framework** | FastAPI + Uvicorn + Pydantic v2 | High-performance asynchronous HTTP REST API |
| **Vector Engine** | FAISS (`IndexFlatIP`) | 100% exact cosine search over 512-dim normalized vectors |
| **Text Embedding** | `sentence-transformers` (`clip-ViT-B-32`) | Multilingual visual-semantic embedding |
| **Vision-Language (VLM)** | Google Gemini (`google-genai` / `gemini-flash-lite-latest`) | Visual reasoning and VQA frame answering |
| **Translation** | Google GTX Client / Gemini Flash | Sub-millisecond Vietnamese $\to$ English query translation |
| **Object Detection Index** | Faster R-CNN JSON Storage | Offline pre-computed bounding box counts |
| **Resilience** | Custom Circuit Breaker + Tenacity Backoff | Prevents cascading failures during remote API outages |

---

## 6. Key Configuration Variables (`.env`)

```ini
# Server & General
BACKEND_HOST=http://0.0.0.0:8000
VECTOR_BACKEND=faiss                      # Options: faiss, milvus, hybrid
AI_PROVIDER_MODE=real                     # Options: real, mock

# Encoders & Ensemble
TEXT_ENCODER_PROVIDER=sentence_transformers
CLIP_MODEL_NAME=sentence-transformers/clip-ViT-B-32
TEXT_ENCODER_ENSEMBLE_ENABLED=true
ENSEMBLE_MODEL_NAME=sentence-transformers/clip-ViT-B-32-multilingual-v1
ENSEMBLE_PRIMARY_WEIGHT=0.5
ENSEMBLE_SECONDARY_WEIGHT=0.5

# Reranking & Quality
CROSS_ENCODER_ENABLED=true
CROSS_ENCODER_TOP_K=100
CROSS_ENCODER_WEIGHT=0.5
KIS_MEDIA_INFO_RERANK=true
HYBRID_METADATA_RERANK_ENABLED=true

# VQA & VLM
VQA_PROVIDER=gemini
GEMINI_API_KEY=<your_api_key>
GEMINI_MODEL=gemini-flash-lite-latest
VQA_TIMEOUT_SECONDS=60
```

---

## 7. Operations & Commands Cheatsheet

### Starting & Managing Server
```powershell
# Clean start (automatically terminates ghost processes on :8000)
.\start.bat --reset

# Standard background launch
.\start.bat
```

### Running Searches via CLI
```powershell
# Known-Item Search
.\search.ps1 -Mode KIS "người đi xe máy trên đường" -TopK 20

# Visual Question Answering
.\search.ps1 -Mode VQA "kitchen scene" -Question "What is on table?" -TopK 5

# Temporal Event Sequence
.\search.ps1 -Mode TRAKE -Events "enters room","sits at table","stands up"
```

### Ingestion, Indexing & Packaging
```powershell
# Extract organizer zip files from data/inbox/
.\ingest.ps1

# Build / Rebuild FAISS index from features
.\.venv\Scripts\python.exe build_index.py

# Create self-installing distribution package
.\package_for_release.ps1 -Version "20260817"

# Run test suite
.\test.ps1
```

---

## 8. Index & Artifact Resolution Map

How any search result connects back to raw data, object detections, metadata, and media assets:

```mermaid
flowchart LR
    VectorHit[FAISS Hit\nvector_id: 17517] --> Metadata[(data/metadata.json)]
    Metadata --> VideoID[video_id: L22_V021]
    Metadata --> KeyframeID[keyframe_id: 17517]
    Metadata --> Timestamp[pts_time: 583.93s]
    
    VideoID & KeyframeID --> ObjectJSON[(data/objects/L22_V021/17517.json\nFaster R-CNN Detections)]
    VideoID & KeyframeID --> KeyframeMap[(data/map_keyframes/L22_V021.csv\nFPS, frame_idx)]
    VideoID --> MediaInfo[(data/media_info/L22_V021.json\nTitle, Channel, Transcript)]
    VideoID & KeyframeID --> ImageFile[(static/keyframes/L22_V021/17517.jpg\nJPEG Image Stream)]
```

### Artifact Resolution Paths & Schemas:

| Artifact | File Path Pattern | Key Fields / Schema | Code Resolver |
|---|---|---|---|
| **Vector Index** | `data/faiss_index.bin` | 512-dim `float32` L2-normalized vectors | `FaissVectorStore.search(query_vector, k)` |
| **Frame Metadata** | `data/metadata.json` | `vector_id`, `video_id`, `keyframe_id`, `frame_id`, `timestamp`, `image_path` | `FaissVectorStore.metadata_for(vector_id)` |
| **Object Detections** | `data/objects/<video_id>/<keyframe_id:03d>.json` | `detection_scores`: float[], `detection_class_entities`: str[], `detection_boxes`: [ymin, xmin, ymax, xmax][] | `object_store.get_detections(video_id, keyframe_id)` |
| **Keyframe Map** | `data/map_keyframes/<video_id>.csv` | `n` (keyframe_id), `pts_time` (seconds), `fps`, `frame_idx` (video frame number) | `AICKeyframeAdapter.load_keyframe_map(video_id)` |
| **Media Info** | `data/media_info/<video_id>.json` | `title`, `channel`, `description`, `published_at`, `duration` | `media_info_store.get_media_info(video_id)` |
| **Keyframe Image** | `static/keyframes/<video_id>/<keyframe_id:03d>.jpg` | Standard JPEG keyframe image | `keyframe_image_path(video_id, keyframe_id)` |
