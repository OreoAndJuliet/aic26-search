"""Parse and normalize VQA answers from VLM providers."""

from __future__ import annotations

import json
import re
from typing import Any

MAX_VQA_ANSWER_LENGTH = 100


def build_vqa_prompt(question: str) -> str:
    """Build optimized VQA prompt for better answer quality and consistency."""
    
    clean_q = question.strip()
    q_lower = clean_q.lower()
    words = re.findall(r"\b\w+\b", q_lower)
    first_word = words[0] if words else ""
    
    # 1. Count questions
    if any(phrase in q_lower for phrase in ["how many", "number of", "count", "quantity"]):
        return (
            "Answer using only the image. Count the objects accurately. "
            "Return JSON only in this exact shape: "
            '{"answer": "<number> or \"0\" if none"}. '
            "Be precise - return only the number as a string. "
            f"Question: {clean_q}"
        )
    
    # 2. Color questions
    if any(phrase in q_lower for phrase in ["what color", "which color", "color of", "colour"]):
        return (
            "Answer using only the image. Identify the primary color accurately. "
            "Return JSON only in this exact shape: "
            '{"answer": "<color name>"}. '
            "Use standard color names (e.g. red, blue, green, white, black, silver). "
            f"Question: {clean_q}"
        )
    
    # 3. Location questions
    if first_word in ("where",) or any(phrase in q_lower for phrase in ["where is", "located at", "what place"]):
        return (
            "Answer using only the image. Describe the location concisely. "
            "Return JSON only in this exact shape: "
            '{"answer": "<location description>"}. '
            "Keep it brief (under 50 characters). "
            f"Question: {clean_q}"
        )
    
    # 4. Object / Action / Entity questions (What, Which, Who, Name)
    if first_word in ("what", "which", "who", "whom", "whose", "name"):
        return (
            "Answer using only the image. Identify the specific object(s), person, text, or action accurately. "
            "Return JSON only in this exact shape: "
            '{"answer": "<concise answer naming the object, action, or item>"}. '
            "Do NOT answer with yes/no. Give the specific item name (e.g., 'laptop and cup', 'fruits', 'cooking food', 'microphone'). "
            f"Question: {clean_q}"
        )
    
    # 5. True Yes/No (Polar) questions starting with auxiliary verbs
    if first_word in ("is", "are", "do", "does", "did", "can", "could", "will", "would", "has", "have", "had", "was", "were"):
        return (
            "Answer using only the image. Provide a yes or no answer. "
            "Return JSON only in this exact shape: "
            '{"answer": "yes" or "no"}. '
            "Answer strictly 'yes' or 'no' based on the image. "
            f"Question: {clean_q}"
        )
    
    # 6. General questions
    return (
        "Answer using only the image. Provide a concise, accurate answer naming the specific item or action. "
        "Return JSON only in this exact shape: "
        '{"answer": "<short answer>"}. '
        "Keep the answer short and suitable for CSV export (max 100 characters). "
        f"Question: {clean_q}"
    )


def _strip_code_fence(text: str) -> str:
    cleaned = text.strip()
    cleaned = re.sub(r"^\s*```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```\s*$", "", cleaned)
    return cleaned.strip()


def _extract_answer_from_json(payload: Any) -> str | None:
    if isinstance(payload, dict):
        for key in ("answer", "response", "text", "result"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, dict):
                extracted = _extract_answer_from_json(value)
                if extracted:
                    return extracted
        return None

    if isinstance(payload, list):
        for item in payload:
            extracted = _extract_answer_from_json(item)
            if extracted:
                return extracted
    return None


def parse_vqa_answer(raw_text: str, *, max_length: int = MAX_VQA_ANSWER_LENGTH) -> str:
    """Parse provider output as JSON when possible, otherwise use plain text."""
    text = _strip_code_fence(raw_text)
    if not text:
        return ""

    try:
        payload = json.loads(text)
        extracted = _extract_answer_from_json(payload)
        if extracted:
            text = extracted
    except json.JSONDecodeError:
        pass

    normalized = " ".join(text.split())
    if len(normalized) <= max_length:
        return normalized
    return normalized[:max_length].rstrip()
