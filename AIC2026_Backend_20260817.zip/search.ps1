<#
.SYNOPSIS
    Unified search entry point for KIS, VQA, and TRAKE modes.
.DESCRIPTION
    Replaces search_kis.ps1, search_vqa.ps1, search_trake.ps1 with a single script.
    Reads .env from script directory, calls the backend /api/search endpoint.
.EXAMPLE
    .\search.ps1 -Mode KIS -Query "a dog running on the beach"
    .\search.ps1 -Mode VQA -Query "outdoor scene" -Question "What is the animal doing?"
    .\search.ps1 -Mode TRAKE -Query "enters|sits|leaves"
    .\search.ps1 -Mode TRAKE -Events "enters","sits","leaves"
    .\search.ps1 -Help
#>

[CmdletBinding()]
param(
    [Alias('Type')]
    [ValidateSet('KIS','VQA','TRAKE')]
    [string] $Mode = 'KIS',

    [Parameter(Position = 0)]
    [Alias('q')]
    [string] $Query = '',

    [string] $Question = '',

    [string[]] $Events = @(),

    [string] $EventList = '',

    [int] $TopK = -1,   # -1 means "use mode default"

    [string] $ApiBase = '',

    [Alias('h')]
    [switch] $Help,

    [switch] $Json
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --- Colored output helpers --------------------------------------------------
function Write-Info  { param([string]$Msg) Write-Host $Msg -ForegroundColor Cyan }
function Write-Warn  { param([string]$Msg) Write-Host "WARN: $Msg" -ForegroundColor Yellow }
function Write-Err   { param([string]$Msg) Write-Host "ERR:  $Msg" -ForegroundColor Red }
function Write-Ok    { param([string]$Msg) Write-Host $Msg -ForegroundColor Green }

# --- Load .env file from script directory ------------------------------------
function Load-EnvFile {
    $envPath = Join-Path $PSScriptRoot '.env'
    if (-not (Test-Path $envPath)) { return }
    foreach ($line in Get-Content $envPath) {
        $line = $line.Trim()
        if ($line -match '^\s*#' -or $line -eq '') { continue }
        if ($line -match '^([^=]+)=(.*)$') {
            $key = $Matches[1].Trim()
            $val = $Matches[2].Trim().Trim('"').Trim("'")
            [System.Environment]::SetEnvironmentVariable($key, $val, 'Process')
        }
    }
}

# --- Show help / usage -------------------------------------------------------
function Show-Help {
    Write-Host @'

USAGE:  .\search.ps1 [-Mode <KIS|VQA|TRAKE>] [-Query <text>] [options]

MODES:
  KIS    Known-Item Search -- find frames matching a text description
  VQA    Visual Q&A Search -- find frames, then answer a question about them
  TRAKE  Temporal RE -- find a sequence of events across time

PARAMETERS:
  -Mode / -Type       KIS | VQA | TRAKE   (default: KIS)
  -Query / -q         Search query / context text (positional arg 0)
  -Question / -Q      VQA question (VQA only)
  -Events             Array of event strings (TRAKE only)
  -EventList          Pipe-separated events, e.g. 'enters|sits|leaves' (TRAKE only)
  -TopK               Result count (default: 20 for KIS/VQA, 100 for TRAKE)
  -ApiBase            Backend URL (default: $env:BACKEND_HOST or http://127.0.0.1:8000)
  -Json               Output raw JSON instead of formatted table
  -Help / -h          Show this help

EXAMPLES:
  # KIS
  .\search.ps1 "a person walks into a room"
  .\search.ps1 -Mode KIS -Query "sunset over water" -TopK 5

  # VQA
  .\search.ps1 -Mode VQA -Query "kitchen scene" -Question "How many people?"
  .\search.ps1 -Mode VQA -q "outdoor market" -Q "What is being sold?"

  # TRAKE (pipe syntax or -Events array)
  .\search.ps1 -Mode TRAKE -Query "enters|sits down|stands up|leaves"
  .\search.ps1 -Mode TRAKE -Events "opens door","walks in","closes door"
  .\search.ps1 -Mode TRAKE -EventList "enters|sits|leaves"

'@ -ForegroundColor White
}

# --- POST to backend /api/search ---------------------------------------------
function Invoke-BackendSearch {
    param(
        [string]   $Base,
        [hashtable]$Body
    )
    $uri  = "$Base/api/search"
    $json = $Body | ConvertTo-Json -Depth 6 -Compress
    Write-Info "  -> POST $uri"
    try {
        $resp = Invoke-RestMethod -Method Post -Uri $uri `
            -ContentType 'application/json' -Body $json
        return $resp
    } catch {
        Write-Err "Request failed: $_"
        exit 1
    }
}

# --- Format results as a table -----------------------------------------------
function Format-ResultTable {
    param(
        $Results,
        [string] $SearchMode,
        [string] $Base
    )

    if (-not $Results -or $Results.Count -eq 0) {
        Write-Warn 'No results returned. Is the backend running?'
        return
    }

    $rank = 1
    $rows = $Results | ForEach-Object {
        $r = $_

        # Build thumbnail URL -- use /keyframes (fixes old /static/keyframes bug)
        $thumb = if ($r.PSObject.Properties['thumbnail_url'] -and $r.thumbnail_url) {
            $r.thumbnail_url -replace '^/static/keyframes', '/keyframes'
        } elseif ($r.PSObject.Properties['video_id'] -and $r.PSObject.Properties['frame_id']) {
            "$Base/keyframes/$($r.video_id)/$($r.frame_id)"
        } else { '' }

        $score = if ($r.PSObject.Properties['r_score']) {
            '{0:F4}' -f [double]$r.r_score
        } else { '' }

        $row = [ordered]@{
            rank          = $rank++
            r_score       = $score
            video_id      = if ($r.PSObject.Properties['video_id'])  { $r.video_id }  else { '' }
            frame_id      = if ($r.PSObject.Properties['frame_id'])  { $r.frame_id }  else { '' }
            timestamp     = if ($r.PSObject.Properties['timestamp']) { $r.timestamp } else { '' }
            thumbnail_url = $thumb
        }

        if ($SearchMode -eq 'VQA') {
            $row['answer'] = if ($r.PSObject.Properties['answer']) { $r.answer } else { '' }
            $row['source'] = if ($r.PSObject.Properties['source']) { $r.source } else { 'VLM_API' }
        }
        if ($SearchMode -eq 'TRAKE') {
            $row['event_index'] = if ($r.PSObject.Properties['event_index']) { $r.event_index } else { '' }
            $row['event_text']  = if ($r.PSObject.Properties['event_text'])  { $r.event_text }  else { '' }
            $row.Remove('thumbnail_url')   # TRAKE table skips thumbnail column
        }

        [PSCustomObject]$row
    }

    switch ($SearchMode) {
        'KIS'   { $rows | Format-Table rank, r_score, video_id, frame_id, timestamp, thumbnail_url -AutoSize }
        'VQA'   { $rows | Format-Table rank, r_score, answer, source, video_id, frame_id, timestamp, thumbnail_url -AutoSize }
        'TRAKE' {
            $rows | Format-Table rank, event_index, event_text, r_score, video_id, frame_id, timestamp -AutoSize

            # Submission summary box
            $frames = ($Results | ForEach-Object {
                if ($_.PSObject.Properties['frame_id']) { $_.frame_id } else { '' }
            }) -join ', '
            $vid = if ($Results[0].PSObject.Properties['video_id']) { $Results[0].video_id } else { '?' }
            Write-Host ''
            Write-Host ('+' + '-' * 62 + '+') -ForegroundColor Magenta
            Write-Host ("|  Submission line: $vid, $frames".PadRight(63) + '|') -ForegroundColor Magenta
            Write-Host ('+' + '-' * 62 + '+') -ForegroundColor Magenta
        }
    }
}

# --- Print timing summary ----------------------------------------------------
function Show-Timing {
    param($Response)
    $total = if ($Response.PSObject.Properties['total_time_ms'])       { $Response.total_time_ms }       else { '--' }
    $trans = if ($Response.PSObject.Properties['translation_time_ms']) { $Response.translation_time_ms } else { '--' }
    $retr  = if ($Response.PSObject.Properties['retrieval_time_ms'])   { $Response.retrieval_time_ms }   else { '--' }
    $vlm   = if ($Response.PSObject.Properties['vlm_time_ms'])         { $Response.vlm_time_ms }         else { 0 }

    $vlmPart = if ([double]$vlm -gt 0) { "  vlm=${vlm}ms" } else { '' }
    Write-Host ''
    Write-Host "Timing: total=${total}ms  translate=${trans}ms  retrieve=${retr}ms${vlmPart}" `
        -ForegroundColor DarkGray
}

# ============================================================================
#  MAIN
# ============================================================================

Load-EnvFile

if ($Help) { Show-Help; exit 0 }

# Resolve ApiBase
if (-not $ApiBase) {
    $ApiBase = if ($env:BACKEND_HOST) { $env:BACKEND_HOST } else { 'http://127.0.0.1:8000' }
}
$ApiBase = $ApiBase.TrimEnd('/')

# Resolve TopK default
if ($TopK -lt 0) { $TopK = if ($Mode -eq 'TRAKE') { 100 } else { 20 } }

# --- Resolve events for TRAKE ------------------------------------------------
$resolvedEvents = @()
if ($Mode -eq 'TRAKE') {
    if ($Events.Count -gt 0) {
        $resolvedEvents = $Events
    } elseif ($EventList -ne '') {
        $resolvedEvents = $EventList -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
    } elseif ($Query -match '\|') {
        $resolvedEvents = $Query -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        $Query = ''   # consumed into events
    }

    if ($resolvedEvents.Count -eq 0) {
        $raw = Read-Host 'Enter pipe-separated events (e.g. enters|sits|leaves)'
        $resolvedEvents = $raw -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
    }
}

# --- Interactive prompts (non-TRAKE) -----------------------------------------
if ($Query -eq '' -and $Mode -ne 'TRAKE') {
    $Query = Read-Host "[$Mode] Enter search query"
}
if ($Mode -eq 'VQA' -and $Question -eq '') {
    $Question = Read-Host '[VQA] Enter question'
}

# --- Header ------------------------------------------------------------------
switch ($Mode) {
    'KIS'   { Write-Info "[KIS]   Searching for: $Query  (top $TopK)" }
    'VQA'   { Write-Info "[VQA]   Context: $Query | Question: $Question  (top $TopK)" }
    'TRAKE' { Write-Info "[TRAKE] Events: $($resolvedEvents -join ' -> ')  (top $TopK)" }
}

# --- Build request body ------------------------------------------------------
$body = @{ type = $Mode.ToUpper(); top_k = $TopK }
switch ($Mode) {
    'KIS'   { $body['query']  = $Query }
    'VQA'   { $body['query']  = $Query; $body['question'] = $Question }
    'TRAKE' { $body['events'] = $resolvedEvents }
}

# --- Call backend ------------------------------------------------------------
$response = Invoke-BackendSearch -Base $ApiBase -Body $body

# --- Output ------------------------------------------------------------------
if ($Json) {
    $response | ConvertTo-Json -Depth 8
} else {
    $results = if ($response.PSObject.Properties['results']) { $response.results } else { @() }
    if (-not $results -or $results.Count -eq 0) {
        Write-Warn 'No results returned. Is the backend running?'
    } else {
        Write-Ok "`n  $($results.Count) result(s) found`n"
        Format-ResultTable -Results $results -SearchMode $Mode -Base $ApiBase
    }
}

Show-Timing -Response $response

<#
--- USAGE EXAMPLES -------------------------------------------------------------

  KIS - Known-Item Search:
    .\search.ps1 "a dog running on the beach"
    .\search.ps1 -Mode KIS -Query "sunset over water" -TopK 5 -Json

  VQA - Visual Question Answering:
    .\search.ps1 -Mode VQA -Query "kitchen scene" -Question "How many people are there?"
    .\search.ps1 -Mode VQA -q "outdoor market" -Q "What is being sold?" -TopK 10

  TRAKE - Temporal Event Sequence:
    .\search.ps1 -Mode TRAKE "enters|sits down|stands up|leaves"
    .\search.ps1 -Mode TRAKE -Events "opens door","walks in","closes door"
    .\search.ps1 -Mode TRAKE -EventList "enters|sits|leaves" -TopK 50

  General:
    .\search.ps1 -Help
    .\search.ps1 -Mode KIS -Query "mountain landscape" -ApiBase http://myserver:8000

--------------------------------------------------------------------------------
#>
