import json
from functools import lru_cache
from pathlib import Path

from app.core.config import settings


@lru_cache(maxsize=512)
def _get_detections_cached(root_path: str, video_id: str, keyframe_id: int) -> tuple:
    root = Path(root_path)
    json_path = root / video_id / f"{keyframe_id:03d}.json"

    if not json_path.is_file():
        return ()

    with json_path.open("r", encoding="utf-8") as file:
        data = json.load(file)

    detections = []

    for score, label, box in zip(
        data.get("detection_scores", []),
        data.get("detection_class_entities", []),
        data.get("detection_boxes", []),
    ):
        detections.append({
            "label": str(label).strip().lower(),
            "score": float(score),
            "box": [float(value) for value in box],
        })

    return tuple(detections)


CLASS_ENTITY_ALIASES: dict[str, tuple[str, ...]] = {
    "person": ("person", "man", "woman", "human", "child", "boy", "girl", "people"),
    "car": ("car", "vehicle", "land vehicle", "automobile"),
    "bus": ("bus", "vehicle", "land vehicle"),
    "truck": ("truck", "vehicle", "land vehicle"),
    "motorbike": ("motorcycle", "motorbike", "vehicle", "land vehicle"),
    "bicycle": ("bicycle", "bike", "vehicle", "land vehicle"),
    "dog": ("dog", "mammal", "animal", "carnivore"),
    "cat": ("cat", "mammal", "animal", "carnivore", "feline"),
    "chair": ("chair", "furniture", "couch", "sofa"),
    "table": ("table", "desk", "coffee table", "furniture"),
    "bottle": ("bottle", "drink", "beverage", "water bottle"),
    "cup": ("cup", "mug", "drink", "coffee cup", "beverage"),
    "phone": ("mobile phone", "cell phone", "telephone", "phone", "electronics"),
    "building": ("building", "skyscraper", "tower", "house"),
    "tree": ("tree", "palm tree", "plant"),
}


class ObjectStore:
    def __init__(self, objects_dir: Path | str | None = None) -> None:
        self.objects_dir = Path(objects_dir or settings.OBJECT_ROOT)

    def get_detections(self, video_id: str, keyframe_id: int) -> list[dict]:
        raw = _get_detections_cached(str(self.objects_dir), video_id, keyframe_id)
        return list(raw)

    def clear_cache(self) -> None:
        """Clear the LRU cache to prevent memory leaks."""
        _get_detections_cached.cache_clear()  # type: ignore[attr-defined]

    def find_by_class(
        self,
        video_id: str,
        keyframe_id: int,
        target_class: str,
        threshold: float = 0.5,
    ) -> list[dict]:
        normalized_target = target_class.strip().lower()
        aliases = CLASS_ENTITY_ALIASES.get(normalized_target, (normalized_target,))

        return [
            detection
            for detection in self.get_detections(video_id, keyframe_id)
            if any(alias in detection["label"] or detection["label"] in alias for alias in aliases)
            and detection["score"] >= threshold
        ]

    def count_with_uncertainty(
        self,
        video_id: str,
        keyframe_id: int,
        target_class: str,
        high_threshold: float = 0.55,
        mid_threshold: float = 0.35,
        iou_threshold: float = 0.45,
    ) -> dict:
        """Evaluate counting certainty vs uncertainty across confidence thresholds."""
        high_conf_boxes = self.count_by_class(
            video_id, keyframe_id, target_class, threshold=high_threshold, iou_threshold=iou_threshold
        )
        mid_conf_boxes = self.count_by_class(
            video_id, keyframe_id, target_class, threshold=mid_threshold, iou_threshold=iou_threshold
        )

        n_high = len(high_conf_boxes)
        n_mid = len(mid_conf_boxes)
        volatility = abs(n_high - n_mid)
        mean_conf = (
            sum(b["score"] for b in high_conf_boxes) / n_high if n_high > 0 else 0.0
        )

        reasons: list[str] = []
        if n_mid >= 8:
            reasons.append("dense_crowd")
        if volatility >= 2:
            reasons.append("high_threshold_volatility")
        if n_high > 0 and mean_conf < 0.60:
            reasons.append("low_mean_confidence")

        uncertainty_level = "low"
        if len(reasons) == 1:
            uncertainty_level = "medium"
        elif len(reasons) >= 2:
            uncertainty_level = "high"

        should_use_vlm = uncertainty_level in ("medium", "high")

        return {
            "count": n_high if n_high > 0 else n_mid,
            "high_conf_count": n_high,
            "mid_conf_count": n_mid,
            "mean_confidence": round(mean_conf, 3),
            "bboxes": high_conf_boxes or mid_conf_boxes,
            "uncertainty_level": uncertainty_level,
            "should_use_vlm": should_use_vlm,
            "fallback_reasons": reasons,
        }

    def count_with_confidence(
        self,
        video_id: str,
        keyframe_id: int,
        target_class: str,
        threshold: float = 0.4,
    ) -> dict:
        return self.count_with_uncertainty(video_id, keyframe_id, target_class, high_threshold=threshold, mid_threshold=0.3)

    @staticmethod
    def _iou(box_a: list[float], box_b: list[float]) -> float:
        # Boxes are [ymin, xmin, ymax, xmax].
        top = max(box_a[0], box_b[0])
        left = max(box_a[1], box_b[1])
        bottom = min(box_a[2], box_b[2])
        right = min(box_a[3], box_b[3])

        intersection_height = max(0.0, bottom - top)
        intersection_width = max(0.0, right - left)
        intersection = intersection_height * intersection_width

        area_a = max(0.0, box_a[2] - box_a[0]) * max(0.0, box_a[3] - box_a[1])
        area_b = max(0.0, box_b[2] - box_b[0]) * max(0.0, box_b[3] - box_b[1])

        union = area_a + area_b - intersection
        return intersection / union if union > 0 else 0.0

    def count_by_class(
        self,
        video_id: str,
        keyframe_id: int,
        target_class: str,
        threshold: float = 0.5,
        iou_threshold: float = 0.5,
    ) -> list[dict]:
        candidates = self.find_by_class(
            video_id,
            keyframe_id,
            target_class,
            threshold,
        )

        # Keep the highest-confidence box; discard overlapping duplicates.
        selected: list[dict] = []

        for detection in sorted(
            candidates,
            key=lambda detection: detection["score"],
            reverse=True,
        ):
            if all(
                self._iou(detection["box"], kept["box"]) < iou_threshold
                for kept in selected
            ):
                selected.append(detection)

        return selected


object_store = ObjectStore()
