<#
.SYNOPSIS
    Packages the project into a self-installing ZIP for distribution.
.DESCRIPTION
    Creates AIC2026_Backend_<version>.zip that clients can extract and
    run setup.bat to install everything automatically.
    
    What gets included:
      - app/            (all backend source code, with patches)
      - scripts/        (helper scripts)
      - main.py, build_index.py, requirements.txt
      - .env.example    (client copies this to .env and adds their API key)
      - setup.ps1       (applies tqdm hotfix + env setup, called by install.ps1)
      - install.ps1     (full one-shot installer)
      - setup.bat       (double-click entry point for clients)
      - start.bat       (start the server, supports --reset flag)
      - search.ps1      (CLI search tool)
      - GUIDE.md        (documentation)
    
    What gets excluded:
      - .venv/          (clients build their own)
      - static/         (keyframes - too large, clients bring their own data)
      - data/           (local FAISS index files)
      - submission/     (local output)
      - error_log.txt   (local debug file)
      - __pycache__/
      - *.zip           (previous packages)
.EXAMPLE
    .\package_for_release.ps1
    .\package_for_release.ps1 -Version "2.1.0"
#>
param(
    [string]$Version = (Get-Date -Format "yyyyMMdd")
)

$ErrorActionPreference = 'Stop'
$root    = $PSScriptRoot
$distName = "AIC2026_Backend_$Version.zip"
$outPath  = Join-Path $root $distName

# Remove old package if exists
if (Test-Path $outPath) {
    Remove-Item $outPath -Force
    Write-Host "  Removed old: $distName" -ForegroundColor Gray
}

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  AIC 2026 Backend - Packaging for Release  " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Output : $outPath" -ForegroundColor Gray
Write-Host ""

# ── Files & folders to include ───────────────────────────────────────────────
$includeItems = @(
    "app",
    "scripts",
    "main.py",
    "build_index.py",
    "requirements.txt",
    ".env.example",
    "setup.ps1",
    "install.ps1",
    "setup.bat",
    "start.bat",
    "ingest.ps1",
    "test.ps1",
    "package_for_release.ps1",
    "search.ps1",
    "search_common.ps1",
    "search_kis.ps1",
    "search_vqa.ps1",
    "search_trake.ps1",
    "GUIDE.md",
    "PROJECT_INFRASTRUCTURE_MAP.md",
    "AIC2026_REQUIREMENTS_ANALYSIS.md",
    "docker-compose.yml",
    "Dockerfile"
)

# ── Clean __pycache__ before packaging ───────────────────────────────────────
Write-Host "  Cleaning temporary cache files..." -ForegroundColor Gray
Get-ChildItem -Path $root -Recurse -Filter "__pycache__" -Directory -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem -Path $root -Recurse -Filter "*.pyc" -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue

# ── Collect items ─────────────────────────────────────────────────────────────
$toPackage = @()
foreach ($item in $includeItems) {
    $fullPath = Join-Path $root $item
    if (Test-Path $fullPath) {
        $toPackage += $fullPath
        Write-Host "  + $item" -ForegroundColor Green
    } else {
        Write-Host "  ! MISSING (skipped): $item" -ForegroundColor Yellow
    }
}

# ── Create the ZIP ────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  Compressing..." -ForegroundColor Cyan
Compress-Archive -Path $toPackage -DestinationPath $outPath -Force

# ── Report ────────────────────────────────────────────────────────────────────
$sizeMB = [math]::Round((Get-Item $outPath).Length / 1MB, 2)
Write-Host ""
Write-Host "=============================================" -ForegroundColor Green
Write-Host "  Done! Package created:" -ForegroundColor Green
Write-Host "  $outPath ($sizeMB MB)" -ForegroundColor White
Write-Host "=============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Client instructions:" -ForegroundColor Yellow
Write-Host "   1. Extract the ZIP anywhere" -ForegroundColor Gray
Write-Host "   2. Copy .env.example to .env and add your GEMINI_API_KEY" -ForegroundColor Gray
Write-Host "   3. Place their keyframes in static\keyframes\" -ForegroundColor Gray
Write-Host "   4. Double-click setup.bat (or run .\install.ps1)" -ForegroundColor Gray
Write-Host "   5. Double-click start.bat to launch the server" -ForegroundColor Gray
Write-Host ""

