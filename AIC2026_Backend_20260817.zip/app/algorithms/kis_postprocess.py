"""Post-retrieval KIS reranking using Objects JSON and media-info keywords."""

from __future__ import annotations

import re
from dataclasses import dataclass

from app.core.config import settings
from app.services.media_info_store import media_info_store
from app.services.object_store import object_store

OBJECT_ALIASES: dict[str, tuple[str, ...]] = {
    "person": ("person", "people", "human", "man", "woman", "child", "nguoi", "người"),
    "car": ("car", "cars", "automobile", "vehicle", "xe", "xe hoi", "xe hơi"),
    "dog": ("dog", "dogs", "puppy", "cho", "chó"),
    "cat": ("cat", "cats", "kitten", "meo", "mèo"),
    "cup": ("cup", "mug", "glass", "coc", "cốc"),
    "bottle": ("bottle", "bottles", "chai"),
    "chair": ("chair", "chairs", "ghe", "ghế"),
    "table": ("table", "tables", "ban", "bàn"),
    "phone": ("phone", "mobile", "cellphone", "dien thoai", "điện thoại"),
    "bicycle": ("bicycle", "bike", "xe dap", "xe đạp"),
    "bus": ("bus", "xe buyt", "xe buýt"),
    "motorbike": ("motorbike", "motorcycle", "xe may", "xe máy"),
}


@dataclass(frozen=True)
class ObjectConstraint:
    target_class: str
    min_count: int = 1


_COUNT_PATTERN = re.compile(
    r"\b(\d+)\s+(cars?|people|persons?|dogs?|cats?|cups?|bottles?|"
    r"chairs?|tables?|phones?|bicycles?|bikes?|buses?|motorbikes?)\b",
    re.IGNORECASE,
)


def parse_object_constraints(query: str) -> list[ObjectConstraint]:
    normalized = query.casefold()
    constraints: list[ObjectConstraint] = []

    for match in _COUNT_PATTERN.finditer(normalized):
        count = int(match.group(1))
        label = match.group(2)
        target = _normalize_object_label(label)
        if target:
            constraints.append(ObjectConstraint(target_class=target, min_count=count))

    if constraints:
        return constraints

    for target_class, aliases in OBJECT_ALIASES.items():
        if any(re.search(rf"\b{re.escape(alias)}\b", normalized) for alias in aliases):
            constraints.append(ObjectConstraint(target_class=target_class, min_count=1))

    return constraints


def _normalize_object_label(label: str) -> str | None:
    token = label.casefold().strip()
    for target_class, aliases in OBJECT_ALIASES.items():
        if token in aliases or token.rstrip("s") in aliases:
            return target_class
    return None


def _object_boost(result: dict, constraints: list[ObjectConstraint]) -> float:
    if not constraints:
        return 0.0

    video_id = str(result["video_id"])
    keyframe_id = int(result.get("keyframe_id", result["frame_id"]))
    boost = 0.0

    for constraint in constraints:
        count = len(
            object_store.count_by_class(
                video_id,
                keyframe_id,
                constraint.target_class,
            )
        )
        if count >= constraint.min_count:
            boost += 0.05 * constraint.min_count
            if count == constraint.min_count:
                boost += 0.02
        else:
            boost -= 0.08

    return boost


def rerank_kis_by_objects(query: str, results: list[dict]) -> list[dict]:
    if not settings.KIS_OBJECT_RERANK_ENABLED or not results:
        return results

    constraints = parse_object_constraints(query)
    if not constraints:
        return results

    reranked: list[dict] = []
    for item in results:
        copy = dict(item)
        object_boost = _object_boost(copy, constraints)
        copy["object_boost"] = round(object_boost, 6)
        new_score = round(float(copy.get("score", 0.0)) + object_boost, 6)
        copy["score"] = new_score
        # Keep r_score in sync so sort order is consistent with score
        copy["r_score"] = new_score
        reranked.append(copy)

    reranked.sort(key=lambda row: (
        -float(row.get("score", 0.0)),
        int(row.get("rank", 999))
    ))
    for rank, item in enumerate(reranked, start=1):
        item["rank"] = rank
    return reranked


def rerank_kis_by_media_info(query: str, results: list[dict]) -> list[dict]:
    if not settings.KIS_MEDIA_INFO_RERANK_ENABLED or not results:
        return results

    reranked: list[dict] = []
    for item in results:
        copy = dict(item)
        media_boost = round(
            media_info_store.keyword_score(str(copy["video_id"]), query)
            * settings.KIS_MEDIA_INFO_RERANK_WEIGHT,
            6,
        )
        copy["media_boost"] = media_boost
        new_score = round(float(copy.get("score", 0.0)) + media_boost, 6)
        copy["score"] = new_score
        # Keep r_score in sync so sort order is consistent with score
        copy["r_score"] = new_score
        reranked.append(copy)

    reranked.sort(key=lambda row: (
        -float(row.get("score", 0.0)),
        int(row.get("rank", 999))
    ))
    for rank, item in enumerate(reranked, start=1):
        item["rank"] = rank
    return reranked
