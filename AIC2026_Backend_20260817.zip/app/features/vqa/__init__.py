"""VQA use-case layer (person-count heuristics + VLM fallback)."""

from app.features.vqa.service import answer_vqa_question, is_person_count_question

__all__ = ["answer_vqa_question", "is_person_count_question"]
