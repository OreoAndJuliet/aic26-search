"""VQA orchestration: Faster R-CNN JSON first, VLM when uncertain."""

from __future__ import annotations

import time

from app.core.config import settings
from app.services.object_store import object_store
from app.services.vqa_engine import vqa_engine
from app.utils.keyframes import keyframe_image_path
from app.utils.vqa_answer import build_vqa_prompt

COUNT_WORDS = ("how many", "number of", "bao nhiêu", "bao nhieu", "số lượng")
PERSON_WORDS = ("person", "people", "human", "người", "nguoi")


def is_person_count_question(question: str) -> bool:
    normalized = question.casefold()
    return (
        any(word in normalized for word in COUNT_WORDS)
        and any(word in normalized for word in PERSON_WORDS)
    )


def _answer_person_count(top_kis_results: list[dict]) -> tuple[list[dict], float]:
    if not top_kis_results:
        return [], 0.0

    vlm_started_at = time.perf_counter()
    processed_results: list[dict] = []
    
    for result in top_kis_results:
        candidate = result.copy()
        keyframe_id = int(candidate.get("keyframe_id", candidate["frame_id"]))
        json_result = object_store.count_with_confidence(
            candidate["video_id"],
            keyframe_id,
            "person",
        )

        candidate["json_count"] = json_result["count"]
        candidate["json_bboxes"] = json_result["bboxes"]
        candidate["fallback_reasons"] = json_result["fallback_reasons"]

        if json_result["should_use_vlm"]:
            image_path = keyframe_image_path(
                candidate["video_id"],
                keyframe_id,
                keyframes_dir=settings.KEYFRAMES_DIR,
            )
            vlm_raw_log = vqa_engine.answer_single_image(
                image_path,
                build_vqa_prompt("Count the visible people."),
            )
            candidate["answer"] = vlm_raw_log[:100]
            candidate["source"] = "VLM_API"
            candidate["vlm_raw_log"] = vlm_raw_log
        else:
            candidate["answer"] = str(json_result["count"])
            candidate["source"] = "FASTER_RCNN_JSON"
            candidate["vlm_raw_log"] = ""

        processed_results.append(candidate)

    vlm_time_ms = round((time.perf_counter() - vlm_started_at) * 1000, 2)
    return processed_results, vlm_time_ms


def answer_vqa_question(
    top_kis_results: list[dict],
    question: str,
) -> tuple[list[dict], float]:
    """Answer a VQA query from KIS-ranked keyframe candidates."""
    if is_person_count_question(question):
        return _answer_person_count(top_kis_results)

    vlm_started_at = time.perf_counter()
    results = vqa_engine.answer(top_kis_results, question)
    vlm_time_ms = round((time.perf_counter() - vlm_started_at) * 1000, 2)
    return results, vlm_time_ms
