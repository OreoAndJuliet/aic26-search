"""Shared KIS retrieval helpers used by unified search and legacy KIS endpoint."""

from __future__ import annotations

import logging

from app.algorithms.crop_alignment import apply_crop_clip_alignment
from app.algorithms.diversification import apply_intra_video_diversification
from app.algorithms.hybrid_ranking import rerank_hybrid_results
from app.algorithms.kis_postprocess import (
    rerank_kis_by_media_info,
    rerank_kis_by_objects,
)
from app.algorithms.temporal_smoothing import apply_temporal_smoothing
from app.core.config import settings
from app.features.search.enrichment import attach_media_info
from app.services.kis_engine import kis_engine
from app.services.kis_rscore import build_rscore_report

logger = logging.getLogger(__name__)


def run_kis_retrieval(
    translated_text: str,
    top_k: int,
) -> tuple[list[dict], dict[str, float | dict | None]]:
    """Translate-ready text → FAISS hits with stage timings and rscore report."""
    results, retrieval_metrics = kis_engine.search_with_metrics(translated_text, top_k)
    results = rerank_kis_by_objects(translated_text, results)
    results = rerank_kis_by_media_info(translated_text, results)
    results = attach_media_info(results)
    results = rerank_hybrid_results(translated_text, results, task_type="KIS")
    results = apply_temporal_smoothing(results)

    # Crop-Level Regional CLIP Alignment
    if settings.KIS_CROP_ALIGNMENT_ENABLED and results:
        try:
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = apply_crop_clip_alignment(
                results,
                query_vector,
                kis_engine.text_encoder,
                keyframes_dir=settings.KEYFRAMES_DIR,
                objects_dir=settings.OBJECT_ROOT,
                weight=settings.KIS_CROP_ALIGNMENT_WEIGHT,
                top_k_eval=settings.KIS_CROP_ALIGNMENT_TOPK,
            )
        except Exception as exc:
            logger.warning("crop_clip_alignment_failed: %s", exc)

    # Multi-Scale Spatial Quadrant RoI Max-Pooling for Small Objects
    try:
        from app.algorithms.spatial_roi_pooling import (
            apply_spatial_quadrant_roi_pooling,
            should_apply_spatial_roi_pooling,
        )
        if should_apply_spatial_roi_pooling(translated_text) and results:
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = apply_spatial_quadrant_roi_pooling(
                results,
                query_vector,
                kis_engine.text_encoder,
                keyframes_dir=settings.KEYFRAMES_DIR,
                top_k_eval=5,
                roi_weight=0.20,
            )
    except Exception as exc:
        logger.debug("spatial_roi_pooling_failed: %s", exc)

    # Negative Constraint Penalty
    try:
        from app.algorithms.negative_projection import extract_negative_constraint
        has_neg, pos_text, neg_text = extract_negative_constraint(translated_text)
        if has_neg and neg_text and results:
            v_neg = kis_engine.encode_query_vector(neg_text)
            norm_neg = np.linalg.norm(v_neg)
            if norm_neg > 0:
                v_neg = v_neg / norm_neg
                # Check top candidates and penalize those matching the negative concept
                for r in results[:10]:
                    v_id = str(r.get("video_id", ""))
                    f_id = int(r.get("keyframe_id", r.get("frame_id", 1)))
                    # Use store image vector or metadata vector if available
                    cand_vec = kis_engine.store.vector_for_frame(v_id, f_id) if hasattr(kis_engine.store, "vector_for_frame") else None
                    if cand_vec is not None:
                        neg_sim = float(np.dot(cand_vec, v_neg))
                        if neg_sim > 0.40:
                            base_s = float(r.get("score", r.get("r_score", 0.0)))
                            r["score"] = max(0.0, base_s - (0.25 * neg_sim))
                            r["r_score"] = r["score"]
                            r["negative_penalty"] = round(0.25 * neg_sim, 3)
                results.sort(key=lambda x: x.get("score", x.get("r_score", 0.0)), reverse=True)
    except Exception as exc:
        logger.debug("negative_penalty_failed: %s", exc)

    # Object Class + HSV Color Co-Occurrence Reranking
    try:
        from app.algorithms.color_object_reranker import rerank_by_color_object_cooccurrence
        results = rerank_by_color_object_cooccurrence(
            results,
            translated_text,
            keyframes_dir=settings.KEYFRAMES_DIR,
            objects_dir=settings.OBJECT_ROOT,
            boost_weight=0.25,
            top_k_eval=15,
        )
    except Exception as exc:
        logger.debug("color_object_rerank_failed: %s", exc)

    results = apply_intra_video_diversification(results)

    # Optional cross-encoder style rescoring (lightweight proxy using image embeddings)
    try:
        from app.algorithms.cross_encoder import rescore_top_k
    except ImportError:
        rescore_top_k = None

    if rescore_top_k is not None and settings.CROSS_ENCODER_ENABLED and results:
        try:
            # encode once (use cached) to get the query vector used earlier
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = rescore_top_k(query_vector, results, kis_engine.store)
        except (RuntimeError, ValueError, OSError) as exc:
            # Rescoring failure must not break retrieval — log exception details and continue
            logger.warning("cross_encoder_rescore_failed: %s", exc)

    retrieval_time_ms = round(
        retrieval_metrics["embedding_time_ms"]
        + retrieval_metrics["faiss_time_ms"]
        + retrieval_metrics["metadata_time_ms"],
        2,
    )
    metrics: dict[str, float | dict | None] = {
        **retrieval_metrics,
        "retrieval_time_ms": retrieval_time_ms,
        "vlm_time_ms": 0.0,
        "rscore": build_rscore_report(results),
    }
    return results, metrics
