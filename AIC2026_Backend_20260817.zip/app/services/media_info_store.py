import json
from functools import lru_cache
from pathlib import Path

from app.core.config import settings


@lru_cache(maxsize=512)
def _get_media_info_cached(root_path: str, video_id: str) -> dict | None:
    root = Path(root_path)
    candidates = [
        root / "media-info" / f"{video_id}.json",
        root / f"{video_id}.json",
    ]
    for path in candidates:
        if path.is_file():
            with path.open("r", encoding="utf-8") as file:
                return json.load(file)
    return None


class MediaInfoStore:
    """Loads optional YouTube metadata JSON per video (L01_V001.json)."""

    def __init__(self, root: Path | str | None = None) -> None:
        self.root = Path(root or settings.MEDIA_INFO_ROOT)

    def _resolve_path(self, video_id: str) -> Path | None:
        candidates = [
            self.root / "media-info" / f"{video_id}.json",
            self.root / f"{video_id}.json",
        ]
        for path in candidates:
            if path.is_file():
                return path
        return None

    def get(self, video_id: str) -> dict | None:
        # Delegate to module-level cached function to avoid applying lru_cache to instance methods
        return _get_media_info_cached(str(self.root), video_id)

    def clear_cache(self) -> None:
        """Clear the LRU cache to prevent memory leaks."""
        _get_media_info_cached.cache_clear()  # type: ignore[attr-defined]

    def keyword_score(self, video_id: str, query: str) -> float:
        """Return 0-1 score when query terms appear in title/description/tags."""
        info = self.get(video_id)
        if not info:
            return 0.0

        haystack_parts = [
            str(info.get("title", "")),
            str(info.get("description", "")),
            str(info.get("author", "")),
            str(info.get("channelTitle", "")),
        ]
        tags = info.get("tags")
        if isinstance(tags, list):
            haystack_parts.extend(str(tag) for tag in tags)
        haystack = " ".join(haystack_parts).casefold()

        terms = [term for term in query.casefold().split() if len(term) >= 3]
        if not terms:
            return 0.0

        hits = sum(1 for term in terms if term in haystack)
        return hits / len(terms)


media_info_store = MediaInfoStore()
