"""Parse and normalize VQA answers from VLM providers."""

from __future__ import annotations

import json
import re
from typing import Any

MAX_VQA_ANSWER_LENGTH = 100


def build_vqa_prompt(question: str) -> str:
    """Build optimized VQA prompt for better answer quality and consistency."""
    
    # Question-specific prompt optimization
    question_lower = question.lower()
    
    # Count questions
    if any(word in question_lower for word in ["how many", "number of", "count", "quantity"]):
        return (
            "Answer using only the image. Count the objects accurately. "
            "Return JSON only in this exact shape: "
            '{"answer": "<number> or \"0\" if none"}. '
            "Be precise - return only the number as a string. "
            f"Question: {question.strip()}"
        )
    
    # Color questions
    if any(word in question_lower for word in ["color", "colour", "what color"]):
        return (
            "Answer using only the image. Identify the primary color accurately. "
            "Return JSON only in this exact shape: "
            '{"answer": "<color name>"}. '
            "Use standard color names (red, blue, green, etc.). "
            f"Question: {question.strip()}"
        )
    
    # Location questions
    if any(word in question_lower for word in ["where", "located", "position"]):
        return (
            "Answer using only the image. Describe the location concisely. "
            "Return JSON only in this exact shape: "
            '{"answer": "<location description>"}. '
            "Keep it brief (under 50 characters). "
            f"Question: {question.strip()}"
        )
    
    # Yes/No questions
    if any(word in question_lower for word in ["is", "are", "do", "does", "can", "will", "would"]):
        return (
            "Answer using only the image. Provide a yes or no answer. "
            "Return JSON only in this exact shape: "
            '{"answer": "yes" or "no"}. '
            "Answer strictly yes or no based on the image. "
            f"Question: {question.strip()}"
        )
    
    # General action/object questions
    return (
        "Answer using only the image. Provide a concise, accurate answer. "
        "Return JSON only in this exact shape: "
        '{"answer": "<short answer>"}. '
        "Keep the answer short and suitable for CSV export (max 100 characters). "
        "Focus on the most relevant information. "
        f"Question: {question.strip()}"
    )


def _strip_code_fence(text: str) -> str:
    cleaned = text.strip()
    cleaned = re.sub(r"^\s*```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```\s*$", "", cleaned)
    return cleaned.strip()


def _extract_answer_from_json(payload: Any) -> str | None:
    if isinstance(payload, dict):
        for key in ("answer", "response", "text", "result"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, dict):
                extracted = _extract_answer_from_json(value)
                if extracted:
                    return extracted
        return None

    if isinstance(payload, list):
        for item in payload:
            extracted = _extract_answer_from_json(item)
            if extracted:
                return extracted
    return None


def parse_vqa_answer(raw_text: str, *, max_length: int = MAX_VQA_ANSWER_LENGTH) -> str:
    """Parse provider output as JSON when possible, otherwise use plain text."""
    text = _strip_code_fence(raw_text)
    if not text:
        return ""

    try:
        payload = json.loads(text)
        extracted = _extract_answer_from_json(payload)
        if extracted:
            text = extracted
    except json.JSONDecodeError:
        pass

    normalized = " ".join(text.split())
    if len(normalized) <= max_length:
        return normalized
    return normalized[:max_length].rstrip()
