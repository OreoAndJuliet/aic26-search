"""One place to warm up shared engines before serving requests or batch jobs."""

from __future__ import annotations

import logging

from app.core.config import settings
from app.services.kis_engine import kis_engine
from app.services.zip_ingest import zip_ingest_service

logger = logging.getLogger(__name__)


def initialize_engines() -> None:
    """Ingest inbox zips, then load FAISS index, metadata, and CLIP encoder."""
    if settings.ZIP_INGEST_ENABLED:
        results = zip_ingest_service.ingest_inbox()
        if results:
            logger.info("zip_ingest processed %s archive(s) at startup", len(results))

    kis_engine.initialize()
