@echo off
setlocal enabledelayedexpansion
powershell -ExecutionPolicy Bypass -File "%~dp0start.ps1"
if %errorlevel% neq 0 (
    echo Server process ended with code %errorlevel%.
    pause
)
