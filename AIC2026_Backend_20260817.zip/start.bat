@echo off
echo ===================================================
echo     AIC 2026 Backend - Starting Server
echo ===================================================
echo.

if "%1"=="--reset" (
    echo [INFO] Reset option detected. Searching for ghost processes on port 8000...
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000 ^| findstr LISTENING') do (
        echo [INFO] Killing ghost process PID: %%a
        taskkill /f /pid %%a >nul 2>&1
    )
    echo.
)

if not exist "%~dp0.venv\Scripts\uvicorn.exe" (
    echo Error: Virtual environment not found. Please run setup.bat first!
    pause
    exit /b 1
)
"%~dp0.venv\Scripts\uvicorn.exe" main:app --host 0.0.0.0 --port 8000
pause
