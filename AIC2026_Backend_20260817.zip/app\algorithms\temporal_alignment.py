"""Temporal alignment for TRAKE multi-event retrieval."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class EventCandidate:
    video_id: str
    frame_id: int
    timestamp: float
    score: float
    event_index: int
    event_text: str
    payload: dict[str, Any]


def build_event_candidates(
    *,
    event_texts: list[str],
    kis_results_per_event: list[list[dict[str, Any]]],
) -> list[list[EventCandidate]]:
    layers: list[list[EventCandidate]] = []
    for event_index, (event_text, results) in enumerate(
        zip(event_texts, kis_results_per_event, strict=True)
    ):
        layer: list[EventCandidate] = []
        for result in results:
            layer.append(
                EventCandidate(
                    video_id=str(result["video_id"]),
                    frame_id=int(result["frame_id"]),
                    timestamp=float(result["timestamp"]),
                    score=float(result.get("score", result.get("r_score", 0.0))),
                    event_index=event_index,
                    event_text=event_text,
                    payload=result,
                )
            )
        layers.append(layer)
    return layers


def _is_temporally_after(left: EventCandidate, right: EventCandidate) -> bool:
    if left.timestamp != right.timestamp:
        return left.timestamp < right.timestamp
    return left.frame_id < right.frame_id


def _dp_best_path(layers: list[list[EventCandidate]], max_gap_seconds: float = 300.0) -> tuple[list[EventCandidate], float]:
    """Best increasing-time path through one video's candidate layers with temporal gap constraint."""
    if not layers or any(not layer for layer in layers):
        return [], float("-inf")

    best_scores: list[list[float]] = []
    backpointers: list[list[int | None]] = []

    first_layer = layers[0]
    best_scores.append([candidate.score for candidate in first_layer])
    backpointers.append([None] * len(first_layer))

    for layer_index in range(1, len(layers)):
        previous_layer = layers[layer_index - 1]
        current_layer = layers[layer_index]
        layer_scores: list[float] = []
        layer_backpointers: list[int | None] = []

        for current_index, current in enumerate(current_layer):
            best_prev_score = float("-inf")
            best_prev_index: int | None = None

            for previous_index, previous in enumerate(previous_layer):
                if not _is_temporally_after(previous, current):
                    continue
                
                # Calculate temporal gap
                temporal_gap = current.timestamp - previous.timestamp
                
                # Apply gap penalty - larger gaps reduce score; no bonus for small gaps
                if temporal_gap > max_gap_seconds:
                    gap_penalty = (temporal_gap - max_gap_seconds) * 0.01  # Linear penalty for large gaps
                else:
                    gap_penalty = 0.0

                previous_score = best_scores[layer_index - 1][previous_index]
                adjusted_score = previous_score + current.score - gap_penalty
                
                if adjusted_score > best_prev_score:
                    best_prev_score = adjusted_score
                    best_prev_index = previous_index

            if best_prev_index is None:
                layer_scores.append(float("-inf"))
                layer_backpointers.append(None)
            else:
                layer_scores.append(best_prev_score)
                layer_backpointers.append(best_prev_index)

        best_scores.append(layer_scores)
        backpointers.append(layer_backpointers)

    final_layer_scores = best_scores[-1]
    best_final_index = max(range(len(final_layer_scores)), key=final_layer_scores.__getitem__)
    if final_layer_scores[best_final_index] == float("-inf"):
        return [], float("-inf")

    path_indices: list[int] = [best_final_index]
    for layer_index in range(len(layers) - 1, 0, -1):
        previous_index = backpointers[layer_index][path_indices[-1]]
        if previous_index is None:
            return [], float("-inf")
        path_indices.append(previous_index)
    path_indices.reverse()

    path = [layers[layer_index][path_indices[layer_index]] for layer_index in range(len(layers))]
    return path, final_layer_scores[best_final_index]


def align_events_dtw(event_layers: list[list[EventCandidate]], max_gap_seconds: float = 300.0) -> tuple[list[EventCandidate], float] | None:
    """Pick one candidate per event on the same video with strictly increasing time.

    The search is a layered dynamic program over event candidates. This is the
    constrained DTW lattice used for TRAKE: each event contributes one frame and
    transitions are only allowed forward in time within the same video.
    
    Args:
        event_layers: List of candidate layers for each event
        max_gap_seconds: Maximum allowed temporal gap between consecutive events (default: 300s)
                        Larger gaps are penalized rather than rejected completely.
    """
    if not event_layers:
        return None

    # Edge case: empty layers
    if any(not layer for layer in event_layers):
        return None

    video_ids = {candidate.video_id for layer in event_layers for candidate in layer}
    best_path: list[EventCandidate] | None = None
    best_score = float("-inf")

    # Performance optimization: sort candidates by score to improve early pruning.
    # Use sorted() to avoid mutating the caller's input lists in-place.
    event_layers = [sorted(layer, key=lambda x: x.score, reverse=True) for layer in event_layers]

    for video_id in video_ids:
        per_video_layers: list[list[EventCandidate]] = []
        for layer in event_layers:
            filtered = [candidate for candidate in layer if candidate.video_id == video_id]
            if not filtered:
                per_video_layers = []
                break
            per_video_layers.append(filtered)

        if not per_video_layers:
            continue

        path, score = _dp_best_path(per_video_layers, max_gap_seconds)
        if path and score > best_score:
            best_score = score
            best_path = path

    if best_path is None:
        return None

    return best_path, best_score
