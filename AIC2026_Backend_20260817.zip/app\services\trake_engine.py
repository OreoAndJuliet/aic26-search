"""TRAKE engine: multi-event KIS retrieval with temporal alignment."""

from __future__ import annotations

import logging
from typing import Any

from app.algorithms.temporal_alignment import align_events_dtw, build_event_candidates
from app.core.config import settings
from app.core.exceptions import RetrievalUnavailableError
from app.services.kis_engine import kis_engine

logger = logging.getLogger(__name__)


class TRAKEEngine:
    def align_events(
        self,
        english_events: list[str],
        *,
        top_k_per_event: int = 100,
        max_gap_seconds: float | None = None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        if not english_events:
            return [], {
                "video_id": None,
                "event_frames": [],
                "event_count": 0,
                "alignment_score": 0.0,
                "dtw_score": 0.0,
            }

        # Use config default if not specified
        if max_gap_seconds is None:
            max_gap_seconds = settings.TRAKE_MAX_GAP_SECONDS

        # Try initial top_k_per_event, then fallback to higher values if alignment fails
        # Respect MAX_TOP_K limit (currently 100)
        max_allowed = min(top_k_per_event * 3, 100)  # Max 100 due to schema validation
        fallback_top_k_values = [top_k_per_event, min(top_k_per_event * 2, max_allowed), max_allowed]
        last_error = None
        
        for attempt_top_k in fallback_top_k_values:
            logger.info(f"TRAKE: Attempting alignment with top_k_per_event={attempt_top_k}, max_gap={max_gap_seconds}s")
            
            try:
                # Prefer bulk batch encode + search when the engine supports it for efficiency
                if hasattr(kis_engine, "search_batch_with_metrics"):
                    kis_results_per_event, _metrics = kis_engine.search_batch_with_metrics(
                        english_events,
                        attempt_top_k,
                    )
                else:
                    # Fall back to per-event search for engines that don't implement batch APIs
                    kis_results_per_event = []
                    for evt in english_events:
                        results_per_evt, _metrics = kis_engine.search_with_metrics(evt, attempt_top_k)
                        kis_results_per_event.append(results_per_evt)

                # Edge case: if any event returns no results, skip this attempt
                if any(not results for results in kis_results_per_event):
                    try:
                        idx = next(i for i, r in enumerate(kis_results_per_event) if not r)
                    except StopIteration:
                        idx = 0
                    last_error = f"Event {idx} returned no results"
                    logger.warning("TRAKE: %s", last_error)
                    continue
                
                event_layers = build_event_candidates(
                    event_texts=english_events,
                    kis_results_per_event=kis_results_per_event,
                )
                alignment = align_events_dtw(event_layers, max_gap_seconds=max_gap_seconds)
                
                if alignment is not None:
                    path, dtw_score = alignment
                    event_count = len(path)
                    alignment_score = dtw_score / event_count if event_count else 0.0

                    # Calculate temporal gaps for metadata
                    temporal_gaps = []
                    for i in range(1, len(path)):
                        gap = path[i].timestamp - path[i-1].timestamp
                        temporal_gaps.append(round(gap, 2))

                    results: list[dict[str, Any]] = []
                    for rank, candidate in enumerate(path, start=1):
                        item = dict(candidate.payload)
                        item.update(
                            {
                                "rank": rank,
                                "event_index": candidate.event_index,
                                "event_text": candidate.event_text,
                                "answer": None,
                            }
                        )
                        results.append(item)

                    trake_meta = {
                        "video_id": path[0].video_id,
                        "event_frames": [candidate.frame_id for candidate in path],
                        "event_count": event_count,
                        "alignment_score": round(alignment_score, 6),
                        "dtw_score": round(dtw_score, 6),
                        "top_k_used": attempt_top_k,
                        "temporal_gaps": temporal_gaps,
                        "max_gap_seconds": max_gap_seconds,
                    }
                    logger.info(f"TRAKE: Successfully aligned with top_k_per_event={attempt_top_k}, temporal_gaps={temporal_gaps}")
                    return results, trake_meta
                else:
                    last_error = f"No alignment found with top_k_per_event={attempt_top_k}"
                    logger.warning(f"TRAKE: {last_error}")
                    
            except (RetrievalUnavailableError, RuntimeError, ValueError, OSError) as exc:
                last_error = f"Alignment attempt failed: {exc}"
                logger.error("TRAKE: %s", last_error)
                continue
        
        # All attempts failed - return with helpful error information
        return [], {
            "video_id": None,
            "event_frames": [],
            "event_count": len(english_events),
            "alignment_score": 0.0,
            "dtw_score": 0.0,
            "error": last_error,
            "suggestion": "Try increasing top_k_per_event, adjust max_gap_seconds, or check if events can occur in sequence",
        }

    def align(self, english_text: str, top_k: int = 100) -> list[dict[str, Any]]:
        """Backward-compatible single-string entrypoint."""
        results, _meta = self.align_events([english_text], top_k_per_event=top_k)
        return results


trake_engine = TRAKEEngine()
