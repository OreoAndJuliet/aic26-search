from pathlib import Path
from typing import Any

from app.cache.factory import create_cache_backend
from app.cache.vlm_cache import VlmCache
from app.core.config import settings
from app.core.exceptions import VLMUnavailableError
from app.providers.vlm import VLMProvider, create_vlm_provider
from app.utils.vqa_answer import build_vqa_prompt, parse_vqa_answer


class VQAEngine:
    def __init__(self) -> None:
        self._provider: VLMProvider | None = None
        self._startup_error: str | None = None
        self._answer_cache = VlmCache(
            create_cache_backend(namespace="vlm"),
            scope=self._vlm_cache_scope(),
            ttl_seconds=self._vlm_cache_ttl(),
        )

    @staticmethod
    def _vlm_cache_scope() -> str:
        return (
            f"{settings.AI_PROVIDER_MODE}:{settings.VQA_PROVIDER}:"
            f"{settings.GEMINI_MODEL}:{settings.OPENAI_VQA_MODEL}:"
            f"{settings.CLAUDE_VQA_MODEL}:{settings.QWEN_VQA_MODEL}"
        )

    @staticmethod
    def _vlm_cache_ttl() -> int | None:
        ttl = settings.VLM_CACHE_TTL_SECONDS
        return ttl if ttl > 0 else None

    @property
    def provider_name(self) -> str:
        if settings.AI_PROVIDER_MODE.strip().lower() == "mock":
            return "mock"
        return settings.VQA_PROVIDER

    def _ensure_provider(self) -> VLMProvider:
        if self._provider is not None:
            return self._provider

        try:
            self._provider = create_vlm_provider(
                provider_name=settings.VQA_PROVIDER,
                provider_mode=settings.AI_PROVIDER_MODE,
                timeout_seconds=settings.VQA_TIMEOUT_SECONDS,
                gemini_api_key=settings.GEMINI_API_KEY,
                gemini_model_name=settings.GEMINI_MODEL,
                gemini_api_base=settings.GEMINI_API_BASE,
                openai_api_key=settings.OPENAI_API_KEY,
                openai_model_name=settings.OPENAI_VQA_MODEL,
                openai_api_base=settings.OPENAI_API_BASE,
                anthropic_api_key=settings.ANTHROPIC_API_KEY,
                claude_model_name=settings.CLAUDE_VQA_MODEL,
                anthropic_api_base=settings.ANTHROPIC_API_BASE,
                qwen_api_key=settings.QWEN_API_KEY,
                qwen_model_name=settings.QWEN_VQA_MODEL,
                qwen_api_base=settings.QWEN_API_BASE,
            )
        except VLMUnavailableError as exc:
            self._startup_error = str(exc)
            raise

        self._startup_error = None
        return self._provider

    def _answer_image(
        self,
        image_path: Path,
        question: str,
        *,
        video_id: str,
        keyframe_id: int,
    ) -> str:
        cached = self._answer_cache.get(
            video_id=video_id,
            keyframe_id=keyframe_id,
            question=question,
        )
        if cached is not None:
            return cached

        provider = self._ensure_provider()
        raw_answer = provider.answer(image_path, question)
        answer = parse_vqa_answer(raw_answer)
        self._answer_cache.set(
            video_id=video_id,
            keyframe_id=keyframe_id,
            question=question,
            answer=answer,
        )
        return answer

    def answer_single_image(self, image_path: Path, question: str) -> str:
        """Answer one image question for the JSON-to-VLM fallback path."""
        parts = image_path.parts
        video_id = parts[-2]
        keyframe_id = int(Path(parts[-1]).stem)
        return self._answer_image(
            image_path,
            build_vqa_prompt(question),
            video_id=video_id,
            keyframe_id=keyframe_id,
        )

    def answer(self, top_kis_results: list[dict[str, Any]], question: str) -> list[dict[str, Any]]:
        if not question.strip() or not top_kis_results:
            return []

        from concurrent.futures import ThreadPoolExecutor
        from app.services.kis_engine import kis_engine

        def _evaluate_candidate(result: dict[str, Any]) -> dict[str, Any]:
            keyframe_id = int(result.get("keyframe_id", result.get("frame_id", 0)))
            video_id = str(result["video_id"])

            image_path_raw = kis_engine.resolve_keyframe_path(video_id, keyframe_id)
            if image_path_raw is not None:
                image_path = Path(image_path_raw)
                if not image_path.is_absolute():
                    image_path = Path(settings.STATIC_DIR) / image_path
            else:
                image_path = settings.KEYFRAMES_DIR / video_id / f"{keyframe_id:03d}.jpg"

            result_copy = result.copy()
            try:
                result_copy["answer"] = self._answer_image(
                    image_path,
                    question,
                    video_id=video_id,
                    keyframe_id=keyframe_id,
                )
            except Exception as exc:
                result_copy["answer"] = ""
                result_copy["vlm_error"] = str(exc)

            result_copy["source"] = "VLM_API"
            return result_copy

        max_workers = min(len(top_kis_results), settings.VQA_MAX_CONCURRENCY)
        if max_workers <= 1:
            return [_evaluate_candidate(r) for r in top_kis_results]

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            return list(executor.map(_evaluate_candidate, top_kis_results))


vqa_engine = VQAEngine()

