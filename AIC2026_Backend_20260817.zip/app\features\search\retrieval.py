"""Shared KIS retrieval helpers used by unified search and legacy KIS endpoint."""

from __future__ import annotations

import logging

from app.algorithms.crop_alignment import apply_crop_clip_alignment
from app.algorithms.diversification import apply_intra_video_diversification
from app.algorithms.hybrid_ranking import rerank_hybrid_results
from app.algorithms.kis_postprocess import (
    rerank_kis_by_media_info,
    rerank_kis_by_objects,
)
from app.algorithms.temporal_smoothing import apply_temporal_smoothing
from app.core.config import settings
from app.features.search.enrichment import attach_media_info
from app.services.kis_engine import kis_engine
from app.services.kis_rscore import build_rscore_report

logger = logging.getLogger(__name__)


def run_kis_retrieval(
    translated_text: str,
    top_k: int,
) -> tuple[list[dict], dict[str, float | dict | None]]:
    """Translate-ready text → FAISS hits with stage timings and rscore report."""
    results, retrieval_metrics = kis_engine.search_with_metrics(translated_text, top_k)
    results = rerank_kis_by_objects(translated_text, results)
    results = rerank_kis_by_media_info(translated_text, results)
    results = attach_media_info(results)
    results = rerank_hybrid_results(translated_text, results, task_type="KIS")
    results = apply_temporal_smoothing(results)

    # Crop-Level Regional CLIP Alignment
    if settings.KIS_CROP_ALIGNMENT_ENABLED and results:
        try:
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = apply_crop_clip_alignment(
                results,
                query_vector,
                kis_engine.text_encoder,
                keyframes_dir=settings.KEYFRAMES_DIR,
                objects_dir=settings.OBJECT_ROOT,
                weight=settings.KIS_CROP_ALIGNMENT_WEIGHT,
                top_k_eval=settings.KIS_CROP_ALIGNMENT_TOPK,
            )
        except Exception as exc:
            logger.warning("crop_clip_alignment_failed: %s", exc)

    results = apply_intra_video_diversification(results)

    # Optional cross-encoder style rescoring (lightweight proxy using image embeddings)
    try:
        from app.algorithms.cross_encoder import rescore_top_k
    except ImportError:
        rescore_top_k = None

    if rescore_top_k is not None and settings.CROSS_ENCODER_ENABLED and results:
        try:
            # encode once (use cached) to get the query vector used earlier
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = rescore_top_k(query_vector, results, kis_engine.store)
        except (RuntimeError, ValueError, OSError) as exc:
            # Rescoring failure must not break retrieval — log exception details and continue
            logger.warning("cross_encoder_rescore_failed: %s", exc)

    retrieval_time_ms = round(
        retrieval_metrics["embedding_time_ms"]
        + retrieval_metrics["faiss_time_ms"]
        + retrieval_metrics["metadata_time_ms"],
        2,
    )
    metrics: dict[str, float | dict | None] = {
        **retrieval_metrics,
        "retrieval_time_ms": retrieval_time_ms,
        "vlm_time_ms": 0.0,
        "rscore": build_rscore_report(results),
    }
    return results, metrics
