"""Shared KIS retrieval helpers used by unified search and legacy KIS endpoint."""

from __future__ import annotations

import logging
import re

from app.algorithms.crop_alignment import apply_crop_clip_alignment
from app.algorithms.diversification import apply_intra_video_diversification
from app.algorithms.hybrid_ranking import rerank_hybrid_results
from app.algorithms.kis_postprocess import (
    rerank_kis_by_media_info,
    rerank_kis_by_objects,
)
from app.algorithms.temporal_smoothing import apply_temporal_smoothing
from app.core.config import settings
from app.features.search.enrichment import attach_media_info
from app.services.kis_engine import kis_engine
from app.services.kis_rscore import build_rscore_report

logger = logging.getLogger(__name__)


def determine_adaptive_candidate_pool_size(query: str, requested_top_k: int) -> int:
    """Dynamically determine optimal candidate pool depth (default: 1000) based on query and dataset size."""
    base_pool = int(getattr(settings, "KIS_CANDIDATE_POOL_SIZE", 1000))
    # Guarantee deep retrieval pool for all queries while respecting requested_top_k and vector capacity
    chosen_k = max(base_pool, requested_top_k * 10)

    max_avail = chosen_k
    try:
        if getattr(kis_engine, "is_ready", False) and kis_engine.store and kis_engine.store.stats:
            if kis_engine.store.stats.vector_count > 0:
                max_avail = kis_engine.store.stats.vector_count
    except Exception:
        pass
    return max(requested_top_k, min(chosen_k, max_avail))


def run_kis_retrieval(
    translated_text: str,
    top_k: int,
) -> tuple[list[dict], dict[str, float | dict | None]]:
    """Translate-ready text → FAISS hits with stage timings and rscore report."""
    # 1. Adaptively choose candidate pool depth (e.g. 1000 for complex queries, 300-500 for fast queries)
    expanded_k = determine_adaptive_candidate_pool_size(translated_text, top_k)
    results, retrieval_metrics = kis_engine.search_with_metrics(translated_text, expanded_k)

    # 2. OCR / Multi-Modal Inverted Index Candidate Injection & Boosting
    try:
        from app.services.ocr_store import ocr_store
        matched_ocr_frames = ocr_store.search_matching_frames(translated_text, top_k=15)
        if matched_ocr_frames:
            existing_keys = {(str(r.get("video_id")), int(r.get("frame_id", r.get("keyframe_id", 0)))) for r in results}
            injected_count = 0
            for ocr_f in matched_ocr_frames:
                v_id = str(ocr_f["video_id"])
                f_id = int(ocr_f["frame_id"])
                if (v_id, f_id) not in existing_keys:
                    img_path = kis_engine.resolve_keyframe_path(v_id, f_id)
                    results.insert(0, {
                        "video_id": v_id,
                        "frame_id": f_id,
                        "keyframe_id": f_id,
                        "timestamp": ocr_f.get("timestamp", 0.0),
                        "score": ocr_f.get("score", 0.95),
                        "r_score": ocr_f.get("score", 0.95),
                        "ocr_text": ocr_f.get("detected_text", ""),
                        "ocr_boost": True,
                        "image_path": str(img_path) if img_path else f"keyframes/{v_id}/{f_id:03d}.jpg",
                    })
                    existing_keys.add((v_id, f_id))
                    injected_count += 1
                else:
                    # Boost existing candidate
                    for r in results:
                        if str(r.get("video_id")) == v_id and int(r.get("frame_id", r.get("keyframe_id", 0))) == f_id:
                            r["score"] = max(float(r.get("score", 0.0)), float(ocr_f.get("score", 0.95)))
                            r["r_score"] = r["score"]
                            r["ocr_boost"] = True
                            r["ocr_text"] = ocr_f.get("detected_text", "")
            if injected_count > 0 or matched_ocr_frames:
                results.sort(key=lambda x: x.get("score", x.get("r_score", 0.0)), reverse=True)
    except Exception as exc:
        logger.debug("ocr_candidate_injection_failed: %s", exc)

    # 3. Attach media_info early so all downstream rerankers have access to metadata
    results = attach_media_info(results)

    # 4. Vietnamese Iconic Landmark Gazetteer Boosting
    try:
        from app.services.landmark_gazetteer import landmark_gazetteer
        matched_lms = landmark_gazetteer.match_landmarks(translated_text)
        if matched_lms and results:
            lm_names = {lm.get("name", "").lower() for lm in matched_lms}
            lm_names.update({lm.get("canonical_en", "").lower() for lm in matched_lms})
            for r in results:
                info = r.get("media_info") or {}
                title = str(info.get("title", "")).lower()
                desc = str(info.get("description", "")).lower()
                tags = " ".join(info.get("tags", [])).lower() if isinstance(info.get("tags"), list) else str(info.get("tags", "")).lower()
                combined_meta = f"{title} {desc} {tags}"
                if any(lm in combined_meta for lm in lm_names if len(lm) >= 4):
                    r["score"] = min(1.0, float(r.get("score", 0.0)) + 0.30)
                    r["r_score"] = r["score"]
                    r["landmark_boost"] = 0.30
            results.sort(key=lambda x: x.get("score", x.get("r_score", 0.0)), reverse=True)
    except Exception as exc:
        logger.debug("landmark_boost_failed: %s", exc)

    results = rerank_kis_by_objects(translated_text, results)
    results = rerank_kis_by_media_info(translated_text, results)
    results = rerank_hybrid_results(translated_text, results, task_type="KIS")
    results = apply_temporal_smoothing(results)

    # Crop-Level Regional CLIP Alignment
    if settings.KIS_CROP_ALIGNMENT_ENABLED and results:
        try:
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = apply_crop_clip_alignment(
                results,
                query_vector,
                kis_engine.text_encoder,
                keyframes_dir=settings.KEYFRAMES_DIR,
                objects_dir=settings.OBJECT_ROOT,
                weight=settings.KIS_CROP_ALIGNMENT_WEIGHT,
                top_k_eval=settings.KIS_CROP_ALIGNMENT_TOPK,
            )
        except Exception as exc:
            logger.warning("crop_clip_alignment_failed: %s", exc)

    # Multi-Scale Spatial Quadrant RoI Max-Pooling for Small Objects
    try:
        from app.algorithms.spatial_roi_pooling import (
            apply_spatial_quadrant_roi_pooling,
            should_apply_spatial_roi_pooling,
        )
        if should_apply_spatial_roi_pooling(translated_text) and results:
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = apply_spatial_quadrant_roi_pooling(
                results,
                query_vector,
                kis_engine.text_encoder,
                keyframes_dir=settings.KEYFRAMES_DIR,
                top_k_eval=5,
                roi_weight=0.20,
            )
    except Exception as exc:
        logger.debug("spatial_roi_pooling_failed: %s", exc)

    # Negative Constraint Penalty
    try:
        from app.algorithms.negative_projection import extract_negative_constraint
        has_neg, pos_text, neg_text = extract_negative_constraint(translated_text)
        if has_neg and neg_text and results:
            v_neg = kis_engine.encode_query_vector(neg_text)
            norm_neg = np.linalg.norm(v_neg)
            if norm_neg > 0:
                v_neg = v_neg / norm_neg
                # Check top candidates and penalize those matching the negative concept
                for r in results[:10]:
                    v_id = str(r.get("video_id", ""))
                    f_id = int(r.get("keyframe_id", r.get("frame_id", 1)))
                    # Use store image vector or metadata vector if available
                    cand_vec = kis_engine.store.vector_for_frame(v_id, f_id) if hasattr(kis_engine.store, "vector_for_frame") else None
                    if cand_vec is not None:
                        neg_sim = float(np.dot(cand_vec, v_neg))
                        if neg_sim > 0.40:
                            base_s = float(r.get("score", r.get("r_score", 0.0)))
                            r["score"] = max(0.0, base_s - (0.25 * neg_sim))
                            r["r_score"] = r["score"]
                            r["negative_penalty"] = round(0.25 * neg_sim, 3)
                results.sort(key=lambda x: x.get("score", x.get("r_score", 0.0)), reverse=True)
    except Exception as exc:
        logger.debug("negative_penalty_failed: %s", exc)

    # Object Class + HSV Color Co-Occurrence Reranking
    try:
        from app.algorithms.color_object_reranker import rerank_by_color_object_cooccurrence
        results = rerank_by_color_object_cooccurrence(
            results,
            translated_text,
            keyframes_dir=settings.KEYFRAMES_DIR,
            objects_dir=settings.OBJECT_ROOT,
            boost_weight=0.25,
            top_k_eval=15,
        )
    except Exception as exc:
        logger.debug("color_object_rerank_failed: %s", exc)

    # MediaInfo BM25 additive boost (applied only for confident topic matches)
    try:
        from app.services.mediainfo_store import mediainfo_store
        media_ranks = mediainfo_store.search_bm25(translated_text, top_k=10)
        if media_ranks and results:
            media_scores_dict = dict(media_ranks)
            for item in results:
                v_id = str(item.get("video_id", ""))
                if v_id in media_scores_dict:
                    bm25_s = media_scores_dict[v_id]
                    if bm25_s >= 5.0:
                        boost = min(0.12, 0.01 * bm25_s)
                        item["score"] = round(float(item.get("score", item.get("r_score", 0.0))) + boost, 6)
                        item["r_score"] = item["score"]
                        item["mediainfo_boost"] = round(boost, 3)
            results.sort(key=lambda x: x.get("score", 0.0), reverse=True)
    except Exception as exc:
        logger.debug("mediainfo_boost_failed: %s", exc)

    # Visual Pseudo-Relevance Feedback (Visual PRF)
    if settings.VISUAL_PRF_ENABLED and results:
        try:
            from app.algorithms.visual_prf import apply_visual_pseudo_relevance_feedback
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = apply_visual_pseudo_relevance_feedback(
                results,
                query_vector,
                kis_engine.store,
                top_m_visual=settings.VISUAL_PRF_TOPK,
                prf_weight=settings.VISUAL_PRF_WEIGHT,
                blend_alpha=settings.VISUAL_PRF_BLEND_ALPHA,
            )
        except Exception as exc:
            logger.debug("visual_prf_failed: %s", exc)

    # Temporal Shot Consensus Graph Filtering
    if settings.TEMPORAL_CONSENSUS_ENABLED and results:
        try:
            from app.algorithms.temporal_consensus import apply_temporal_shot_consensus
            results = apply_temporal_shot_consensus(
                results,
                window_seconds=settings.TEMPORAL_CONSENSUS_WINDOW_SECONDS,
                consensus_boost_weight=settings.TEMPORAL_CONSENSUS_BOOST_WEIGHT,
                isolated_penalty=settings.TEMPORAL_CONSENSUS_ISOLATED_PENALTY,
            )
        except Exception as exc:
            logger.debug("temporal_consensus_failed: %s", exc)

    results = apply_intra_video_diversification(results)

    # Optional cross-encoder style rescoring (lightweight proxy using image embeddings)
    try:
        from app.algorithms.cross_encoder import rescore_top_k
    except ImportError:
        rescore_top_k = None

    if rescore_top_k is not None and settings.CROSS_ENCODER_ENABLED and results:
        try:
            # encode once (use cached) to get the query vector used earlier
            query_vector = kis_engine.encode_query_vector(translated_text)
            results = rescore_top_k(query_vector, results, kis_engine.store)
        except (RuntimeError, ValueError, OSError) as exc:
            # Rescoring failure must not break retrieval — log exception details and continue
            logger.warning("cross_encoder_rescore_failed: %s", exc)

    # Final Top-K Slice
    results = results[:top_k]
    for r, item in enumerate(results, start=1):
        item["rank"] = r

    retrieval_time_ms = round(
        retrieval_metrics["embedding_time_ms"]
        + retrieval_metrics["faiss_time_ms"]
        + retrieval_metrics["metadata_time_ms"],
        2,
    )
    metrics: dict[str, float | dict | None] = {
        **retrieval_metrics,
        "retrieval_time_ms": retrieval_time_ms,
        "vlm_time_ms": 0.0,
        "rscore": build_rscore_report(results),
    }
    return results, metrics
