# =============================================================================
#  AIC 2026 - Smart Server Launcher & Environment Healthcheck
# =============================================================================
param (
    [switch]$AutoTune,
    [switch]$ForceReindex,
    [int]$Port = 8000,
    [string]$HostIP = "0.0.0.0"
)

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"

Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "         AIC 2026 BACKEND SMART SERVER LAUNCHER                  " -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan

# 1. Resolve Python executable
$pythonExe = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    $pythonExe = "python"
}

# 2. Port Cleanup (Kill any stale process occupying port $Port)
Write-Host "[1/4] Checking Port $Port status..." -ForegroundColor Yellow
try {
    $connections = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($connections) {
        foreach ($conn in $connections) {
            $pidToKill = $conn.OwningProcess
            if ($pidToKill -gt 0) {
                Write-Host "      Freeing stale process (PID: $pidToKill) on port $Port..." -ForegroundColor Yellow
                Stop-Process -Id $pidToKill -Force -ErrorAction SilentlyContinue
            }
        }
        Start-Sleep -Milliseconds 500
        Write-Host "      Port $Port is now completely free." -ForegroundColor Green
    } else {
        Write-Host "      Port $Port is ready." -ForegroundColor Green
    }
} catch {
    Write-Host "      Port check completed." -ForegroundColor Gray
}

# 3. Docker & Milvus Vector Database Healthcheck
Write-Host "[2/4] Checking Docker Milvus Vector Store (Port 19530)..." -ForegroundColor Yellow
$milvusPortActive = $false
try {
    $milvusConn = Test-NetConnection -ComputerName 127.0.0.1 -Port 19530 -WarningAction SilentlyContinue
    if ($milvusConn.TcpTestSucceeded) {
        $milvusPortActive = $true
        Write-Host "      Milvus Standalone is ACTIVE on port 19530 (HNSW Hybrid Mode ready)." -ForegroundColor Green
    }
} catch {}

if (-not $milvusPortActive) {
    Write-Host "      Milvus not detected on port 19530." -ForegroundColor Yellow
    # Check if docker is available
    $dockerCmd = Get-Command docker -ErrorAction SilentlyContinue
    if ($dockerCmd) {
        Write-Host "      Attempting to launch Milvus via Docker Compose..." -ForegroundColor Yellow
        & docker compose up -d milvus 2>$null
        Start-Sleep -Seconds 2
    } else {
        Write-Host "      Docker not running. FAISS in-memory C++ engine will handle 100% of queries seamlessly." -ForegroundColor Cyan
    }
}

# 4. Smart New Data & Ground-Truth Detection
Write-Host "[3/4] Checking dataset integrity & new feature batches..." -ForegroundColor Yellow
$featuresDir = Join-Path $PSScriptRoot "data\features"
$faissIndex = Join-Path $PSScriptRoot "data\faiss_index.bin"
$gtJson = Join-Path $PSScriptRoot "data\mock_contest_ground_truth.json"

$newDataDetected = $false

if (Test-Path $featuresDir) {
    $latestFeature = Get-ChildItem -Path $featuresDir -Filter "*.npy" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestFeature -and (Test-Path $faissIndex)) {
        $indexTime = (Get-Item $faissIndex).LastWriteTime
        if ($latestFeature.LastWriteTime -gt $indexTime) {
            $newDataDetected = $true
            Write-Host "      [ALERT] New feature file detected ($($latestFeature.Name)) newer than faiss_index.bin!" -ForegroundColor Magenta
        }
    }
}

if ($ForceReindex -or ($newDataDetected -and -not $AutoTune)) {
    Write-Host "      Rebuilding index (build_index.py)..." -ForegroundColor Yellow
    & $pythonExe (Join-Path $PSScriptRoot "build_index.py")
}

if ($AutoTune -or $newDataDetected) {
    Write-Host "      [AUTO-TUNE] Running hyperparameter auto-tuner (tune.ps1) to find optimal parameters for new data..." -ForegroundColor Cyan
    & $pythonExe -u (Join-Path $PSScriptRoot "scripts\tune_hyperparameters.py") --mode presets --suite kis --apply
}

# 5. Launch Server
Write-Host "[4/4] Starting FastAPI High-Throughput Server on http://${HostIP}:${Port}..." -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Cyan

$uvicornCmd = Join-Path $PSScriptRoot ".venv\Scripts\uvicorn.exe"
if (-not (Test-Path $uvicornCmd)) {
    & $pythonExe -m uvicorn main:app --host $HostIP --port $Port
} else {
    & $uvicornCmd main:app --host $HostIP --port $Port
}
