# AIC 2026 Backend — Complete Guide

> **Project root**: `D:\backup1\2026-08-16_0508`  
> Last updated: 2026-08-16

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Prerequisites](#2-prerequisites)
3. [Installation](#3-installation)
4. [Configuration (.env)](#4-configuration-env)
5. [Data Ingestion](#5-data-ingestion)
6. [Building the FAISS Index](#6-building-the-faiss-index)
7. [Running the Backend](#7-running-the-backend)
8. [Search Modes](#8-search-modes)
9. [API Reference](#9-api-reference)
10. [Docker & Milvus Hybrid](#10-docker--milvus-hybrid)
11. [Troubleshooting](#11-troubleshooting)
12. [Competition Day Checklist](#12-competition-day-checklist)

---

## 1. Project Overview

This backend is the competition engine for **AIC 2026** (AI City Challenge Vietnam). It assembles the organizer-provided CLIP features and Faster R-CNN object files into a full search system — no model training required.

### Directory Layout

```
.
├── main.py                   ← FastAPI entry point
├── build_index.py            ← One-shot FAISS index builder
├── install.ps1               ← First-time installer (venv + deps + Docker)
├── search.ps1                ← Unified search CLI (KIS / VQA / TRAKE)
├── ingest.ps1                ← Data ingestion (zips → static/)
├── .env                      ← Your configuration (API keys, modes, paths)
├── app/
│   ├── core/config.py        ← All settings loaded from .env
│   ├── services/
│   │   ├── kis_engine.py     ← FAISS KIS retrieval
│   │   ├── vqa_engine.py     ← KIS + VLM (Gemini / GPT-4o / Claude / Qwen)
│   │   └── trake_engine.py   ← Temporal alignment (layered DP / DTW)
│   ├── vector/
│   │   ├── faiss_store.py    ← FAISS cosine search
│   │   └── metadata_catalog.py ← JSON metadata lookup
│   └── features/submission/  ← CSV export, Codabench ZIP builder
├── data/
│   ├── faiss_index.bin       ← Built by build_index.py
│   ├── metadata.json         ← Built by build_index.py
│   ├── features/             ← Organizer .npy CLIP feature files
│   ├── map_keyframes/        ← Organizer CSV keyframe maps
│   ├── objects/              ← Organizer Faster R-CNN JSON files
│   └── media_info/           ← Organizer media info JSON files
└── static/
    ├── keyframes/            ← Extracted keyframe images
    └── videos/               ← Extracted video files
```

### Architecture

```
Query (VI/EN)
    │
    ▼
[Translation]  VI→EN via Google GTX (free) or Gemini/OpenAI
    │
    ▼
[CLIP Encoder]  text → 512-dim vector (clip-ViT-B-32)
    │
    ▼
[FAISS Search]  cosine similarity over all keyframe vectors
    │
    ▼
[Reranking]     object boost (Faster R-CNN) + media-info boost
    │
    ├─► KIS → API response
    ├─► VQA → top-1 frame + question → Gemini/GPT/Claude → answer
    └─► TRAKE DTW → find path with t1 < t2 < t3 in same video
```

---

## 2. Prerequisites

| Requirement | Version | Notes |
|-------------|---------|-------|
| Python      | >= 3.10 | 3.12 recommended |
| PowerShell  | >= 5.1  | Included in Windows 10/11 |
| Docker Desktop | any  | Only for Milvus hybrid backend |
| Internet    | —       | For pip install + API calls |

Check Python:
```powershell
python --version
```

---

## 3. Installation

### 3.1 Basic (FAISS only, no Docker)

```powershell
cd D:\backup1\2026-08-16_0508
.\install.ps1
```

| Step | Action |
|------|--------|
| 1 | Verify Python >= 3.10 |
| 2 | Create .venv |
| 3 | pip install -r requirements.txt |
| 4 | Copy .env.example → .env |
| 5 | Create required directories |
| 6 | (skipped in basic mode) |
| 7 | Build FAISS index if .npy files present |
| 8 | Print next-steps summary |

### 3.2 With Milvus (hybrid vector backend)

```powershell
.\install.ps1 -WithMilvus -Force
```

Also: checks Docker, starts Milvus, patches .env VECTOR_BACKEND=hybrid.

### 3.3 Options

```powershell
.\install.ps1 -PythonExe "C:\Python312\python.exe"  # specific Python
.\install.ps1 -SkipIndex                              # skip index build
.\install.ps1 -WithMilvus -Force                     # no prompts + Milvus
```

---

## 4. Configuration (.env)

Edit `.env` in the project root. Key settings:

### 4.1 API Keys

```ini
# Google Gemini — https://aistudio.google.com/app/apikey
GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE

# OpenAI — https://platform.openai.com/api-keys
OPENAI_API_KEY=YOUR_OPENAI_API_KEY_HERE

# Anthropic Claude — https://console.anthropic.com/
ANTHROPIC_API_KEY=YOUR_ANTHROPIC_API_KEY_HERE

# Alibaba Qwen — https://dashscope.console.aliyun.com/
QWEN_API_KEY=YOUR_QWEN_API_KEY_HERE
```

### 4.2 Provider Modes

```ini
# Competition mode (real APIs)
AI_PROVIDER_MODE=real
TEXT_ENCODER_PROVIDER=sentence_transformers   # downloads CLIP on first run

# Test mode (no keys or downloads needed)
AI_PROVIDER_MODE=mock
TEXT_ENCODER_PROVIDER=mock
```

### 4.3 VQA Provider

```ini
VQA_PROVIDER=gemini    # gemini | openai | anthropic | qwen | mock
```

### 4.4 Translation Provider

```ini
TRANSLATION_PROVIDER=google_gtx   # free, no key needed
# TRANSLATION_PROVIDER=gemini     # needs GEMINI_API_KEY
# TRANSLATION_PROVIDER=openai     # needs OPENAI_API_KEY
```

### 4.5 Vector Backend

```ini
VECTOR_BACKEND=faiss      # fast, local, no Docker
# VECTOR_BACKEND=hybrid   # FAISS + Milvus, best recall, needs Docker
# VECTOR_BACKEND=qdrant   # Qdrant, needs Qdrant running
```

### 4.6 Image Path Validation

```ini
# false = warn only (safe for cross-machine / Docker)
# true  = hard fail if image missing
STRICT_IMAGE_VALIDATION=false
```

### 4.7 Backend Host

```ini
BACKEND_HOST=http://localhost:8000
# For LAN team access during competition:
# BACKEND_HOST=http://192.168.1.100:8000
```

### 4.8 Cache TTLs

```ini
EMBEDDING_CACHE_TTL_SECONDS=3600    # 1 hour
TRANSLATION_CACHE_TTL_SECONDS=3600
VLM_CACHE_TTL_SECONDS=1800          # 30 min
```

---

## 5. Data Ingestion

### 5.1 Drop zips in inbox, run ingest

```powershell
# Put zip files in data/inbox/, then:
.\ingest.ps1
```

### 5.2 Point to a directory of zips

```powershell
.\ingest.ps1 -ZipDir "C:\Downloads\aic_bundles"
```

### 5.3 Single zip

```powershell
.\ingest.ps1 -ZipFile "C:\Downloads\keyframes_L01.zip"
```

### 5.4 Dry run (preview, no writes)

```powershell
.\ingest.ps1 -DryRun
```

### 5.5 Ingest + rebuild index

```powershell
.\ingest.ps1 -RebuildIndex
```

### 5.6 Zip type detection

| Filename contains | Destination |
|-------------------|-------------|
| keyframe / frame  | static\keyframes\ |
| video             | static\videos\ |
| feature / clip / npy | data\features\ |
| map / mapping     | data\map_keyframes\ |
| unknown           | detected from zip contents |

### 5.7 Expected structure after ingestion

```
static/keyframes/
  L01_V001/001.jpg, 002.jpg, ...
  L01_V002/001.jpg, ...

data/features/
  L01_V001.npy, L01_V002.npy, ...

data/map_keyframes/
  map-keyframes-aic25-b1/map-keyframes/
    L01_V001.csv, L01_V002.csv, ...
```

---

## 6. Building the FAISS Index

Run once after ingesting .npy feature files:

```powershell
.venv\Scripts\python.exe build_index.py
```

Outputs:
- `data/faiss_index.bin` — FAISS index
- `data/metadata.json` — frame metadata with portable relative paths

> **Important**: After moving data to a new machine or Docker, always rebuild the index. The updated build_index.py stores relative paths, so metadata.json is fully portable.

---

## 7. Running the Backend

### 7.1 Local dev (hot-reload)

```powershell
.venv\Scripts\Activate.ps1
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 7.2 Production (no reload)

```powershell
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 2
```

### 7.3 Docker Compose (with Milvus)

```powershell
docker compose up -d          # start background
docker compose logs -f        # watch logs
docker compose down           # stop
docker compose down -v        # stop + delete Milvus data
```

### 7.4 Health check

```powershell
Invoke-RestMethod http://localhost:8000/health
# → { "status": "ok", "index_loaded": true, "vector_count": 11422 }
```

---

## 8. Search Modes

All search uses `search.ps1`. The old separate scripts (search_kis.ps1, search_vqa.ps1, search_trake.ps1) still work but are now superseded.

### 8.1 KIS — Known-Item Search

```powershell
# Basic
.\search.ps1 "a person walks into a room"

# Vietnamese (auto-translated)
.\search.ps1 "người đi vào phòng"

# Explicit
.\search.ps1 -Mode KIS -Query "sunset over the ocean" -TopK 5

# Raw JSON
.\search.ps1 "a car stops at traffic light" -Json
```

Output columns: `rank`, `r_score`, `video_id`, `frame_id`, `timestamp`, `thumbnail_url`

### 8.2 VQA — Visual Question Answering

Requires a real VLM API key.

```powershell
# Full
.\search.ps1 -Mode VQA -Query "kitchen scene" -Question "How many people?"

# Short aliases
.\search.ps1 -Mode VQA -q "outdoor market" -Q "What is being sold?"

# Interactive (prompts for both fields)
.\search.ps1 -Mode VQA
```

Output columns: `rank`, `r_score`, `answer`, `video_id`, `frame_id`, `thumbnail_url`

**Tip**: For counting questions, the backend reads Faster R-CNN bounding boxes directly — more accurate than asking the VLM to count.

### 8.3 TRAKE — Temporal Event Sequence

```powershell
# Pipe syntax (easiest)
.\search.ps1 -Mode TRAKE "enters room|picks phone|hangs up|leaves"

# Array syntax
.\search.ps1 -Mode TRAKE -Events "opens door","walks in","closes door"

# EventList param
.\search.ps1 -Mode TRAKE -EventList "sits|reads|stands"

# Interactive (prompts one event at a time)
.\search.ps1 -Mode TRAKE
```

Output: event table + "Submission line: `video_id, frame1, frame2, ...`"

### 8.4 Universal options

```powershell
.\search.ps1 -Help                                    # full usage
.\search.ps1 "query" -ApiBase http://server:8000      # custom backend URL
.\search.ps1 "query" -Json                            # raw JSON output
.\search.ps1 "query" -TopK 50                         # more results
```

---

## 9. API Reference

### POST /api/search

**KIS:**
```json
{ "type": "KIS", "text": "a person walks into a room", "top_k": 20 }
```

**VQA:**
```json
{ "type": "VQA", "text": "kitchen scene", "question": "How many people?", "top_k": 5 }
```

**TRAKE:**
```json
{ "type": "TRAKE", "events": ["enters", "sits", "leaves"], "top_k_per_event": 100 }
```

**Response (all modes):**
```json
{
  "status": "success",
  "type": "KIS",
  "results": [
    {
      "video_id": "L01_V003",
      "frame_id": 412,
      "keyframe_id": 137,
      "timestamp": 45.7,
      "r_score": 0.8712,
      "answer": null,
      "thumbnail_url": "/keyframes/L01_V003/137.jpg",
      "image_url": "http://localhost:8000/keyframes/L01_V003/137.jpg"
    }
  ],
  "translation_time_ms": 0.0,
  "retrieval_time_ms": 48.2,
  "total_time_ms": 51.3,
  "trake": null
}
```

**TRAKE addition in response:**
```json
{
  "trake": {
    "video_id": "L03_V002",
    "event_frames": [234, 289, 341],
    "alignment_score": 2.4521
  }
}
```

### GET /health

```
GET http://localhost:8000/health
→ { "status": "ok", "index_loaded": true, "vector_count": 11422 }
```

### Static images

```
GET http://localhost:8000/keyframes/{video_id}/{keyframe_id:03d}.jpg
```

---

## 10. Docker & Milvus Hybrid

```powershell
# Start Milvus only
docker compose up -d milvus

# Start full stack
docker compose up -d

# Watch logs
docker compose logs -f backend

# Restart after config change
docker compose restart backend
```

Milvus takes ~30 seconds to be ready. The backend waits for the healthcheck before starting — no manual timing needed.

**.env settings for hybrid:**
```ini
VECTOR_BACKEND=hybrid
MILVUS_URI=tcp://localhost:19530
```

---

## 11. Troubleshooting

### Zero search results / backend_error.log full of path warnings

Rebuild the index — old metadata.json had absolute paths:
```powershell
.venv\Scripts\python.exe build_index.py
```

### pip install fails (httpx2 not found)

Fixed in requirements.txt. If you have an old install:
```powershell
.venv\Scripts\pip install httpx>=0.25.0
```

### VQA returns empty answers

1. Check `VQA_PROVIDER != mock` in .env
2. Check your API key is filled in
3. Check logs: `Get-Content backend_error.log -Tail 30`

### Backend won't start with Docker

```powershell
docker compose logs milvus     # Milvus health
docker compose logs backend    # backend errors
docker compose down -v
docker compose up -d
```

### VECTOR_BACKEND=qdrant or TRANSLATION_PROVIDER=gemini crashes

Fixed — both are now valid values. If your .env was set before the fix, it now works.

### search.ps1 can't reach backend

```powershell
Invoke-RestMethod http://localhost:8000/health
Get-Content .env | Select-String BACKEND_HOST
```

---

## 12. Competition Day Checklist

```
PRE-COMPETITION (day before)
─────────────────────────────────────────────────────
[ ] Ingest all data:    .\ingest.ps1 -ZipDir <path> -RebuildIndex
[ ] Index built:        Test-Path data\faiss_index.bin
[ ] API key in .env:    GEMINI_API_KEY=<key>
[ ] Real mode:          AI_PROVIDER_MODE=real
[ ] CLIP downloaded:    TEXT_ENCODER_PROVIDER=sentence_transformers
[ ] Caches on:          EMBEDDING_CACHE_TTL_SECONDS=3600
[ ] Team LAN IP set:    BACKEND_HOST=http://192.168.x.x:8000
[ ] Health check OK:    Invoke-RestMethod http://localhost:8000/health

COMPETITION START
─────────────────────────────────────────────────────
[ ] Activate venv:      .venv\Scripts\Activate.ps1
[ ] Start backend:      uvicorn main:app --host 0.0.0.0 --port 8000
[ ] Test KIS:           .\search.ps1 "a person walks in a room" -TopK 5
[ ] Test VQA:           .\search.ps1 -Mode VQA "two people" -Q "How many?"
[ ] Test TRAKE:         .\search.ps1 -Mode TRAKE "enters|sits|leaves"

DURING COMPETITION
─────────────────────────────────────────────────────
KIS task:   .\search.ps1 "<scene description>"        → video_id + frame_id
VQA task:   .\search.ps1 -Mode VQA "<scene>" -Q "<?>" → answer
TRAKE task: .\search.ps1 -Mode TRAKE "e1|e2|e3"       → submission line

SUBMISSION FORMAT
─────────────────────────────────────────────────────
KIS:   video_id, frame_id
VQA:   video_id, frame_id, answer
TRAKE: video_id, frame_id_1, frame_id_2, ..., frame_id_n
```

---

## Quick Reference

```powershell
# Setup
.\install.ps1                                    # basic
.\install.ps1 -WithMilvus -Force                # with Milvus Docker

# Data
.\ingest.ps1 -ZipDir C:\Downloads\aic           # extract zips
.\ingest.ps1 -RebuildIndex                      # extract + rebuild index
.venv\Scripts\python.exe build_index.py          # rebuild index only

# Backend
.venv\Scripts\Activate.ps1
uvicorn main:app --reload                        # dev
uvicorn main:app --host 0.0.0.0 --port 8000     # prod
docker compose up -d                             # with Milvus

# Search
.\search.ps1 "query"                             # KIS
.\search.ps1 -Mode VQA "scene" -Q "question"    # VQA
.\search.ps1 -Mode TRAKE "e1|e2|e3"             # TRAKE
.\search.ps1 -Help                               # all options

# Health
Invoke-RestMethod http://localhost:8000/health
```
