"""VQA orchestration: Faster R-CNN JSON first, VLM when uncertain."""

from __future__ import annotations

import re
import time

from app.core.config import settings
from app.services.object_store import object_store, CLASS_ENTITY_ALIASES
from app.services.vqa_engine import vqa_engine
from app.utils.keyframes import keyframe_image_path
from app.utils.vqa_answer import build_vqa_prompt

COUNT_WORDS = ("how many", "number of", "count", "quantity", "bao nhiêu", "bao nhieu", "số lượng", "mấy", "may")

OBJECT_TARGET_PATTERNS: dict[str, tuple[str, ...]] = {
    "person": ("person", "people", "human", "man", "men", "woman", "women", "child", "children", "người", "nguoi"),
    "car": ("car", "cars", "automobile", "vehicle", "vehicles", "xe hơi", "xe hoi", "xe ô tô", "xe oto"),
    "bus": ("bus", "buses", "xe buýt", "xe buyt"),
    "truck": ("truck", "trucks", "xe tải", "xe tai"),
    "motorbike": ("motorbike", "motorcycle", "motorbikes", "motorcycles", "xe máy", "xe may"),
    "bicycle": ("bicycle", "bike", "bicycles", "bikes", "xe đạp", "xe dap"),
    "dog": ("dog", "dogs", "puppy", "chó", "cho"),
    "cat": ("cat", "cats", "kitten", "mèo", "meo"),
    "chair": ("chair", "chairs", "ghế", "ghe"),
    "table": ("table", "tables", "desk", "desks", "bàn", "ban"),
    "bottle": ("bottle", "bottles", "chai"),
    "cup": ("cup", "cups", "mug", "mugs", "cốc", "coc", "ly"),
    "phone": ("phone", "cellphone", "mobile", "điện thoại", "dien thoai"),
    "building": ("building", "buildings", "skyscraper", "tòa nhà", "toa nha"),
    "tree": ("tree", "trees", "cây", "cay"),
}


def parse_counting_target(question: str) -> tuple[bool, str]:
    """Identify if the question is a counting question and extract the target object class."""
    normalized = question.casefold()
    is_count = any(word in normalized for word in COUNT_WORDS)
    if not is_count:
        return False, ""

    for target_class, aliases in OBJECT_TARGET_PATTERNS.items():
        if any(re.search(rf"\b{re.escape(alias)}\b", normalized) for alias in aliases):
            return True, target_class

    return True, "person"  # default count target if ambiguous


def parse_existence_target(question: str) -> tuple[bool, str]:
    """Identify if the question is an existence question (Is there a... / Có...không)."""
    normalized = question.casefold()
    is_polar = any(normalized.startswith(prefix) for prefix in ("is there", "are there", "có ", "co ")) or "có " in normalized
    if not is_polar:
        return False, ""

    for target_class, aliases in OBJECT_TARGET_PATTERNS.items():
        if any(re.search(rf"\b{re.escape(alias)}\b", normalized) for alias in aliases):
            return True, target_class

ADJECTIVE_ATTRIBUTE_PATTERNS: list[str] = [
    # Colors
    r"\b(?:red|blue|green|yellow|white|black|silver|pink|purple|orange|gray|grey|dark|bright|brown|golden)\b",
    r"\b(?:màu đỏ|màu xanh|màu vàng|màu trắng|màu đen|màu hồng|màu tím|màu cam|màu xám|màu nâu)\b",
    # Posture, state, actions
    r"\b(?:standing|sitting|walking|running|wearing|holding|carrying|riding|sleeping|eating|cooking|talking|swimming|flying|driving)\b",
    r"\b(?:đang đứng|đang ngồi|đang đi|đang chạy|mặc|đeo|cầm|mang|chở|đang ăn|đang nói|đang bơi|đang bay|đang lái)\b",
    # Status & condition
    r"\b(?:open|closed|empty|full|broken|working|damaged|lit|turned on|turned off)\b",
    r"\b(?:mở|đóng|trống|đầy|hỏng|bật|tắt)\b",
    # Materials, size, types
    r"\b(?:wooden|glass|plastic|metallic|leather|concrete|small|little|big|large|tall|short|young|old|police|electric)\b",
    r"\b(?:bằng gỗ|bằng kính|bằng nhựa|bằng kim loại|bằng da|nhỏ|bé|to|lớn|cao|thấp|trẻ|già|công an|cảnh sát)\b",
    # Prepositional / Relational modifiers
    r"\b(?:with|in front of|behind|near|next to|above|under|inside|outside)\b",
    r"\b(?:có mang|có đeo|ở phía trước|ở phía sau|bên cạnh|ở trên|ở dưới|trong|ngoài)\b",
]


def has_visual_attributes(question: str) -> bool:
    """Detect if the counting question contains adjectives, colors, actions, or attribute modifiers."""
    q_lower = question.lower()
    return any(re.search(pat, q_lower) for pat in ADJECTIVE_ATTRIBUTE_PATTERNS)


def is_person_count_question(question: str) -> bool:
    is_count, target = parse_counting_target(question)
    return is_count and target == "person"


def _answer_object_count(
    top_kis_results: list[dict], target_class: str, question: str
) -> tuple[list[dict], float]:
    if not top_kis_results:
        return [], 0.0

    from concurrent.futures import ThreadPoolExecutor

    vlm_started_at = time.perf_counter()
    strategy = settings.VQA_COUNTING_STRATEGY.lower().strip()
    has_attr = has_visual_attributes(question)

    def _process_count_candidate(result: dict) -> dict:
        candidate = result.copy()
        keyframe_id = int(candidate.get("keyframe_id", candidate.get("frame_id", 1)))

        # Run Scale-Aware & Density-Clustered Local Engine on Faster R-CNN JSON
        scale_res = object_store.count_scale_aware(
            candidate["video_id"],
            keyframe_id,
            target_class,
        )

        candidate["json_count"] = scale_res["count"]
        candidate["json_bboxes"] = scale_res["bboxes"]
        candidate["status"] = scale_res["status"]

        # If pure count (no adjectives/actions) and JSON index is healthy -> 0 tokens local speed (<1ms)
        if not has_attr and strategy != "vlm_only" and scale_res["status"] in ("scale_aware_rcnn", "noise_suppressed"):
            candidate["answer"] = str(scale_res["count"])
            candidate["source"] = "FASTER_RCNN_JSON"
            candidate["vlm_raw_log"] = ""
        else:
            # When adjectives, colors, postures, or actions are specified -> VLM visually verifies the attribute!
            image_path = keyframe_image_path(
                candidate["video_id"],
                keyframe_id,
                keyframes_dir=settings.KEYFRAMES_DIR,
            )
            vlm_raw_log = vqa_engine.answer_single_image(
                image_path,
                build_vqa_prompt(question),
            )
            candidate["answer"] = vlm_raw_log[:100]
            candidate["source"] = "DUAL_VERIFIED_VLM" if scale_res["count"] > 0 else "VLM_API"
            candidate["vlm_raw_log"] = vlm_raw_log

        return candidate

    max_workers = min(len(top_kis_results), settings.VQA_MAX_CONCURRENCY)
    if max_workers <= 1:
        processed_results = [_process_count_candidate(r) for r in top_kis_results]
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            processed_results = list(executor.map(_process_count_candidate, top_kis_results))

    vlm_time_ms = round((time.perf_counter() - vlm_started_at) * 1000, 2)
    return processed_results, vlm_time_ms



def answer_vqa_question(
    top_kis_results: list[dict],
    question: str,
) -> tuple[list[dict], float]:
    """Answer a VQA query from KIS-ranked keyframe candidates with 0-token CV fast-paths."""
    if not top_kis_results:
        return [], 0.0

    # 1. Scale-Aware Counting Fast-Path
    is_count, target_class = parse_counting_target(question)
    if is_count and target_class:
        return _answer_object_count(top_kis_results, target_class, question)

    # 2. Binary Existence Fast-Path
    is_exist, exist_target = parse_existence_target(question)
    if is_exist and exist_target and top_kis_results:
        first_cand = top_kis_results[0]
        kf_id = int(first_cand.get("keyframe_id", first_cand.get("frame_id", 1)))
        detections = object_store.find_by_class(first_cand["video_id"], kf_id, exist_target, threshold=0.65)
        if detections:
            processed = []
            for r in top_kis_results:
                c = r.copy()
                c["answer"] = "yes"
                c["source"] = "FASTER_RCNN_JSON"
                processed.append(c)
            return processed, 0.5

    # 3. 0-Token Classical CV HSV Color Reasoner (< 2ms)
    try:
        from app.algorithms.symbolic_reasoner import (
            is_color_question,
            answer_symbolic_color_vqa,
            is_position_question,
            answer_symbolic_position_vqa,
        )
        if is_color_question(question):
            first_cand = top_kis_results[0]
            kf_id = int(first_cand.get("keyframe_id", first_cand.get("frame_id", 1)))
            detections = object_store.get_detections(first_cand["video_id"], kf_id)
            if detections:
                img_path = keyframe_image_path(first_cand["video_id"], kf_id, keyframes_dir=settings.KEYFRAMES_DIR)
                color_ans = answer_symbolic_color_vqa(img_path, [d["box"] for d in detections[:2]])
                if color_ans and color_ans != "unknown":
                    processed = []
                    for r in top_kis_results:
                        c = r.copy()
                        c["answer"] = color_ans
                        c["source"] = "SYMBOLIC_HSV_CV"
                        processed.append(c)
                    return processed, 1.2

        # 4. 0-Token Centroid Spatial Position Reasoner (< 1ms)
        if is_position_question(question):
            first_cand = top_kis_results[0]
            kf_id = int(first_cand.get("keyframe_id", first_cand.get("frame_id", 1)))
            detections = object_store.get_detections(first_cand["video_id"], kf_id)
            if detections:
                pos_ans = answer_symbolic_position_vqa([d["box"] for d in detections[:1]])
                if pos_ans:
                    processed = []
                    for r in top_kis_results:
                        c = r.copy()
                        c["answer"] = pos_ans
                        c["source"] = "SYMBOLIC_CENTROID_CV"
                        processed.append(c)
                        return processed, 0.8
    except Exception as exc:
        logger.debug("Symbolic CV reasoning fallback to VLM: %s", exc)

    # 5. Tier 2 OCR Token Resolver (< 1ms, 0-Token)
    try:
        from app.services.ocr_store import ocr_store
        ocr_patterns = (
            "text", "number", "word", "name", "written", "sign", "license", "plate",
            "chữ gì", "chu gi", "số mấy", "so may", "biển số", "bảng hiệu", "tên gì"
        )
        q_low = question.lower()
        if any(p in q_low for p in ocr_patterns):
            first_cand = top_kis_results[0]
            v_id = str(first_cand.get("video_id", ""))
            f_id = int(first_cand.get("keyframe_id", first_cand.get("frame_id", 1)))
            ocr_text = ocr_store.get_frame_ocr_text(v_id, f_id) if hasattr(ocr_store, "get_frame_ocr_text") else ""
            if ocr_text and ocr_text.strip():
                processed = []
                for r in top_kis_results:
                    c = r.copy()
                    c["answer"] = ocr_text.strip()
                    c["source"] = "OCR_TOKEN_RESOLVER"
                    processed.append(c)
                return processed, 0.9
    except Exception as exc:
        logger.debug("OCR VQA resolver fallback to VLM: %s", exc)

    # 6. Dual-Verified VLM Fallback
    vlm_started_at = time.perf_counter()
    results = vqa_engine.answer(top_kis_results, question)
    vlm_time_ms = round((time.perf_counter() - vlm_started_at) * 1000, 2)
    return results, vlm_time_ms
