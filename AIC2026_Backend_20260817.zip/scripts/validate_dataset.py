"""Validate the configured FAISS index, metadata mapping, and keyframe files."""

import json
import sys
from pathlib import Path

from app.core.config import settings
from app.core.exceptions import DatasetValidationError
from app.vector.faiss_store import FaissVectorStore


def main() -> int:
    try:
        store = FaissVectorStore(settings.FAISS_INDEX_PATH, settings.METADATA_PATH)
        static_root = settings.STATIC_DIR.resolve()
        feature_root = settings.FEATURE_ROOT.resolve()
        missing_images = []
        missing_features = []
        for item in store.metadata:
            image_path = Path(str(item["image_path"])).resolve()
            try:
                image_path.relative_to(static_root)
            except ValueError:
                missing_images.append(item["vector_id"])
                continue
            if not image_path.is_file():
                missing_images.append(item["vector_id"])
            feature_path = Path(str(item["feature_path"])).resolve()
            try:
                feature_path.relative_to(feature_root)
            except ValueError:
                missing_features.append(item["vector_id"])
                continue
            if not feature_path.is_file():
                missing_features.append(item["vector_id"])
        if missing_images:
            raise DatasetValidationError(
                f"{len(missing_images)} metadata records reference missing or unsafe image files."
            )
        if missing_features:
            raise DatasetValidationError(
                f"{len(missing_features)} metadata records reference missing or unsafe feature files."
            )
    except DatasetValidationError as exc:
        print(json.dumps({"status": "invalid", "error": exc.message}))
        return 1

    print(
        json.dumps(
            {
                "status": "valid",
                "dimension": store.stats.dimension,
                "vector_count": store.stats.vector_count,
                "metadata_count": store.stats.metadata_count,
            }
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
