"""Automated Mock Contest Evaluation Harness & Codabench Packager for AIC 2026.

Calculates Top-1 Accuracy, Recall@5/10, Mean Reciprocal Rank (MRR), VQA Accuracy,
TRAKE Monotonic Sequence Consistency, and P50/P95 Latency SLAs against competition benchmarks.
"""

from __future__ import annotations

import csv
import json
import logging
import time
import zipfile
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any
import numpy as np
import requests

logger = logging.getLogger(__name__)


@dataclass
class QueryEvaluationResult:
    query_id: str
    task_type: str
    query_text: str
    top1_hit: bool = False
    top5_hit: bool = False
    top10_hit: bool = False
    reciprocal_rank: float = 0.0
    vqa_correct: bool | None = None
    vqa_answer: str = ""
    vqa_source: str = ""
    trake_monotonic: bool | None = None
    trake_submission: str = ""
    matched_video_id: str = ""
    matched_frame_id: int = 0
    matched_timestamp: float = 0.0
    latency_ms: float = 0.0
    rank_found: int = -1
    # Official competition metric per query (R@1 ... R@100 max, then mean)
    official_query_score: float = 0.0
    details: str = ""


@dataclass
class BenchmarkSummary:
    benchmark_name: str
    total_queries: int
    evaluated_at: str
    top1_accuracy: float = 0.0
    recall_at_5: float = 0.0
    recall_at_10: float = 0.0
    mrr: float = 0.0
    # --- Official competition scoring (Codabench Mean-of-Top-k-max-R@k) ---
    official_mean_score: float = 0.0        # mean over queries of their official_query_score
    r_at_1: float = 0.0                     # % queries where GT is in top-1
    r_at_5: float = 0.0                     # % queries where GT is in top-5
    r_at_20: float = 0.0                    # % queries where GT is in top-20
    r_at_50: float = 0.0                    # % queries where GT is in top-50
    r_at_100: float = 0.0                   # % queries where GT is in top-100
    # ---
    vqa_accuracy: float = 0.0
    trake_sequence_accuracy: float = 0.0
    p50_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    p99_latency_ms: float = 0.0
    mean_latency_ms: float = 0.0
    max_latency_ms: float = 0.0
    sla_compliance_pct: float = 0.0
    results: list[QueryEvaluationResult] = field(default_factory=list)


def evaluate_benchmark(
    ground_truth_path: Path | str = "data/mock_contest_ground_truth.json",
    base_url: str = "http://localhost:8000",
    task_filter: str | None = None,
    top_k: int = 10,
    tolerance_seconds: float = 30.0,
) -> BenchmarkSummary:
    """Run evaluation benchmark against live search API and calculate comprehensive metrics."""
    gt_file = Path(ground_truth_path)
    if not gt_file.is_file():
        raise FileNotFoundError(f"Benchmark ground truth file not found: {gt_file}")

    data = json.loads(gt_file.read_text(encoding="utf-8"))
    benchmark_name = data.get("benchmark_name", "AIC Mock Benchmark")
    all_queries = data.get("queries", [])

    if task_filter and task_filter.upper() != "ALL":
        queries = [q for q in all_queries if q.get("task_type", "").upper() == task_filter.upper()]
    else:
        queries = all_queries

    results: list[QueryEvaluationResult] = []
    latencies: list[float] = []

    for q in queries:
        q_id = q["query_id"]
        t_type = q["task_type"]
        t_text = q.get("query", "")
        exp_vid = q.get("expected_video_id", "")
        exp_fid = q.get("expected_frame_id", 0)
        exp_ts = q.get("expected_timestamp", 0.0)
        acceptable_vids = set(q.get("acceptable_video_ids", [exp_vid]))

        eval_res = QueryEvaluationResult(
            query_id=q_id,
            task_type=t_type,
            query_text=t_text or " -> ".join(q.get("events", [])),
        )

        started_at = time.perf_counter()

        try:
            if t_type == "TRAKE":
                payload = {
                    "type": "TRAKE",
                    "task_type": "TRAKE",
                    "events": q.get("events", []),
                    "top_k": top_k,
                }
                resp = requests.post(f"{base_url}/api/search", json=payload, timeout=20)
            elif t_type == "VQA":
                payload = {
                    "type": "VQA",
                    "task_type": "VQA",
                    "query": t_text,
                    "question": q.get("question", ""),
                    "top_k": top_k,
                }
                resp = requests.post(f"{base_url}/api/search", json=payload, timeout=20)
            else:  # KIS
                payload = {
                    "type": "KIS",
                    "task_type": "KIS",
                    "query": t_text,
                    "top_k": top_k,
                }
                resp = requests.post(f"{base_url}/api/search", json=payload, timeout=20)

            elapsed_ms = round((time.perf_counter() - started_at) * 1000, 2)
            eval_res.latency_ms = elapsed_ms
            latencies.append(elapsed_ms)

            if resp.status_code == 200:
                res_data = resp.json()
                items = res_data.get("results", [])

                # 1. KIS Evaluation
                if t_type == "KIS":
                    for rank_idx, item in enumerate(items, start=1):
                        vid = str(item.get("video_id", ""))
                        fid = int(item.get("frame_id", item.get("keyframe_id", 0)))
                        ts = float(item.get("timestamp", 0.0))

                        # Check match by video and temporal tolerance
                        is_vid_match = vid in acceptable_vids
                        is_time_match = (exp_ts <= 0.0) or (abs(ts - exp_ts) <= tolerance_seconds)

                        if is_vid_match and is_time_match:
                            eval_res.rank_found = rank_idx
                            eval_res.reciprocal_rank = round(1.0 / rank_idx, 4)
                            eval_res.top1_hit = (rank_idx == 1)
                            eval_res.top5_hit = (rank_idx <= 5)
                            eval_res.top10_hit = (rank_idx <= 10)
                            eval_res.matched_video_id = vid
                            eval_res.matched_frame_id = fid
                            eval_res.matched_timestamp = ts
                            break

                # 2. VQA Evaluation
                elif t_type == "VQA":
                    if items:
                        first_item = items[0]
                        ans = str(first_item.get("answer", "")).strip().lower()
                        src = str(first_item.get("source", ""))
                        eval_res.vqa_answer = ans
                        eval_res.vqa_source = src

                        expected_ans = str(q.get("expected_answer", "")).strip().lower()
                        acceptable_answers = [a.lower() for a in q.get("acceptable_answers", [expected_ans])]

                        eval_res.vqa_correct = any(acc in ans for acc in acceptable_answers)
                        eval_res.matched_video_id = str(first_item.get("video_id", ""))
                        eval_res.matched_frame_id = int(first_item.get("frame_id", first_item.get("keyframe_id", 0)))

                # 3. TRAKE Evaluation
                elif t_type == "TRAKE":
                    eval_res.trake_submission = res_data.get("submission_line", "")
                    if len(items) >= 2:
                        timestamps = [float(it.get("timestamp", 0.0)) for it in items]
                        video_ids = [str(it.get("video_id", "")) for it in items]
                        is_same_video = (len(set(video_ids)) == 1)
                        is_strictly_increasing = all(
                            timestamps[i] < timestamps[i + 1] for i in range(len(timestamps) - 1)
                        )
                        eval_res.trake_monotonic = is_same_video and is_strictly_increasing
                        if items:
                            eval_res.matched_video_id = video_ids[0]
                    else:
                        eval_res.trake_monotonic = False

            else:
                eval_res.details = f"HTTP {resp.status_code}: {resp.text[:100]}"

        except Exception as exc:
            eval_res.latency_ms = round((time.perf_counter() - started_at) * 1000, 2)
            eval_res.details = f"Exception: {exc}"

        results.append(eval_res)

    # Compute Global Summary Metrics
    total = len(results)
    kis_results = [r for r in results if r.task_type == "KIS"]
    vqa_results = [r for r in results if r.task_type == "VQA"]
    trake_results = [r for r in results if r.task_type == "TRAKE"]

    top1_acc = (sum(1 for r in kis_results if r.top1_hit) / len(kis_results) * 100.0) if kis_results else 0.0
    r5 = (sum(1 for r in kis_results if r.top5_hit) / len(kis_results) * 100.0) if kis_results else 0.0
    r10 = (sum(1 for r in kis_results if r.top10_hit) / len(kis_results) * 100.0) if kis_results else 0.0
    mrr_val = (sum(r.reciprocal_rank for r in kis_results) / len(kis_results)) if kis_results else 0.0

    # --- Official competition scoring: Mean-of-Top-k-max-R@k ---
    # R@k = 1 if GT found within top-k, else 0 (binary per query)
    # official_query_score = mean(R@1, R@5, R@20, R@50, R@100) per query
    OFFICIAL_K = (1, 5, 20, 50, 100)

    def _r_at_k_for_result(res: QueryEvaluationResult, k: int) -> float:
        if res.task_type == "VQA":
            return 1.0 if (res.vqa_correct and res.rank_found >= 1 and res.rank_found <= k) else 0.0
        if res.task_type == "TRAKE":
            return 1.0 if res.trake_monotonic else 0.0
        # KIS: binary by rank
        return 1.0 if (res.rank_found >= 1 and res.rank_found <= k) else 0.0

    for res in results:
        r_at_k_vals = [_r_at_k_for_result(res, k) for k in OFFICIAL_K]
        res.official_query_score = round(sum(r_at_k_vals) / len(r_at_k_vals), 6)

    official_mean = sum(r.official_query_score for r in results) / total if total else 0.0
    r_at_1 = sum(_r_at_k_for_result(r, 1) for r in results) / total * 100.0 if total else 0.0
    r_at_5 = sum(_r_at_k_for_result(r, 5) for r in results) / total * 100.0 if total else 0.0
    r_at_20 = sum(_r_at_k_for_result(r, 20) for r in results) / total * 100.0 if total else 0.0
    r_at_50 = sum(_r_at_k_for_result(r, 50) for r in results) / total * 100.0 if total else 0.0
    r_at_100 = sum(_r_at_k_for_result(r, 100) for r in results) / total * 100.0 if total else 0.0

    vqa_acc = (sum(1 for r in vqa_results if r.vqa_correct) / len(vqa_results) * 100.0) if vqa_results else 0.0
    trake_acc = (sum(1 for r in trake_results if r.trake_monotonic) / len(trake_results) * 100.0) if trake_results else 0.0

    p50 = float(np.percentile(latencies, 50)) if latencies else 0.0
    p95 = float(np.percentile(latencies, 95)) if latencies else 0.0
    p99 = float(np.percentile(latencies, 99)) if latencies else 0.0
    mean_lat = float(np.mean(latencies)) if latencies else 0.0
    max_lat = float(np.max(latencies)) if latencies else 0.0
    sla_pct = (sum(1 for l in latencies if l <= 1000.0) / len(latencies) * 100.0) if latencies else 0.0

    summary = BenchmarkSummary(
        benchmark_name=benchmark_name,
        total_queries=total,
        evaluated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        top1_accuracy=round(top1_acc, 2),
        recall_at_5=round(r5, 2),
        recall_at_10=round(r10, 2),
        mrr=round(mrr_val, 4),
        official_mean_score=round(official_mean, 6),
        r_at_1=round(r_at_1, 2),
        r_at_5=round(r_at_5, 2),
        r_at_20=round(r_at_20, 2),
        r_at_50=round(r_at_50, 2),
        r_at_100=round(r_at_100, 2),
        vqa_accuracy=round(vqa_acc, 2),
        trake_sequence_accuracy=round(trake_acc, 2),
        p50_latency_ms=round(p50, 2),
        p95_latency_ms=round(p95, 2),
        p99_latency_ms=round(p99, 2),
        mean_latency_ms=round(mean_lat, 2),
        max_latency_ms=round(max_lat, 2),
        sla_compliance_pct=round(sla_pct, 2),
        results=results,
    )

    return summary


def package_codabench_submission(
    summary: BenchmarkSummary,
    output_dir: Path | str = "data/submissions",
) -> Path:
    """Format and package competition results into official Codabench submission zip archive.

    Produces per-query CSV files inside a ``submission/`` folder, exactly as
    the competition platform requires:
        submission/query-1-kis.csv   →  rows of [video_id, frame_id]  (up to 100)
        submission/query-2-qa.csv    →  single row [video_id, frame_id, answer]
        submission/query-3-trake.csv →  single row [video_id, f1, f2, ..., fN]
    """
    from app.features.submission.csv_export import (
        build_codabench_zip,
        codabench_csv_name,
    )
    from app.features.submission.adapter import results_to_csv_rows, TASK_TYPE_ALIASES

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_file = out_dir / f"codabench_submission_{timestamp}.zip"

    # Build one entry per query result
    entries: list[tuple[str, list, str]] = []
    for i, res in enumerate(summary.results, start=1):
        task_type = res.task_type.upper()
        # Map internal type → canonical type
        canonical = TASK_TYPE_ALIASES.get(task_type, task_type)

        if canonical == "KIS":
            rows = [
                [res.matched_video_id, res.matched_frame_id]
            ] if res.matched_video_id else []
        elif canonical == "QA":
            rows = [
                [res.matched_video_id, res.matched_frame_id, res.vqa_answer]
            ] if res.matched_video_id and res.vqa_answer else []
        elif canonical == "TR":
            # TRAKE: parse event frames from submission line  TR-<video>-f1,f2,...
            rows = []
            if res.trake_submission and res.trake_submission.startswith("TR-"):
                parts = res.trake_submission[3:].split("-", 1)
                if len(parts) == 2:
                    vid = parts[0]
                    frames = [int(f) for f in parts[1].split(",") if f.strip().isdigit()]
                    if vid and frames:
                        rows = [[vid, *frames]]
        else:
            rows = []

        csv_filename = codabench_csv_name(i, task_type)
        entries.append((csv_filename, rows, task_type))

    build_codabench_zip(zip_file, entries)
    return zip_file
