# =============================================================================
#  AIC 2026 - Smart Server Launcher (AutoDetect, AutoTune, Server)
# =============================================================================
[CmdletBinding()]
param (
    [switch]$Benchmark,
    [switch]$Test,
    [switch]$AutoTune,
    [switch]$ForceReindex,
    [int]$Port = 8000,
    [string]$HostIP = "0.0.0.0",
    [Alias("h")]
    [switch]$Help
)

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"

$pythonExe = Join-Path "$PSScriptRoot" ".venv\Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    $pythonExe = "python"
}

if ($Benchmark) {
    Write-Host ">>> Running AIC 2026 Open-World Codabench Benchmark on Real Data..." -ForegroundColor Cyan
    & $pythonExe (Join-Path "$PSScriptRoot" "scripts\run_open_world_benchmark.py")
    exit $LASTEXITCODE
}

if ($Test) {
    Write-Host ">>> Running Complete Automated Test Suite (44 Tests)..." -ForegroundColor Cyan
    $pytestExe = Join-Path "$PSScriptRoot" ".venv\Scripts\pytest.exe"
    if (Test-Path $pytestExe) {
        & $pytestExe (Join-Path "$PSScriptRoot" "tests\test_all_features.py") (Join-Path "$PSScriptRoot" "tests\test_speculative_consensus.py") -v
    } else {
        & $pythonExe -m pytest (Join-Path "$PSScriptRoot" "tests\test_all_features.py") (Join-Path "$PSScriptRoot" "tests\test_speculative_consensus.py") -v
    }
    exit $LASTEXITCODE
}

# --- Default Server Launcher Mode --------------------------------------------
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "         AIC 2026 BACKEND SMART SERVER LAUNCHER                  " -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan

Write-Host "[1/5] Checking Port $Port status..." -ForegroundColor Yellow
try {
    $connections = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($connections) {
        foreach ($conn in $connections) {
            $pidToKill = $conn.OwningProcess
            if ($pidToKill -gt 0) {
                Write-Host "      Freeing stale process (PID: $pidToKill) on port $Port..." -ForegroundColor Yellow
                Stop-Process -Id $pidToKill -Force -ErrorAction SilentlyContinue
            }
        }
        Start-Sleep -Milliseconds 500
        Write-Host "      Port $Port is now completely free." -ForegroundColor Green
    } else {
        Write-Host "      Port $Port is ready." -ForegroundColor Green
    }
} catch {
    Write-Host "      Port check completed." -ForegroundColor Gray
}

Write-Host "[2/5] Checking Docker Milvus Vector Store (Port 19530)..." -ForegroundColor Yellow
$milvusPortActive = $false
try {
    $milvusConn = Test-NetConnection -ComputerName 127.0.0.1 -Port 19530 -WarningAction SilentlyContinue
    if ($milvusConn.TcpTestSucceeded) {
        $milvusPortActive = $true
        Write-Host "      Milvus Standalone is ACTIVE on port 19530 (HNSW Hybrid Mode ready)." -ForegroundColor Green
    }
} catch {}

if (-not $milvusPortActive) {
    Write-Host "      Milvus not detected on port 19530." -ForegroundColor Yellow
    $dockerCmd = Get-Command docker -ErrorAction SilentlyContinue
    if ($dockerCmd) {
        Write-Host "      Attempting to launch Milvus via Docker Compose..." -ForegroundColor Yellow
        & docker compose up -d milvus 2>$null
        Start-Sleep -Seconds 2
    } else {
        Write-Host "      Docker not running. FAISS in-memory C++ engine will handle 100% of queries seamlessly." -ForegroundColor Cyan
    }
}

Write-Host "[3/5] Checking dataset integrity & new feature batches..." -ForegroundColor Yellow
$featuresDir = Join-Path "$PSScriptRoot" "data\features"
$faissIndex = Join-Path "$PSScriptRoot" "data\faiss_index.bin"
$gtJson = Join-Path "$PSScriptRoot" "data\mock_contest_ground_truth.json"

$newDataDetected = $false

if (Test-Path $featuresDir) {
    $latestFeature = Get-ChildItem -Path $featuresDir -Filter "*.npy" -Recurse -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    
    if (-not (Test-Path $faissIndex)) {
        $newDataDetected = $true
        Write-Host "      [ALERT] faiss_index.bin is missing. Vector index needs to be built!" -ForegroundColor Magenta
    } elseif ($latestFeature) {
        $indexTime = (Get-Item $faissIndex).LastWriteTime
        if ($latestFeature.LastWriteTime -gt $indexTime) {
            $newDataDetected = $true
            Write-Host "      [ALERT] New feature file detected ($($latestFeature.Name)) newer than faiss_index.bin!" -ForegroundColor Magenta
        }
    }
}

if ($ForceReindex -or $newDataDetected) {
    Write-Host "      Building FAISS Vector Index (build_index.py)..." -ForegroundColor Yellow
    & $pythonExe (Join-Path "$PSScriptRoot" "build_index.py")
}

Write-Host "      [AUTO-TUNE] Running hyperparameter auto-tuner to find optimal parameters for KIS..." -ForegroundColor Cyan
& $pythonExe -u (Join-Path "$PSScriptRoot" "scripts\tune_hyperparameters.py") --mode presets --suite kis --apply

Write-Host "[4/5] Auto-detecting Hardware Accelerator (CPU/GPU)..." -ForegroundColor Yellow
$gpuCheck = & $pythonExe -c "import torch; print('GPU_ACTIVE') if torch.cuda.is_available() else print('CPU_ONLY')"
if ($gpuCheck -match "GPU_ACTIVE") {
    Write-Host "      CUDA GPU detected! Heavy spatial AI algorithms will be ENABLED." -ForegroundColor Green
} else {
    Write-Host "      CPU only detected. Heavy spatial AI algorithms will be DISABLED for speed." -ForegroundColor Cyan
}

Write-Host "[5/5] Starting FastAPI High-Throughput Server on http://${HostIP}:${Port}..." -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Cyan

$uvicornCmd = Join-Path "$PSScriptRoot" ".venv\Scripts\uvicorn.exe"
if (-not (Test-Path $uvicornCmd)) {
    & $pythonExe -m uvicorn main:app --host $HostIP --port $Port
} else {
    & $uvicornCmd main:app --host $HostIP --port $Port
}
