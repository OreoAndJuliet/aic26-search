INSTALLER AUDIT, GUIDE, AND FIXES
=================================

Generated: 2026-08-16T04:34:53+07:00
Repository root: d:\test1\2026-08-15_1057

Purpose
-------
This document bundles a scan, explanation, run commands, logic review, known flaws, and recommended fixes for the repository's installer/test automation and the robocopy-based backup script. It is intended to be checked into the repository (scripts/INSTALLER_AUDIT_AND_GUIDE.md) as a single source of truth for maintainers and CI.

Files reviewed
--------------
- install_all.ps1 (root)
- setup.ps1 (root)
- test.ps1 (root)
- scripts\backup_robo.ps1

Summary of intent (what each script does)
-----------------------------------------
- setup.ps1
  - Create a Python virtual environment (.venv by default)
  - Upgrade pip/setuptools/wheel
  - Install Python dependencies (requirements.txt or editable install)
  - Optionally run a backup (scripts\backup_robo.ps1) when -Backup is passed
  - Create a .env from example files if none exists

- install_all.ps1
  - Top-level orchestrator: calls setup.ps1, optionally uses Docker/Docker Compose to build/run containers, then runs test.ps1
  - Has flags: -SkipDocker, -SkipBuild, -NonInteractive

- test.ps1
  - Starts backend (docker-compose or local uvicorn) to make HTTP tests available
  - Waits for /health to respond
  - Runs pytest and the eval harness scripts
  - Optionally runs PowerShell-style tests in tests\test_*.ps1

- scripts\backup_robo.ps1
  - Uses robocopy to copy repository and data to a destination timestamped folder
  - Default exclusion for large folders (static, venv), creates skeleton directories for static if skipping static
  - Has options for DryRun, Mirror, IncludeVenv, IncludeStatic, and retention (Keep)

How to run (recommended commands)
---------------------------------
Run interactive (developer):
- Open PowerShell (Developer) in repository root (right-click > "Open in Terminal")
- Allow script execution for the session and run setup:
  powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -PythonExe "C:\Path\To\python.exe"

To run full automated install, build, and tests (non-interactive):
  powershell -NoProfile -ExecutionPolicy Bypass -File .\install_all.ps1 -PythonExe "C:\Path\To\python.exe" -SkipDocker -NonInteractive

Run tests only (prefer .venv python when created):
  powershell -NoProfile -ExecutionPolicy Bypass -File .\test.ps1 -PythonExe "C:\Path\To\python.exe"

Run backup (example):
  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\backup_robo.ps1 -Source "D:\myproject" -DestinationRoot "D:\backups\project" -DryRun

Notes for CI (Windows runner)
- Use the same commands but avoid interactive prompts. For example: install_all.ps1 -PythonExe "%PYTHON%" -NonInteractive -SkipDocker (or ensure Docker present in the runner).
- Ensure ExecutionPolicy Bypass is allowed on the runner or run PowerShell with the -ExecutionPolicy argument as shown above.

Detailed logic review and issues (per-file)
-------------------------------------------
1) install_all.ps1
 - Flow: setup -> docker availability check -> docker build/compose -> run test.ps1
 - Strengths:
   - Uses $ErrorActionPreference = "Stop" and wraps calls in try/catch for resilience.
   - Offers non-interactive mode fallback when Docker missing.
 - Issues / improvements:
   - Root detection uses (Get-Location).Path. If script is invoked from a different working directory (not repository root), it uses the current directory instead of the script file location. Recommend using $PSScriptRoot or resolve the script file path by $MyInvocation.MyCommand.Path to derive repo root reliably.
   - setup.ps1 call: errors from setup are swallowed (Write-Warn) but the script continues. For a full install route, some setup failures must abort the process (or at least the caller should detect critical failures via non-zero exit codes). Consider rethrowing or exiting with a non-zero code on critical failures.
   - Docker detection: command runs `docker --version` and checks $LASTEXITCODE. This is OK, but consider checking for both `docker` and `docker compose` availability separately if you intend to use `docker compose`.
   - When docker build or compose fails, the script warns and continues; for CI runs you may want the build step to fail early (configurable flag to treat Docker errors as fatal).

Recommended changes (install_all.ps1):
 - Use script-file-root resolution: $root = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
 - Propagate error codes on critical failures (add parameter -FailOnSetupError or throw/exit when setup fails unless a flag is set)
 - Add Start-Transcript to capture full output to a log file for diagnostics

2) setup.ps1
 - Flow: optional backup -> create .venv -> upgrade pip -> install requirements -> create .env
 - Strengths: clearly enumerates requirements file candidates; uses virtualenv if missing
 - Issues found:
   - The list envCandidates contains entries with leading spaces in the array: `@(' .env.example',' .env.sample',...)` which will cause the Trim logic below to work but is confusing and duplicates. There are duplicate entries too. Clean this list to: @('.env.example', '.env.sample', '.env.template')
   - Copy-Item used without quoting can misbehave for source/destination names with spaces. Use Join-Path and ensure Copy-Item handles paths; currently it uses Join-Path so OK.
   - $pipPath is computed as `if (Test-Path (Join-Path $venvPath 'Scripts\pip.exe')) { Join-Path $venvPath 'Scripts\pip.exe' } else { "$PythonExe -m pip" }` then $pipPath is not always a single executable path; but the script later consistently calls $pythonExePath -m pip ... which is safe. The $pipPath variable is unused later; remove or use consistently.
   - `& $PythonExe -m venv $venvPath` uses whatever PythonExe path is passed; failing here is fatal but the script catches $LASTEXITCODE; good.
   - The script does not check free disk space before venv or pip installs (useful for large installs).

Recommended changes (setup.ps1):
 - Fix envCandidates array (remove leading spaces and duplicates).
 - Remove unused $pipPath or make it accurate.
 - Use $PSScriptRoot or $MyInvocation.MyCommand.Definition to determine repo root reliably.
 - On requirement installs, add `--no-cache-dir` if desired for CI, and capture return codes explicitly and fail when installation fails unless -InstallDeps is false.
 - Consider using `python -m pip install -r` with `-q` in CI to reduce noise; but keep verbose for local debugging.
 - Optionally create a .env.example sanitizer: do not blindly copy secrets; present the user with a template and require manual secrets entry.

3) test.ps1
 - Flow: start backend (docker compose or local uvicorn) -> wait for /health -> run pytest -> run eval harness -> run tests/test_*.ps1 -> stop backend
 - Issues / improvements:
   - Health check uses hardcoded port 8000 and the /health path. That is fine for local but install_all earlier used 8001 in some test harnesses. Prefer making the port configurable via env or script parameter (e.g., -BackendPort 8000) so all scripts and integration tests align.
   - Start-Backend uses Start-Process to run `python -m uvicorn main:app`. `Start-Sleep -Seconds 1` may be too short for startup; the script later waits for /health but increasing the initial sleep or making the Start-Backend return only after first health probe could avoid races.
   - Start-Backend doesn't redirect stdout/stderr to a log file; capturing these logs is important for debugging failing tests. Add Start-Transcript or Start-Process -RedirectStandardOutput/RedirectStandardError to files.
   - Stop-Backend uses `docker compose down -v` without checking for errors; ensure it is invoked only if compose was started successfully.
   - Running pytest without a timeout wrapper is OK, but the param PytestTimeoutSeconds exists but is not enforced. Consider invoking pytest as a child process and killing it if it exceeds the timeout.
   - Eval harness uses temp CSV; good, but harness invocations swallow errors (warn and continue). For CI you may want to make eval failures visible.

Recommended changes (test.ps1):
 - Add parameter -BackendPort and use it consistently when starting uvicorn and checking /health
 - Capture backend stdout/stderr to a logfile under $root\logs for later inspection
 - Use a robust wait-for-health loop with exponential backoff and more logging
 - Implement PytestTimeoutSeconds by launching pytest via Start-Process and using Wait-Process with timeout

4) scripts\backup_robo.ps1
 - Flow: copy from $Source to destination timestamped folder using robocopy with exclusions; optionally create skeleton dirs for 'static' and venvs; retention logic deletes old backups
 - Strengths: careful about skipping heavy folders and can create skeletons to preserve structure; uses robocopy options for reliability
 - Issues / improvements:
   - Default parameter $Source = "D:\project25" and DestinationRoot = "D:\backups\project25" are hard-coded absolute paths. This is surprising for a repository-scoped script. Recommend defaulting $Source to the repository root (or current directory) and DestinationRoot to a relative or configurable backup base (e.g., $env:USERPROFILE\backups\project or .\backups).
   - When used as part of setup.ps1, setup passes Source = $root and DestinationRoot = Join-Path $env:USERPROFILE "backups\project" — good. But the script's default value still surprising for casual runs.
   - Exclusion detection for .venv* uses Get-ChildItem -Filter '.venv*' — Filter supports wildcards but on some PS versions Filter applies only to the leaf name; the usage is OK. However, the script adds both detected .venv* entries and 'venv' statically to $excludeDirs; that is reasonable.
   - The skeleton creation logic copies directory structure under static recursively but uses substring operations to compute relative path; using Resolve-Path and Split-Path might be more robust.
   - Robocopy arguments are passed in an array and then executed with `& robocopy @robocopyArgs`. This is acceptable, but if any path contains spaces the args must be properly quoted. Current code places paths as separate array elements which is OK.
   - Robocopy exit code handling: script throws when $exitCode -ge 8 — consistent with Robocopy docs where codes >= 8 indicate failures. OK.
   - Retention logic looks for files named backup_*.zip and then falls back to folders. Since the script creates timestamped folders without backup_ prefix, the primary `Get-ChildItem -Filter 'backup_*.zip'` likely always returns empty and it will then list folders — that works but is confusing. Consider making either zip archives or use consistent naming (e.g. destination folder name 'backup_2026-08-16_...' or keep using timestamp but change filter to match the pattern used).

Recommended changes (backup_robo.ps1):
 - Default $Source to '.' (current repo root) or detect script root with $PSScriptRoot; e.g. param([string]$Source = (Split-Path -Parent $MyInvocation.MyCommand.Definition))
 - Ensure $DestinationRoot exists (New-Item -ItemType Directory -Force) before creating timestamp folder
 - Quote or Resolve-Path all file system paths used when constructing robocopy args to avoid edge cases with spaces
 - Consider adding a -Compress switch that, when enabled, compresses the final timestamp folder with `Compress-Archive` and optionally writes checksums (Get-FileHash) — done outside of Robocopy to avoid large in-memory operations
 - Make retention selection consistent: decide on a naming convention (folders named with `backup_YYYY-MM-DD_HHMM` or zipped archives `backup_YYYY-...zip`) and use that consistently in creation and retention removal
 - Add -WhatIf support (PowerShell common parameter style) and -Verbose logging
 - For performance, optionally add `/MT:16` to robocopy args for multi-threading (but be aware of CPU/disk contention)

Security & operational notes
----------------------------
- Scripts call external tools (docker, docker-compose, robocopy, python). Ensure PATH contains the expected versions and CI runners have them installed.
- The scripts may copy / create .env files. Ensure secrets are not committed. Add README guidance to not check .env into git and use a secret manager for CI.
- When running on developer machines, ExecutionPolicy and admin rights may be required for some operations. Prefer to run scripts with `-ExecutionPolicy Bypass -NoProfile` as shown above to reduce friction.

Small code fixes to apply (copy/paste patches)
---------------------------------------------
Below are minimal, safe edits recommended to improve reliability. Apply as separate commits.

1) install_all.ps1: compute rooted repo path using the script location
- Replace current root detection (line similar to `$root = (Get-Location).Path`) with:
  $root = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

2) setup.ps1: fix .env candidates list and remove duplicates
- Replace the envCandidates line (bad entries with leading spaces) with:
  $envCandidates = @('.env.example', '.env.sample', '.env.template')

3) setup.ps1: remove or fix unused $pipPath (optional)
- If you keep it, compute as a command array or call `$pythonExePath -m pip` consistently. Otherwise, remove the creation of $pipPath to avoid confusion.

4) test.ps1: add configurable backend port parameter and use it when starting uvicorn and checking /health
- Add param([int]$BackendPort = 8000) at the top and replace the hardcoded 8000 in uvicorn args and health URL.
- Replace the health check 'http://127.0.0.1:8000/health' with "http://127.0.0.1:$BackendPort/health"

5) backup_robo.ps1: default Source to script root
- Replace `param([string]$Source = "D:\project25", ...)` with:
  param(
    [string]$Source = (Split-Path -Path $MyInvocation.MyCommand.Definition -Parent),
    [string]$DestinationRoot = (Join-Path $env:USERPROFILE "backups\project25"),
    ...
  )

Operational checklist before "tape out" to git
-----------------------------------------------
1. Run the above three patches locally and run a smoke test of each script.
2. Create a small CI job (Windows-latest) that runs:
   - powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -PythonExe "%Python%"
   - powershell -NoProfile -ExecutionPolicy Bypass -File .\install_all.ps1 -PythonExe "%Python%" -NonInteractive -SkipDocker
   - Confirm pytest finishes and outputs are stored in artifacts/logs
3. Add a small README section that documents script usage and required preconditions (Docker, Python version, ExecutionPolicy) — see the example snippet below.
4. Add gitignore entries to avoid committing backups and large static payloads. Ensure .env is ignored.

README snippet (example)
------------------------
Usage (developer):
  powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1 -PythonExe "C:\Python\Python314\python.exe"
  .\.venv\Scripts\Activate.ps1
  powershell -NoProfile -ExecutionPolicy Bypass -File .\test.ps1

Usage (CI):
  powershell -NoProfile -ExecutionPolicy Bypass -File .\install_all.ps1 -PythonExe "%PYTHON%" -NonInteractive -SkipDocker

Recommended Git workflow for this scripts change
-----------------------------------------------
- Create a feature branch: feature/installer-audit-fixes
- Commit small focused patches (one per script) with descriptive messages
- Add tests (if possible) to exercise the update (e.g., run test.ps1 with -RunPytest:$false and a fake health endpoint)
- Open PR describing the changes and the rationale; include this audit file in scripts/INSTALLER_AUDIT_AND_GUIDE.md

Checklist before committing
---------------------------
- [ ] Apply the minimal edits suggested above
- [ ] Run full .\test.ps1 locally and fix problems
- [ ] Ensure no secrets in .env (manually verify)
- [ ] Add or update CI pipeline to exercise non-Docker install path

Appendix: quick fix diff snippets
--------------------------------
(1) install_all.ps1: root computation
  # OLD
  $root = (Get-Location).Path
  # NEW
  $root = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

(2) setup.ps1: envCandidates cleanup
  # OLD
  $envCandidates = @(' .env.example',' .env.sample','.env.template','.env.example','.env.sample')
  # NEW
  $envCandidates = @('.env.example', '.env.sample', '.env.template')

(3) test.ps1: make backend port configurable
  # OLD param block contains only PythonExe, RunPytest... add:
  param(..., [int]$BackendPort = 8000)
  # OLD uvicorn args: '-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', '8000'
  # NEW: replace '8000' with $BackendPort (stringified)

(4) backup_robo.ps1: default source
  # OLD
  param(
    [string]$Source = "D:\project25",
    [string]$DestinationRoot = "D:\backups\project25",
    ... )
  # NEW
  param(
    [string]$Source = (Split-Path -Path $MyInvocation.MyCommand.Definition -Parent),
    [string]$DestinationRoot = (Join-Path $env:USERPROFILE "backups\project25"),
    ... )

Closing notes & recommendations
-------------------------------
- The repository's scripts are already fairly thorough and aim to be forgiving for manual use. To make them CI-grade:
  1) ensure deterministic exit codes (fail-fast on critical errors unless explicitly opted out)
  2) capture logs and expose them as artifacts
  3) make ports and paths configurable via parameters or environment variables
  4) fix the small bugs called out above (envCandidates, default backup path, root detection)

- After applying the suggested small edits, commit them with a clear message and include this document. Example commit message:
  "scripts: harden installer and backup scripts; fix env template detection; use script-root resolution\n\nSee scripts/INSTALLER_AUDIT_AND_GUIDE.md for details.\n\nCo-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"

If you'd like, apply the minimal patches now and I can run the test suite and a smoke backup to validate them, then create the git commit message. Alternatively I can produce standalone patch files (diffs) as ready-to-apply edits.