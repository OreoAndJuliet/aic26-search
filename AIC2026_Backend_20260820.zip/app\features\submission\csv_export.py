"""Write competition CSV files and Codabench submission ZIP archives."""

from __future__ import annotations

import csv
import io
import zipfile
from pathlib import Path

from app.features.submission.adapter import CsvRow, normalize_task_type

CODABENCH_SUBMISSION_DIR = "submission"
MAX_SUBMISSION_ROWS = 100


def task_type_slug(task_type: str) -> str:
    normalized = normalize_task_type(task_type)
    return {"KIS": "kis", "QA": "qa", "TR": "trake"}[normalized]


def codabench_csv_name(query_id: int, task_type: str) -> str:
    """Official-style filename: query-1-kis.csv, query-2-qa.csv, ..."""
    return f"query-{int(query_id)}-{task_type_slug(task_type)}.csv"


def _format_vqa_row(row: CsvRow) -> str:
    video_id = str(row[0])
    frame_id = int(row[1])
    answer = str(row[2]).replace('"', '""')
    return f'{video_id},{frame_id},"{answer}"'


def submission_csv_text(rows: list[CsvRow], *, task_type: str) -> str:
    if normalize_task_type(task_type) == "QA":
        if not rows:
            return ""
        return "\n".join(_format_vqa_row(row) for row in rows) + "\n"

    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
    for row in rows:
        writer.writerow(row)
    return buffer.getvalue()


def write_submission_csv(path: Path, rows: list[CsvRow], *, task_type: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(submission_csv_text(rows, task_type=task_type), encoding="utf-8")


def build_codabench_zip(
    zip_path: Path,
    entries: list[tuple[str, list[CsvRow], str]],
) -> Path:
    """Pack CSV files under submission/ inside one Codabench-ready .zip."""
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for filename, rows, task_type in entries:
            arcname = f"{CODABENCH_SUBMISSION_DIR}/{filename}"
            archive.writestr(
                arcname,
                submission_csv_text(rows, task_type=task_type),
            )
    return zip_path
