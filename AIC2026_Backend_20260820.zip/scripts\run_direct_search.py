"""Direct In-Process Search Runner for start.bat / start.ps1 CLI integration.

Allows executing KIS, VQA, and TRAKE searches directly with all multi-modal upgrades
(OCR boosting, speculative consensus judge, 0-token CV, landmark gazetteers) active.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from app.bootstrap import initialize_engines
from app.features.search.service import run_search


async def _run() -> None:
    parser = argparse.ArgumentParser(description="Direct Search with all upgrades active.")
    parser.add_argument("--mode", choices=["KIS", "VQA", "TRAKE"], default="KIS")
    parser.add_argument("--query", default="")
    parser.add_argument("--question", default="")
    parser.add_argument("--events", nargs="*", default=[])
    parser.add_argument("--top-k", type=int, default=10)
    args = parser.parse_args()

    initialize_engines()

    events_list = args.events
    if not events_list and args.query and "|" in args.query and args.mode == "TRAKE":
        events_list = [e.strip() for e in args.query.split("|") if e.strip()]

    payload = {
        "task_type": args.mode,
        "query": args.query,
        "question": args.question or None,
        "events": events_list if events_list else None,
        "top_k": args.top_k,
    }

    response = await run_search(**payload)
    print(json.dumps(response, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(_run())
