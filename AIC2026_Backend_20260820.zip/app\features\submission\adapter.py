"""Convert internal search results to official AIC competition submission formats."""

from __future__ import annotations

from typing import Any

MAX_VQA_ANSWER_LENGTH = 100
MAX_SUBMISSION_ROWS = 100

TASK_TYPE_ALIASES = {
    "KIS": "KIS",
    "TKIS": "KIS",
    "TEXTUAL_KIS": "KIS",
    "VQA": "QA",
    "QA": "QA",
    "TRAKE": "TR",
    "TR": "TR",
}


def normalize_task_type(task_type: str) -> str:
    normalized = task_type.strip().upper()
    try:
        return TASK_TYPE_ALIASES[normalized]
    except KeyError as exc:
        raise ValueError(f"Unsupported submission task type: {task_type}") from exc


def build_kis_answer(result: dict[str, Any]) -> dict[str, str]:
    """One KIS ranked hit for POST /submit answerSets."""
    frame_id = int(result["frame_id"])
    frame_text = str(frame_id)
    return {
        "mediaItemName": str(result["video_id"]),
        "start": frame_text,
        "end": frame_text,
    }


def build_qa_text(result: dict[str, Any]) -> str:
    """QA answer string: QA-{ANSWER}-{mediaItemName}-{start},{end}."""
    video_id = str(result["video_id"])
    frame_id = int(result["frame_id"])
    answer = str(result.get("answer", "")).strip()[:MAX_VQA_ANSWER_LENGTH]
    if not answer:
        raise ValueError("VQA submission requires a non-empty answer on the top result.")
    return f"QA-{answer}-{video_id}-{frame_id},{frame_id}"


def build_tr_text(video_id: str, event_frames: list[int]) -> str:
    """TR answer string: TR-{mediaItemName}-{f1},{f2},..."""
    if not video_id.strip():
        raise ValueError("TRAKE submission requires a video_id.")
    if not event_frames:
        raise ValueError("TRAKE submission requires at least one event frame.")
    frames = ",".join(str(int(frame)) for frame in event_frames)
    return f"TR-{video_id}-{frames}"


def build_answer_set(
    task_type: str,
    results: list[dict[str, Any]],
    *,
    trake_meta: dict[str, Any] | None = None,
) -> dict[str, list[dict[str, str]]]:
    """Build one answerSets[] entry for the mock-server POST /submit body."""
    normalized = normalize_task_type(task_type)
    answers: list[dict[str, str]] = []

    if normalized == "KIS":
        for result in results[:MAX_SUBMISSION_ROWS]:
            answers.append(build_kis_answer(result))
    elif normalized == "QA":
        if not results:
            raise ValueError("VQA submission requires at least one result.")
        answers.append({"text": build_qa_text(results[0])})
    elif normalized == "TR":
        meta = trake_meta or {}
        video_id = str(meta.get("video_id") or (results[0]["video_id"] if results else ""))
        event_frames = list(meta.get("event_frames") or [])
        if not event_frames and results:
            event_frames = [int(item["frame_id"]) for item in results]
        answers.append({"text": build_tr_text(video_id, event_frames)})

    return {"answers": answers}


def build_submission_payload(
    team_session_id: str,
    answer_sets: list[dict[str, list[dict[str, str]]]],
) -> dict[str, Any]:
    return {
        "teamSessionId": team_session_id,
        "answerSets": answer_sets,
    }


def search_response_to_grading_results(response: dict[str, Any]) -> list[dict[str, Any]]:
    """Convert unified POST /api/v1/search output to eval_competition JSON rows."""
    results: list[dict[str, Any]] = []
    for index, item in enumerate(response.get("results", []), start=1):
        entry: dict[str, Any] = {
            "video_id": item["video_id"],
            "frame_id": int(item["frame_id"]),
            "rank": int(item.get("rank", index)),
        }
        if item.get("answer") is not None:
            entry["answer"] = item["answer"]
        if item.get("event_index") is not None:
            entry["event_index"] = item["event_index"]
        results.append(entry)

    trake = response.get("trake") or {}
    event_frames = trake.get("event_frames") or []
    if event_frames:
        if results:
            results[0]["event_frames"] = event_frames
        elif trake.get("video_id"):
            results.append(
                {
                    "video_id": trake["video_id"],
                    "frame_id": int(event_frames[0]),
                    "event_frames": event_frames,
                    "rank": 1,
                }
            )
    return results


CsvRow = list[str | int]


def results_to_csv_rows(
    task_type: str,
    results: list[dict[str, Any]],
    *,
    trake_meta: dict[str, Any] | None = None,
) -> list[CsvRow]:
    """Rows for competition CSV export (no header).

    KIS:   [video_id, frame_id]
    VQA:   [video_id, frame_id, answer]
    TRAKE: [video_id, frame_id_1, frame_id_2, ..., frame_id_n]  (single row)
    """
    normalized = normalize_task_type(task_type)

    if normalized == "QA":
        if not results:
            return []
        top = results[0]
        answer = str(top.get("answer", "")).strip()[:MAX_VQA_ANSWER_LENGTH]
        return [[str(top["video_id"]), int(top["frame_id"]), answer]]

    if normalized == "TR":
        meta = trake_meta or {}
        candidate_trajectories = meta.get("candidate_trajectories") or []
        if candidate_trajectories:
            return [[str(traj[0]), *[int(f) for f in traj[1:]]] for traj in candidate_trajectories[:MAX_SUBMISSION_ROWS]]

        video_id = str(meta.get("video_id") or (results[0]["video_id"] if results else ""))
        event_frames = list(meta.get("event_frames") or [])
        if not event_frames and results:
            event_frames = [int(item["frame_id"]) for item in results]
        if not video_id.strip():
            raise ValueError("TRAKE submission requires a video_id.")
        if not event_frames:
            raise ValueError("TRAKE submission requires at least one event frame.")
        return [[video_id, *[int(frame_id) for frame_id in event_frames]]]

    return [[str(item["video_id"]), int(item["frame_id"])] for item in results[:MAX_SUBMISSION_ROWS]]
