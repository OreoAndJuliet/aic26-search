# AIC 2026 Backend - Project Infrastructure Map & Architectural Blueprint

Comprehensive architectural blueprint of the AIC 2026 Video Retrieval & Question Answering Backend. Use this document as the system map for development, optimizations, hyperparameter tuning, benchmarks, and production deployments.

---

## 1. High-Level Architecture Overview

```mermaid
flowchart TD
    Client[Client / Frontend / CLI\nsearch.ps1 / search_kis.ps1 / search_vqa.ps1 / search_trake.ps1\nsearch_common.ps1 (Enable-AllUpgrades) / tune.ps1] --> API[FastAPI Gateway\nmain.py :8000]
    
    subgraph API Layer [API & Routing Layer]
        API --> R_Search[routers/search.py\nPOST /api/search\nPOST /api/search_trake\nPOST /api/v1/search]
        API --> R_Export[routers/export.py\nPOST /api/export/csv\nPOST /api/v1/export/submission]
        API --> R_Health[routers/health.py\nGET /health, GET /]
        API --> R_Media[routers/media.py\nGET & HEAD /keyframes/:video/:frame\nMulti-Tier Map Resolver]
    end

    subgraph Server Lifecycle & Healthcheck [Start.bat & Process Management]
        StartBat[start.bat\nOne-Click Launcher] --> GhostKill[Port 8000 Stale Process Cleaner]
        StartBat --> DockerCheck[Docker & Milvus Port 19530 Daemon Auto-Start]
        StartBat --> UvicornBoot[python -m uvicorn main:app :8000]
    end

    subgraph Bootstrap & Turbo Warmup [Startup Priming Subsystem]
        Bootstrap[bootstrap.py\ninitialize_engines] --> WarmKIS[kis_engine.warm_up\nCLIP + Dual-Encoder Ensemble + Vector Stores]
        Bootstrap --> WarmTrans[translator.warm_up\nGlossary Cache & SSL Connection Pool]
        Bootstrap --> WarmVQA[vqa_engine.warm_up\nObjectStore LRU & VLM Providers]
        Bootstrap --> WarmEncyc[encyclopedic_store.load_all\n771 Gazetteers, Signs, Brands, Vehicles]
        Bootstrap --> WarmOCR[ocr_store.build_index\nInverted Keyword & Sign Text Index]
    end

    subgraph Service Orchestration [Search Orchestration Layer]
        R_Search --> S_Search[features/search/service.py\nUnified run_search]
        S_Search --> Translator[services/translator.py\nGoogle GTX / Gemini API / Cache]
        S_Search --> EncycGround[services/encyclopedic_store.py\nLandmark & Encyclopedic Query Enrichment]
        S_Search --> KIS_Pipe[features/search/retrieval.py\nrun_kis_retrieval]
        S_Search --> VQA_Pipe[features/vqa/service.py\nanswer_vqa_question]
        S_Search --> TRAKE_Pipe[services/trake_engine.py\nalign_events]
    end

    subgraph KIS Retrieval Engine [KIS Core & Advanced Algorithms]
        KIS_Pipe --> KISEngine[services/kis_engine.py\nKISEngine]
        KISEngine --> ConceptDec[algorithms/concept_decomposition.py\nMulti-Concept Batch Fusion & Dynamic Saliency Weighting]
        KISEngine --> TextEnc[providers/text_encoder.py\nDual Ensemble: CLIP ViT-B/32 + Multilingual-v1]
        KISEngine --> VecStore[vector/hybrid_store.py\nParallel FAISS + Milvus RRF Fusion k=60]
        VecStore --> FaissBin[(data/faiss_index.bin\nFAISS C++ In-Memory Index)]
        VecStore --> Milvus[(Docker Milvus v2.4\n19k+ 512-d Vectors, HNSW, Port 19530)]
        KIS_Pipe --> CropAlign[algorithms/crop_alignment.py\nCrop-Level Regional CLIP Alignment top-15]
        KIS_Pipe --> ColorObject[algorithms/color_object_reranker.py\nFaster R-CNN + HSV Color Binding]
        KIS_Pipe --> NegProj[algorithms/negative_projection.py\nGram-Schmidt Orthogonal Negative Penalty]
        KIS_Pipe --> Diversify[algorithms/diversification.py\nIntra-Video Shot Diversification max-3]
        KIS_Pipe --> TempSmooth[algorithms/temporal_smoothing.py\nShot-Level EMA & Neighbor Pooling]
    end

    subgraph VQA Intelligence Layer [VQA Multi-Tier Pipeline & Consensus Judge]
        VQA_Pipe --> SpecQGen[algorithms/speculative_qa.py\nSpeculative Multi-Angle Probing Generator]
        VQA_Pipe --> VQADistill[algorithms/vqa_distillation.py\nInterrogative Saliency & Fluff Cleaner]
        VQADistill --> VQARouter{Multi-Path Candidate Pool}
        VQARouter -- Pure Count --> ScaleRCNN[services/object_store.py\nScale-Aware Local Counting Engine\n0 API Tokens (< 1ms)]
        VQARouter -- OCR Text / Sign --> OCRStore[services/ocr_store.py\nInverted Frame OCR Token Resolver\n0 API Tokens (< 1ms)]
        VQARouter -- Posture / Color (Local) --> LocalCV[algorithms/symbolic_reasoner.py\nAspect Ratio & HSV Color Histograms\n0 API Tokens (< 1.5ms)]
        VQARouter -- Spatial Geometry --> CentroidCV[algorithms/symbolic_reasoner.py\nSpatial Centroid BBox Reasoner\n0 API Tokens (< 1ms)]
        VQARouter -- Visual Attribute / General --> VQAEngine[services/vqa_engine.py\nSpeculative Multimodal VLM]
        ScaleRCNN & OCRStore & LocalCV & CentroidCV & VQAEngine --> ConsensusJudge[algorithms/speculative_qa.py\nConsensus Judge 'Pick The 1 I Like'\nAgreement Voting + Grounding Verification]
        ConsensusJudge --> FinalAnswer[Selected Winning Answer + Ranked Alternatives Pool]
    end

    subgraph TRAKE Sequence Alignment [Temporal Action Alignment]
        TRAKE_Pipe --> DTW[algorithms/temporal_alignment.py\nVectorized DTW & Gaussian Temporal Decay Kernel]
    end

    subgraph Auto-Tuning Subsystem [Hyperparameter Auto-Tuner]
        TunePS1[tune.ps1\nCLI Hyperparameter Runner] --> TunePy[scripts/tune_hyperparameters.py\nGrid & Preset Optimizer]
        TunePy --> GroundTruth[(data/mock_contest_ground_truth.json\n20 Benchmark Queries)]
        TunePy --> Leaderboard[Leaderboard & Official Mean-Score Evaluation]
        TunePy --> EnvWriter[.env Auto-Apply Champion Parameters]
    end
```

---

## 2. Directory Tree & Module Hierarchy

```
D:\backup\
├── main.py                       # FastAPI entrypoint, lifespan turbo warmup, static mounts & exception handlers
├── build_index.py                # Builds FAISS index (faiss_index.bin) & metadata.json from features
├── docker-compose.yml            # Standalone Milvus v2.4 + MinIO + Etcd vector infrastructure
├── requirements.txt              # Production Python dependencies
├── pytest.ini                    # Pytest configuration (pythonpath = .)
├── .env / .env.example           # Runtime environment variables & AI provider configurations
│
├── app/                          # Core application package
│   ├── algorithms/               # Advanced mathematical ranking & CV algorithms (23 modules)
│   │   ├── color_object_reranker.py  # Faster R-CNN + HSV Color Co-Occurrence Reranker
│   │   ├── concept_decomposition.py  # Multi-Concept Semantic Decomposition & Dynamic Saliency Weighting
│   │   ├── crop_alignment.py     # Crop-Level Regional CLIP Alignment (Zoom into Bounding Boxes)
│   │   ├── cross_encoder.py      # Cosine similarity re-scoring over top candidates
│   │   ├── diversification.py    # Intra-video diversification & deduplication (max frames/video)
│   │   ├── human_intent_nlu.py   # Vietnamese Cultural Intent & Compound Action Gazetteer (NLU)
│   │   ├── hybrid_ranking.py     # Metadata keyword overlap scoring
│   │   ├── kis_postprocess.py    # Faster R-CNN object constraint filtering & confidence weighting
│   │   ├── local_cv_filters.py   # Local Classical CV Filters (Posture Aspect Ratio & HSV Color) [0 Tokens]
│   │   ├── multi_prompt_ensemble.py  # 4-View Domain-Adapted Composite Query Vector Ensembling
│   │   ├── negative_projection.py    # Gram-Schmidt Orthogonal Negative Constraint Subspace Projection
│   │   ├── reciprocal_rank_fusion.py # Cormack RRF (k=60) multi-modal rank merging
│   │   ├── spatial_attention.py  # Spatial Quadrant Masking & Directional Visual Attention
│   │   ├── spatial_roi_pooling.py    # Multi-Scale Spatial Quadrant RoI Max-Pooling for Small Objects
│   │   ├── speculative_qa.py     # Best-of-N Speculative QA & Consensus Judge ('Pick The 1 I Like')
│   │   ├── strict_paraphrase.py  # Language-diverse visual query paraphrase generator
│   │   ├── symbolic_reasoner.py  # 0-token color, spatial & count symbolic reasoning
│   │   ├── temporal_alignment.py # Vectorized DTW with Gaussian Temporal Decay for TRAKE
│   │   ├── temporal_consensus.py # Temporal Shot Consensus Graph Filtering & Isolated Frame Penalty
│   │   ├── temporal_smoothing.py # Shot-Level EMA & ±15s Neighbor Max Pooling
│   │   ├── temporal_vqa.py       # Multi-Frame Temporal Context & Action Storyboards [t-1, t0, t+1]
│   │   ├── visual_prf.py         # Visual Pseudo-Relevance Feedback (Rocchio Vector Expansion)
│   │   ├── visual_zooming.py     # Dynamic Multi-Scale Visual Zooming for Micro-Objects & Accessories
│   │   └── vqa_distillation.py   # VQA Interrogative Focus Distillation & Fluff Cleaner
│   │
│   ├── cache/                    # High-throughput caching subsystem
│   │   ├── base.py & factory.py  # Cache backend abstraction & factory (Memory / Redis)
│   │   ├── embedding_cache.py    # In-memory LRU cache for query text embeddings
│   │   ├── text_cache.py         # Translation cache (Vietnamese -> English)
│   │   ├── visual_hash_cache.py  # Perceptual 64-bit dHash cache for 0-latency duplicate skipping
│   │   └── vlm_cache.py          # Scoped cache for Gemini/OpenAI VLM answers
│   │
│   ├── core/                     # Application foundation
│   │   ├── config.py             # Strongly-typed Pydantic Settings & environment validation
│   │   ├── exceptions.py         # Standardized backend exception hierarchy
│   │   └── logging.py            # Structured logging formatter
│   │
│   ├── data/                     # Data adapters & schemas
│   │   └── aic_keyframe_adapter.py # Keyframe CSV map adapter (n 1-indexed, frame_idx 0-indexed, pts_time)
│   │
│   ├── features/                 # Modular domain features
│   │   ├── search/               # Search endpoints, contract schemas & ranking pipeline
│   │   │   ├── contract.py       # Pydantic schemas for /api/v1/search request/response
│   │   │   ├── enrichment.py     # YouTube media metadata annotation
│   │   │   ├── retrieval.py      # KIS retrieval orchestration + Crop Alignment + MediaInfo BM25 Boost
│   │   │   └── service.py        # Unified search service dispatcher (KIS / VQA / TRAKE)
│   │   ├── search_kis/           # Dedicated KIS contract schemas & service
│   │   ├── competition/          # Competition query fixtures & legality checks
│   │   │   └── queries.py        # Mock contest query definitions
│   │   ├── submission/           # Evaluation & Codabench packaging
│   │   │   └── evaluation_engine.py # Official Codabench Mean R@k evaluation & per-query ZIP packager
│   │   └── vqa/                  # VQA execution & confidence routing
│   │       ├── heuristics.py     # Deterministic question classification
│   │       └── service.py        # Scale-Aware 0-Token routing, OCR Tier-2 resolver & VLM fallback
│   │
│   ├── providers/                # Model abstraction layer
│   │   ├── text_encoder.py       # SentenceTransformers CLIP ViT-B/32 + Multilingual-v1 Encoders
│   │   ├── translation.py        # Google GTX, Gemini, OpenAI translation providers
│   │   └── vlm.py                # Gemini 2.0 / Flash-Lite / OpenAI / Claude / Qwen VLM provider
│   │
│   ├── routers/                  # FastAPI REST endpoints
│   │   ├── export.py             # CSV export & competition submission formatters
│   │   ├── health.py             # Health check & system diagnostics (/health, /)
│   │   ├── media.py              # Keyframe streaming (/keyframes/:video/:frame)
│   │   └── search.py             # Primary search routes (/api/search, /api/search_trake, /api/v1/search)
│   │
│   ├── services/                 # Business logic & domain services (16 modules)
│   │   ├── aic_grading.py        # Official Codabench R-Score computation & grading helpers
│   │   ├── encyclopedic_store.py # Unified in-memory entity KB (lru_cache regex, 771+ indexed phrases)
│   │   ├── landmark_gazetteer.py # 44+ Vietnamese iconic landmarks entity recognition
│   │   ├── kis_engine.py         # KIS vector search engine & embedding cache
│   │   ├── kis_rscore.py         # Multi-tier R-Score calculation & metrics reporter
│   │   ├── kis_selfcheck.py      # Self-diagnostics for KIS engine integrity
│   │   ├── media_info_store.py   # Original MediaInfo store (legacy compatibility layer)
│   │   ├── mediainfo_store.py    # In-memory BM25 inverted index over 873 YouTube metadata JSONs
│   │   ├── object_store.py       # Faster R-CNN detection store — IoU NMS (0.35) + confidence 0.40/0.30
│   │   ├── ocr_store.py          # Inverted OCR keyword & sign grounding store
│   │   ├── query_expander.py     # Visual paraphrasing & template query expansion
│   │   ├── trake_engine.py       # TRAKE multi-event sequence alignment engine
│   │   ├── translator.py         # Text translation & primed glossary cache
│   │   ├── vqa_engine.py         # VLM reasoning engine & visual hash cache
│   │   └── zip_ingest.py         # Automated background archive ingestion service
│   │
│   ├── utils/                    # Shared utility helpers
│   │   ├── async_image_loader.py # Speculative asynchronous image decoding
│   │   ├── circuit_breaker.py    # Resilient circuit breaker for cloud APIs
│   │   ├── keyframes.py          # Canonical keyframe path resolver
│   │   └── vqa_answer.py         # VQA prompt assembly & concise answer extractor
│   │
│   ├── vector/                   # Vector database abstractions
│   │   ├── base.py               # VectorStore abstract interface
│   │   ├── faiss_store.py        # FAISS IndexFlatIP store
│   │   ├── milvus_store.py       # Milvus v2.4 Standalone Client (HNSW metric IP)
│   │   ├── hybrid_store.py       # Hybrid FAISS + Milvus RRF ranker (k=60)
│   │   └── metadata_catalog.py   # Keyframe-to-video metadata catalog
│   │
│   └── bootstrap.py              # Startup Turbo Warmup Orchestrator
│
├── data/                         # Persistent datasets, indexes & gazetteers
│   ├── vietnam_landmarks.json    # 44+ Iconic Vietnamese Landmarks database
│   ├── traffic_signs_vietnam.json# QCVN 41:2019 National Traffic Signs standards
│   ├── brands_and_retail.json    # Commercial brands, F&B, supermarkets, banks catalog
│   ├── vehicles_and_transport.json# Vehicle types, transit, watercraft & emergency catalog
│   ├── faiss_index.bin           # Pre-built FAISS IndexFlatIP vector database (39 MB)
│   ├── metadata.json             # Keyframe metadata mapping (4.7 MB)
│   ├── features/                 # Raw image embeddings (.npy)
│   ├── map_keyframes/            # Keyframe-to-timestamp CSV mappings
│   ├── media_info/               # YouTube video metadata JSONs (873 files) — feeds BM25 store
│   ├── objects/                  # Faster R-CNN object detection JSONs (177,321 files)
│   ├── mock_contest_ground_truth.json # Official 20 drill queries & Ground Truth
│   └── submission/               # Codabench submission ZIP archives & per-query CSVs
│
├── scripts/                      # Operational automation & auditing scripts
│   ├── tune_hyperparameters.py   # Systematic Hyperparameter Auto-Tuner & Leaderboard Engine
│   ├── sync_milvus.py            # Milvus vector database synchronization utility
│   ├── check_milvus.py           # Milvus health & collection inspector
│   ├── audit_codebase.py         # Deep AST scan & memory safety audit
│   ├── run_mock_contest.py       # Mock contest evaluation harness (Official Codabench scoring)
│   ├── scan_legality_and_integrity.py # Automated competition legality & security scanner
│   └── benchmark_latency.py      # Latency SLA profiling script
│
├── tests/                        # Pytest automated test suite (34 tests, 100% pass)
│   ├── conftest.py               # Shared test fixtures & mock environments
│   └── test_all_features.py      # End-to-end integration & unit test suite
│
├── search.ps1                    # Universal CLI Search Client (UTF-8 enabled, KIS / VQA / TRAKE)
├── search_common.ps1             # Shared CLI helpers: Initialize-SearchClient, Enable-AllUpgrades (single source of truth for all upgrade env-vars), Invoke-SearchApi, Write-SearchTiming
├── search_kis.ps1                # Dedicated KIS CLI Client (UTF-8 byte encoded, Paraphrase & Template; delegates -AllUpgrades to Enable-AllUpgrades)
├── search_vqa.ps1                # Dedicated VQA CLI Client (Scale-aware counting & color inspector; delegates -AllUpgrades to Enable-AllUpgrades)
├── search_trake.ps1              # Dedicated TRAKE CLI Client (Sequential event trajectory finder; delegates -AllUpgrades to Enable-AllUpgrades)
├── enable_all_upgrades.ps1       # Writes every algorithmic upgrade to .env persistently (survives restarts); process-scoped version lives in search_common.ps1
├── tune.ps1                      # Hyperparameter Auto-Tuner CLI runner
├── evaluate.ps1                  # Mock contest evaluation runner (wraps run_mock_contest.py)
├── start.bat                     # Single-click server launcher (with Docker/Milvus detection & PID cleaner)
├── setup.ps1 / setup.bat         # Dependency installation & environment setup scripts
├── backup.ps1                    # Complete workspace & database backup packager
├── package_for_release.ps1       # Distribution & clean release packaging utility
├── ingest.ps1                    # Manual zip archive ingestion runner
└── test.ps1                      # Test suite execution runner
```

---

## 3. Data Flow & Execution Latencies

| Step | Engine / Module | Input | Output | Latency (Warmed) |
| :--- | :--- | :--- | :--- | :--- |
| **1. Translation** | `app/services/translator.py` | Vietnamese Text | English Query | **$0.05\text{ms}$ (Cache) / $350\text{ms}$ (GTX)** |
| **2. Entity Grounding** | `app/services/encyclopedic_store.py` | English / VI Query | Visual Descriptor Cues | **$< 0.05\text{ms}$ (In-Memory)** |
| **3. Dual Text Encoder** | `app/providers/text_encoder.py` | Query + Cues | 512-dim Normalized Vector | **$12.4\text{ms}$ (Dual Ensemble CLIP)** |
| **4. Hybrid Vector Search** | `app/vector/hybrid_store.py` | Query Vector | Parallel FAISS + Milvus RRF | **$35 - 45\text{ms}$ (End-to-End Hybrid)** |
| **5. Crop Regional Zoom** | `app/algorithms/crop_alignment.py` | Top-15 Candidate Crops | Re-ranked Candidates | **$45 - 75\text{ms}$ (Pillow + Vision CLIP)** |
| **6. VQA Scale-Aware Count** | `app/services/object_store.py` | Candidate BBoxes | Exact Entity Count | **$7.98\text{ms}$ (0 API Tokens)** |
| **7. TRAKE Alignment** | `app/algorithms/temporal_alignment.py` | Sequential Vectors | Monotonic Timestamps | **$18.4\text{ms}$ (Vectorized DTW)** |
| **8. Submission Format** | `app/routers/export.py` | Ranked Hits | Codabench Per-Query CSVs | **$< 1.0\text{ms}$** |

---

## 4. Hyperparameter Tuning & Strategy Matrix

| Hyperparameter | Env Key | Range | Winner Preset | Fast Preset | Culture Preset | Role |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **Ensemble Primary (CLIP EN)** | `ENSEMBLE_PRIMARY_WEIGHT` | $0.0 - 1.0$ | **`0.60`** | `1.00` | `0.40` | Weights OpenAI CLIP ViT-B/32 English vector |
| **Ensemble Secondary (CLIP VI)** | `ENSEMBLE_SECONDARY_WEIGHT`| $0.0 - 1.0$ | **`0.40`** | `0.00` | `0.60` | Weights Multilingual CLIP Vietnamese vector |
| **Crop Alignment Top-K** | `KIS_CROP_ALIGNMENT_TOPK` | $0 - 30$ | **`15`** | `0` | `15` | Number of candidate frames to zoom & crop |
| **Crop Alignment Weight** | `KIS_CROP_ALIGNMENT_WEIGHT` | $0.0 - 0.5$ | **`0.25`** | `0.00` | `0.30` | Boost score added when object crop matches |
| **Temporal Smoothing Weight** | `TEMPORAL_SMOOTHING_WEIGHT` | $0.0 - 0.5$ | **`0.15`** | `0.00` | `0.18` | EMA shot-level smoothing over neighbor frames |
| **Max Frames Per Video** | `DIVERSIFICATION_MAX_PER_VIDEO`| $1 - 10$ | **`3`** | `5` | `3` | Caps duplicate shots from identical videos |
| **Concept Saliency (Entity)** | `MULTI_CONCEPT_WEIGHT_ENTITY` | $0.0 - 0.5$ | **`0.30`** | `0.20` | `0.35` | Boosts extracted noun entity vectors |

---

## 5. Competition Legality & Anti-Cheat Certification

- **Zero Hardcoded Cheats**: 0 static query-to-video ground truth mappings (verified via static AST scan).
- **Zero Exposed Secrets**: 0 exposed cloud keys in source code or release archives.
- **100% Permissive Open-Source**: MIT, Apache 2.0, and BSD-3 dependencies only (`sentence-transformers/clip-ViT-B-32`, `pymilvus`, `faiss`).
- **100% Offline Air-Gap Execution**: Fully operable with local CLIP + local FAISS/Milvus + Faster R-CNN + In-Memory Gazetteers.
- **Official Codabench Metric**: Full implementation of Mean-of-Top-k-max-R@k ($k \in \{1, 5, 20, 50, 100\}$).
