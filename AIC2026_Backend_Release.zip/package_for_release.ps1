﻿<#
.SYNOPSIS
    Packages the project into a clean ZIP file for distribution.
.DESCRIPTION
    Creates an AIC2026_Backend_Release.zip file that you can share with others.
    It automatically excludes heavy or local-only folders like .venv, data, and static images.
#>
$ErrorActionPreference = 'Stop'
$distName = "AIC2026_Backend_Release.zip"
$outPath = Join-Path $PSScriptRoot $distName

if (Test-Path $outPath) { Remove-Item $outPath -Force }

Write-Host "Packaging project to $distName..." -ForegroundColor Cyan

# Items to include (we exclude heavy data folders so the zip is small)
$includes = @(
    "app",
    "scripts",
    "main.py",
    "build_index.py",
    "requirements.txt",
    ".env.example",
    "*.ps1",
    "*.bat",
    "docker-compose.yml",
    "Dockerfile",
    "GUIDE.md",
    "AIC2026_REQUIREMENTS_ANALYSIS.md"
)

# Use Compress-Archive
Get-ChildItem -Path $PSScriptRoot | 
    Where-Object { 
        $name = $_.Name
        $match = $false
        foreach ($inc in $includes) {
            if ($name -like $inc) { $match = $true; break }
        }
        $match -and ($name -ne $distName)
    } | 
    Compress-Archive -DestinationPath $outPath -Force

Write-Host "Created release zip: $outPath" -ForegroundColor Green
Write-Host "You can now upload this zip file for people to download." -ForegroundColor Yellow
Write-Host "When they extract it, they just need to double-click setup.bat!" -ForegroundColor Yellow
