[CmdletBinding()]
param (
    [Parameter(Mandatory = $false, Position = 0, HelpMessage = "Event/context text in Vietnamese or English")]
    [string]$ContextText,

    [Parameter(Mandatory = $false, Position = 1, HelpMessage = "Question about the retrieved frame")]
    [string]$Question,

    [Parameter(HelpMessage = "Show detailed command usage and exit")]
    [Alias("h")]
    [switch]$Help,

    [int]$topK = 5,
    [string]$apiBase = ""
)

# Set default API base from environment variable if not provided
if (-not $apiBase) {
    $apiBase = if ($env:BACKEND_HOST) { $env:BACKEND_HOST } else { "http://127.0.0.1:8000" }
}

function Show-SearchVqaHelp {
    Write-Host ""
    Write-Host "Usage: .\search_vqa.ps1 [contextText] [question] [-Help] [-topK N] [-apiBase URL]" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  .\search_vqa.ps1 'a person walking in a room' 'How many people are visible?'" -ForegroundColor Gray
    Write-Host "  .\search_vqa.ps1 -Help" -ForegroundColor Gray
    Write-Host "  .\search_vqa.ps1 'một người đang đi trong phòng' 'Có bao nhiêu người?' -topK 10" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -topK N        Number of candidate frames to inspect (default: 5)" -ForegroundColor Gray
    Write-Host "  -apiBase URL   Backend URL (default: http://127.0.0.1:8000)" -ForegroundColor Gray
    Write-Host ""
}

if ($Help) {
    Show-SearchVqaHelp
    exit 0
}

# Usage:
#   .\search_vqa.ps1 "a person walking in a room" "How many people are visible?"
#   .\search_vqa.ps1
#     (script will prompt for context + question)

. "$PSScriptRoot\search_common.ps1"
Initialize-SearchClient

if ([string]::IsNullOrWhiteSpace($ContextText)) {
    $ContextText = Read-Host "Enter event/context text"
}

if ([string]::IsNullOrWhiteSpace($Question)) {
    $Question = Read-Host "Enter VQA question"
}

if ([string]::IsNullOrWhiteSpace($ContextText)) {
    Write-Error "Context text cannot be empty."
    exit 1
}

if ([string]::IsNullOrWhiteSpace($Question)) {
    Write-Error "Question cannot be empty."
    exit 1
}

Write-Host "Mode: VQA (KIS top-$topK + answer)"
Write-Host "Context: $ContextText"
Write-Host "Question: $Question"
Write-Host ""

try {
    $response = Invoke-SearchApi -ApiBase $apiBase -Body @{
        type     = "VQA"
        text     = $ContextText
        question = $Question
        top_k    = $topK
    }
}
catch {
    throw "VQA search failed. Check that the backend is running at $apiBase. Error: $_"
}

if ($null -eq $response.results -or $response.results.Count -eq 0) {
    throw "No VQA results returned."
}

$results = Add-SearchResultLinks -Results @($response.results) -ApiBase $apiBase

Write-Host "Translated context: $($response.translated_text)"
if ($response.translation_applied) {
    Write-Host "Translation applied: yes"
}
Write-Host ""
Write-Host "Top $($results.Count) VQA result(s):"

$results | Select-Object `
    rank,
    @{Name='r_score'; Expression={ if ($_.PSObject.Properties.Name -contains 'r_score') { "{0:F4}" -f [double]$_.r_score } else { "N/A" } }},
    answer,
    video_id,
    frame_id,
    keyframe_id,
    @{Name='time(s)'; Expression={ "{0:F1}" -f [double]$_.timestamp } },
    link | Format-Table -AutoSize

Write-SearchTiming -Response $response

$best = $results | Select-Object -First 1
Write-Host ""
Write-Host "Best answer: $($best.answer)"
Write-Host "Frame: $($best.video_id), frame_id=$($best.frame_id)"
Write-Host "Thumbnail: $($best.link)"

