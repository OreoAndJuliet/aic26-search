@echo off
echo ===================================================
echo     AIC 2026 Backend - Starting Server
echo ===================================================
echo.
if not exist "%~dp0.venv\Scripts\uvicorn.exe" (
    echo Error: Virtual environment not found. Please run setup.bat first!
    pause
    exit /b 1
)
"%~dp0.venv\Scripts\uvicorn.exe" main:app --host 0.0.0.0 --port 8000
pause
