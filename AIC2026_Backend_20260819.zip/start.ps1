# =============================================================================
#  AIC 2026 - Smart Server Launcher & All-in-One CLI (KIS / VQA / TRAKE)
# =============================================================================
[CmdletBinding()]
param (
    [Alias("k")]
    [string]$Kis = "",

    [Alias("v")]
    [string]$Vqa = "",

    [Alias("q")]
    [string]$Question = "",

    [Alias("t")]
    [string]$Trake = "",

    [string[]]$Events = @(),

    [int]$TopK = 10,

    [switch]$Benchmark,
    [switch]$Test,
    [switch]$AutoTune,
    [switch]$ForceReindex,
    [int]$Port = 8000,
    [string]$HostIP = "0.0.0.0",
    [switch]$Json,
    [Alias("h")]
    [switch]$Help
)

$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"

# 1. Resolve Python executable
$pythonExe = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    $pythonExe = "python"
}

# --- Quick Action Branch: KIS / VQA / TRAKE Direct Search -------------------
if ($Kis -ne "" -or $Vqa -ne "" -or $Trake -ne "" -or $Benchmark -or $Test) {
    if ($Benchmark) {
        Write-Host ">>> Running AIC 2026 Open-World Codabench Benchmark on Real Data..." -ForegroundColor Cyan
        & $pythonExe (Join-Path $PSScriptRoot "scripts\run_open_world_benchmark.py")
        exit $LASTEXITCODE
    }

    if ($Test) {
        Write-Host ">>> Running Complete Automated Test Suite (44 Tests)..." -ForegroundColor Cyan
        $pytestExe = Join-Path $PSScriptRoot ".venv\Scripts\pytest.exe"
        if (Test-Path $pytestExe) {
            & $pytestExe (Join-Path $PSScriptRoot "tests\test_all_features.py") (Join-Path $PSScriptRoot "tests\test_speculative_consensus.py") -v
        } else {
            & $pythonExe -m pytest (Join-Path $PSScriptRoot "tests\test_all_features.py") (Join-Path $PSScriptRoot "tests\test_speculative_consensus.py") -v
        }
        exit $LASTEXITCODE
    }

    # Determine mode & parameters
    $mode = "KIS"
    $query = $Kis
    if ($Vqa -ne "") {
        $mode = "VQA"
        $query = $Vqa
    } elseif ($Trake -ne "" -or $Events.Count -gt 0) {
        $mode = "TRAKE"
        $query = $Trake
    }

    Write-Host "=================================================================" -ForegroundColor Cyan
    Write-Host "       AIC 2026 DIRECT SEARCH ENGINE (ALL UPGRADES ACTIVE)       " -ForegroundColor Cyan
    Write-Host "=================================================================" -ForegroundColor Cyan
    Write-Host "Mode:       $mode" -ForegroundColor Yellow
    Write-Host "Query:      $query" -ForegroundColor Yellow
    if ($Question) { Write-Host "Question:   $Question" -ForegroundColor Yellow }
    Write-Host "Upgrades:   Dual-Language OCR Boosting | 4-View Vector Ensemble | Consensus Judge | Faster R-CNN" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Gray

    $directScript = Join-Path $PSScriptRoot "scripts\run_direct_search.py"
    $extraArgs = @()
    if ($Question -ne "") {
        $extraArgs += @("--question", $Question)
    }
    if ($Events.Count -gt 0) {
        $extraArgs += @("--events") + $Events
    }

    $rawJson = & $pythonExe $directScript --mode $mode --query "$query" --top-k $TopK @extraArgs
    
    if ($Json) {
        $rawJson
        exit 0
    }

    try {
        $response = $rawJson | ConvertFrom-Json
        $results = @($response.results)

        if ($results.Count -eq 0) {
            Write-Host "No matching results found." -ForegroundColor Red
            exit 0
        }

        Write-Host "`nTop $($results.Count) Result(s):" -ForegroundColor Cyan
        
        $tableRows = @()
        foreach ($r in $results) {
            $rowObj = [ordered]@{
                rank        = $r.rank
                score       = "{0:F4}" -f [double]$r.score
                video_id    = $r.video_id
                frame_id    = $r.frame_id
                keyframe_id = $r.keyframe_id
                time_s      = "{0:F1}" -f [double]$r.timestamp
            }
            if ($mode -eq "VQA") {
                $rowObj['answer']     = $r.answer
                $rowObj['confidence'] = if ($r.confidence) { "{0:P0}" -f [double]$r.confidence } else { "N/A" }
                $rowObj['source']     = $r.source
            }
            $tableRows += [PSCustomObject]$rowObj
        }

        $tableRows | Format-Table -AutoSize

        if ($mode -eq "VQA" -and $results[0].alternative_answers -and $results[0].alternative_answers.Count -gt 0) {
            Write-Host "Selected Answer: $($results[0].answer)" -ForegroundColor Green
            Write-Host "Decision Source: $($results[0].source) (Confidence: $("`{0:P0`}" -f [double]$results[0].confidence))" -ForegroundColor Cyan
            if ($results[0].rationale) {
                Write-Host "Consensus Rationale: $($results[0].rationale)" -ForegroundColor DarkYellow
            }
            Write-Host "`nSpeculative Candidate Answers Pool ('Pick the 1 you like'):" -ForegroundColor Yellow
            $aIdx = 1
            foreach ($alt in $results[0].alternative_answers) {
                $altConf = "{0:P0}" -f [double]$alt.confidence
                Write-Host "  [$aIdx] $($alt.text) - Source: $($alt.source) ($altConf) | $($alt.rationale)" -ForegroundColor DarkCyan
                $aIdx++
            }
        }

        # Print Metrics
        if ($response.metrics) {
            Write-Host ""
            Write-Host "Timing: total=$($response.metrics.retrieval_time_ms)ms  faiss=$($response.metrics.faiss_time_ms)ms  embed=$($response.metrics.embedding_time_ms)ms" -ForegroundColor DarkGray
        }
        
        # --- Generate CSV Submission String & File Link ---
        Write-Host "`n=================================================================" -ForegroundColor Cyan
        Write-Host "       SUBMISSION & VERIFICATION EXPORT                          " -ForegroundColor Yellow
        Write-Host "=================================================================" -ForegroundColor Cyan
        
        $topHit = $results[0]
        $csvStr = ""
        
        if ($mode -eq "KIS") {
            $csvStr = "$($topHit.video_id),$($topHit.frame_id)"
        } elseif ($mode -eq "VQA") {
            $csvStr = "$($topHit.video_id),$($topHit.frame_id),$($topHit.answer)"
        } elseif ($mode -eq "TRAKE") {
            $csvStr = $response.submission_line
        }

        Write-Host "CSV Format:   " -NoNewline
        Write-Host $csvStr -ForegroundColor Green

        # Format 3-digit keyframe ID (e.g. 5 -> 005)
        $kfStr = "{0:D3}" -f [int]$topHit.keyframe_id
        $vid = $topHit.video_id
        $absPath = Join-Path $PSScriptRoot "static\keyframes\$vid\$kfStr.jpg"
        $absPath = $absPath.Replace("\", "/")
        
        Write-Host "Image Link:   " -NoNewline
        Write-Host "file:///$absPath" -ForegroundColor Magenta
        Write-Host "-----------------------------------------------------------------`n" -ForegroundColor Gray

    } catch {
        $rawJson
    }

    exit 0
}

# --- Default Server Launcher Mode --------------------------------------------
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "         AIC 2026 BACKEND SMART SERVER LAUNCHER                  " -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan

# 2. Port Cleanup (Kill any stale process occupying port $Port)
Write-Host "[1/4] Checking Port $Port status..." -ForegroundColor Yellow
try {
    $connections = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($connections) {
        foreach ($conn in $connections) {
            $pidToKill = $conn.OwningProcess
            if ($pidToKill -gt 0) {
                Write-Host "      Freeing stale process (PID: $pidToKill) on port $Port..." -ForegroundColor Yellow
                Stop-Process -Id $pidToKill -Force -ErrorAction SilentlyContinue
            }
        }
        Start-Sleep -Milliseconds 500
        Write-Host "      Port $Port is now completely free." -ForegroundColor Green
    } else {
        Write-Host "      Port $Port is ready." -ForegroundColor Green
    }
} catch {
    Write-Host "      Port check completed." -ForegroundColor Gray
}

# 3. Docker & Milvus Vector Database Healthcheck
Write-Host "[2/4] Checking Docker Milvus Vector Store (Port 19530)..." -ForegroundColor Yellow
$milvusPortActive = $false
try {
    $milvusConn = Test-NetConnection -ComputerName 127.0.0.1 -Port 19530 -WarningAction SilentlyContinue
    if ($milvusConn.TcpTestSucceeded) {
        $milvusPortActive = $true
        Write-Host "      Milvus Standalone is ACTIVE on port 19530 (HNSW Hybrid Mode ready)." -ForegroundColor Green
    }
} catch {}

if (-not $milvusPortActive) {
    Write-Host "      Milvus not detected on port 19530." -ForegroundColor Yellow
    $dockerCmd = Get-Command docker -ErrorAction SilentlyContinue
    if ($dockerCmd) {
        Write-Host "      Attempting to launch Milvus via Docker Compose..." -ForegroundColor Yellow
        & docker compose up -d milvus 2>$null
        Start-Sleep -Seconds 2
    } else {
        Write-Host "      Docker not running. FAISS in-memory C++ engine will handle 100% of queries seamlessly." -ForegroundColor Cyan
    }
}

# 4. Smart New Data & Ground-Truth Detection
Write-Host "[3/4] Checking dataset integrity & new feature batches..." -ForegroundColor Yellow
$featuresDir = Join-Path $PSScriptRoot "data\features"
$faissIndex = Join-Path $PSScriptRoot "data\faiss_index.bin"
$gtJson = Join-Path $PSScriptRoot "data\mock_contest_ground_truth.json"

$newDataDetected = $false

if (Test-Path $featuresDir) {
    $latestFeature = Get-ChildItem -Path $featuresDir -Filter "*.npy" -Recurse -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestFeature -and (Test-Path $faissIndex)) {
        $indexTime = (Get-Item $faissIndex).LastWriteTime
        if ($latestFeature.LastWriteTime -gt $indexTime) {
            $newDataDetected = $true
            Write-Host "      [ALERT] New feature file detected ($($latestFeature.Name)) newer than faiss_index.bin!" -ForegroundColor Magenta
        }
    }
}

if ($ForceReindex -or ($newDataDetected -and -not $AutoTune)) {
    Write-Host "      Rebuilding index (build_index.py)..." -ForegroundColor Yellow
    & $pythonExe (Join-Path $PSScriptRoot "build_index.py")
}

if ($AutoTune -or $newDataDetected) {
    Write-Host "      [AUTO-TUNE] Running hyperparameter auto-tuner (tune.ps1) to find optimal parameters for new data..." -ForegroundColor Cyan
    & $pythonExe -u (Join-Path $PSScriptRoot "scripts\tune_hyperparameters.py") --mode presets --suite kis --apply
}

# 5. Launch Server
Write-Host "[4/4] Starting FastAPI High-Throughput Server on http://${HostIP}:${Port}..." -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Cyan

$uvicornCmd = Join-Path $PSScriptRoot ".venv\Scripts\uvicorn.exe"
if (-not (Test-Path $uvicornCmd)) {
    & $pythonExe -m uvicorn main:app --host $HostIP --port $Port
} else {
    & $uvicornCmd main:app --host $HostIP --port $Port
}
